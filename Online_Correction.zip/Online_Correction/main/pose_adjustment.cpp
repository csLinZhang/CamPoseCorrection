#include <iostream>
#include <cmath>
#include <string>
#include <vector>
#include <boost/format.hpp>
#include <typeinfo>
#include <Eigen/Core>
#include <Eigen/Geometry>
#include "sophus/se3.h"
#include "sophus/so3.h"
#include <g2o/core/base_binary_edge.h>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/opencv.hpp>
#include <opencv2/core/eigen.hpp>


#include "initializer.h"
#include "surroundview.h"

#include "time.h"

using namespace std; 
// using namespace cv;






double CalculatePhotometricError(cv::Mat & mImage_1 , cv::Mat & mImage_2 , cv::Rect iROI){
	cv::Mat mGrayImage_1 , mGrayImage_2;
	cv::cvtColor(mImage_1(iROI),mGrayImage_1,cv::COLOR_BGR2GRAY);
	cv::cvtColor(mImage_2(iROI),mGrayImage_2,cv::COLOR_BGR2GRAY);	
	mGrayImage_1.convertTo(mGrayImage_1, CV_64FC1);
	mGrayImage_2.convertTo(mGrayImage_2, CV_64FC1);

	cv::Mat mDiff;
	cv::subtract(mGrayImage_1, mGrayImage_2, mDiff);

	return cv::norm(mDiff , cv::NORM_L2);
}








int main(int argc, char** argv)
{

	ofstream fOutFile("photometric_error_v1.txt");

	cout<<"------------------Initialize camera pose----------------"<<endl;
	Sophus::SE3 T_FG;
	Sophus::SE3 T_LG;
	Sophus::SE3 T_BG;
	Sophus::SE3 T_RG;
	initializePose(T_FG, T_LG, T_BG, T_RG);
	cout<<T_FG.matrix()<<endl;

	cout<<"---------------Initialize K-------------------------------"<<endl;
	Eigen::Matrix3d K_F;
	Eigen::Matrix3d K_L;
	Eigen::Matrix3d K_B;
	Eigen::Matrix3d K_R;
	initializeK(K_F, K_L, K_B, K_R);
	cout<<K_F<<endl;
	
	cout<<"--------------------Initialize D--------------------------"<<endl;
	Eigen::Vector4d D_F;
	Eigen::Vector4d D_L;
	Eigen::Vector4d D_B; 
	Eigen::Vector4d D_R;
	initializeD(D_F, D_L, D_B, D_R);
	cout<<D_F<<endl;
	
	cout<<"--------------------Load images--------------------------"<<endl;
	int img_index = 1430;
	boost::format img_path_template("/home/kyrie/Documents/Data/1216/%06d ");
	cout<<"Reading "<<(img_path_template%img_index).str()<<"F.jpg"<<endl;
	cv::Mat img_F = cv::imread((img_path_template%img_index).str()+ "F.jpg");
	cout<<"Reading "<<(img_path_template%img_index).str()<<"L.jpg"<<endl;
	cv::Mat img_L = cv::imread((img_path_template%img_index).str()+ "L.jpg");
	cout<<"Reading "<<(img_path_template%img_index).str()<<"B.jpg"<<endl;
	cv::Mat img_B = cv::imread((img_path_template%img_index).str()+ "B.jpg");
	cout<<"Reading "<<(img_path_template%img_index).str()<<"R.jpg"<<endl;
	cv::Mat img_R = cv::imread((img_path_template%img_index).str()+ "R.jpg");
	cout<<img_F.size<<endl;

	cout<<"--------------------Init K_G--------------------------"<<endl;
	int rows = 1000;
	int cols = 1000;
	double dX = 0.1;
	double dY = 0.1;
	double fx =  1/dX;
	double fy = -1/dY;
	cv::Mat K_G = cv::Mat::zeros(3,3,CV_64FC1);
	K_G.at<double>(0,0) = fx;
	K_G.at<double>(1,1) = fy;
	K_G.at<double>(0,2) = cols/2;
	K_G.at<double>(1,2) = rows/2;
	K_G.at<double>(2,2) =   1.0;
	cout<<K_G<<endl;
	
	cout<<"--------------------Add noise to T matrix--------------------------"<<endl;

	Eigen::Matrix<double,6,1>  V6;
	V6<<0.01, -0.01, 0.01, -0.01, 0.01, -0.01;
// 	V6<<0.005, 0.005, 0.005, 0.005, 0.005, 0.005;
// 	V6<<0.0, 0.0, 0.005, 0.0, 0.0, 0.0;
// 	V6<<0.01, 0.0, 0.0, 0.0, 0.0, 0.0;
// 	T_FG = Sophus::SE3::exp(T_FG.log()+V6);
// 	V6<<0.0, 0.0, 0.01, 0.0, 0.0, 0.0;
	T_LG = Sophus::SE3::exp(T_LG.log()+V6*2);
// 	V6<<0.0, 0.0, 0.0, 0.01, 0.0, 0.0;
// 	T_BG = Sophus::SE3::exp(T_BG.log()+V6);
// 	V6<<0.01, 0.0, 0.0, 0.0, 0.0, 0.01;
	V6<<0.01, 0.01, -0.01, 0.01, -0.01, -0.01;
	T_RG = Sophus::SE3::exp(T_RG.log()+V6*2);


	// Eigen::Matrix<double,6,1>  V6;
	// V6<<0.01, -0.01, 0.01, -0.01, 0.01, -0.01;
	// T_FG = Sophus::SE3::exp(T_FG.log()+V6);
	// T_LG = Sophus::SE3::exp(T_LG.log()+V6);
	// T_BG = Sophus::SE3::exp(T_BG.log()+V6);
	// T_RG = Sophus::SE3::exp(T_RG.log()+V6);
	
	Sophus::SE3 T_GF = T_FG.inverse();
	Sophus::SE3 T_GL = T_LG.inverse();
	Sophus::SE3 T_GB = T_BG.inverse();
	Sophus::SE3 T_GR = T_RG.inverse();
	
	cout<<"--------------------Project images on the ground--------------------------"<<endl;
	cv::Mat img_GF = project_on_ground(img_F,T_FG,K_F,D_F,K_G,rows,cols);
	cv::Mat img_GL = project_on_ground(img_L,T_LG,K_L,D_L,K_G,rows,cols);
	cv::Mat img_GB = project_on_ground(img_B,T_BG,K_B,D_B,K_G,rows,cols);
	cv::Mat img_GR = project_on_ground(img_R,T_RG,K_R,D_R,K_G,rows,cols);
	
	cout<<"--------------------Stitch the surround view image--------------------------"<<endl;
	cv::Mat img_G = generate_surround_view(img_GF,img_GL,img_GB,img_GR,rows,cols);
	
	// cv::imshow("const cv::String &winname", img_G);
	// cv::waitKey(0);

	int overlap_x,overlap_y,overlap_w,overlap_h;
	overlap_x = 650;
	overlap_y = 0;
	overlap_w = 350;
	overlap_h = 350;
	cv::Rect rectFR(overlap_x,overlap_y,overlap_w,overlap_h);
	cv::Rect rectFL(overlap_x,overlap_y,overlap_w,overlap_h);



	//--------------------------- ROI_F ----------------------------
	int ROI_FL_x = 200;
	int ROI_FL_y = 0;
	int ROI_FL_w = 200;
	int ROI_FL_h = 200;
	
	int ROI_FR_x = 650;
	int ROI_FR_y = 0;
	int ROI_FR_w = 200;
	int ROI_FR_h = 200;
	
	
	//--------------------------- ROI_L ----------------------------
	int ROI_LF_x = 200;
	int ROI_LF_y = 0;
	int ROI_LF_w = 200;
	int ROI_LF_h = 200;
	
	int ROI_LB_x = 200;
	int ROI_LB_y = 800;
	int ROI_LB_w = 200;
	int ROI_LB_h = 200;
	
	
	//--------------------------- ROI_B ----------------------------
	int ROI_BL_x = 200;
	int ROI_BL_y = 800;
	int ROI_BL_w = 200;
	int ROI_BL_h = 200;
	
	int ROI_BR_x = 650;
	int ROI_BR_y = 800;
	int ROI_BR_w = 200;
	int ROI_BR_h = 200;
	
	
	//--------------------------- ROI_R ----------------------------
	int ROI_RF_x = 650;
	int ROI_RF_y = 0;
	int ROI_RF_w = 200;
	int ROI_RF_h = 200;
	
	int ROI_RB_x = 650;
	int ROI_RB_y = 800;
	int ROI_RB_w = 200;
	int ROI_RB_h = 200;
	


	cv::Rect ROI_FL(ROI_FL_x,ROI_FL_y,ROI_FL_w,ROI_FL_h);
	cv::Rect ROI_LB(ROI_LB_x,ROI_LB_y,ROI_LB_w,ROI_LB_h);
	cv::Rect ROI_BR(ROI_BR_x,ROI_BR_y,ROI_BR_w,ROI_BR_h);
	cv::Rect ROI_RF(ROI_RF_x,ROI_RF_y,ROI_RF_w,ROI_RF_h);






	
	// update T_FG
	Eigen::Matrix<double,6,1> rhophi_F,rhophi_R;
	Eigen::Matrix<double,6,1> rhophi_BR;

	Eigen::Matrix<double,6,1> rhophi_B,rhophi_L;
	Eigen::Matrix<double,6,1> rhophi_BL;

	double lr = 2e-9;
	int iter_times = 100;
	double nDecay = 0.95;

	double nTotalSecond = 0.0;
	
	for(int i=0;i<iter_times;i++)
	{
		cout<<"iter "<<i<<": "<<endl;
		
		// cv::namedWindow("img_GF",0);
		// cv::imshow("img_GF",img_GF(rectFR));
		// cv::namedWindow("img_GL",0);
		// cv::imshow("img_GL",img_GR(rectFR));
		
// 		adjust_pose(img_GF,img_GL,rhophi_F,rhophi_L,K_G,
// 				overlap_x, overlap_y, overlap_w,overlap_h,lr);



		double nTotalError = CalculatePhotometricError(img_GL , img_GF , cv::Rect(ROI_LF_x,ROI_LF_y,ROI_LF_w,ROI_LF_h));
		nTotalError += CalculatePhotometricError(img_GL , img_GB , cv::Rect(ROI_LB_x,ROI_LB_y,ROI_LB_w,ROI_LB_h));
		nTotalError += CalculatePhotometricError(img_GR , img_GF , cv::Rect(ROI_RF_x,ROI_RF_y,ROI_RF_w,ROI_RF_h));
		nTotalError += CalculatePhotometricError(img_GR , img_GB , cv::Rect(ROI_RB_x,ROI_RB_y,ROI_RB_w,ROI_RB_h));
		cout << endl << endl;
		cout << "------------------------------------------" << endl;
		cout << "Iteration is " << i << endl;
		cout << "Photometric Error is " << nTotalError << endl;
		fOutFile << "Iteration is " << i << endl;
		fOutFile << "Photometric Error is " << nTotalError << endl;
		cout << "------------------------------------------" << endl;
		cout << endl << endl;


		time_t tBegin , tEnd;
		tBegin = clock();
		adjust_pose(img_GF,img_GR,rhophi_F,rhophi_R,K_G,
				overlap_x, overlap_y, overlap_w,overlap_h,lr);

		adjust_pose(img_GB,img_GR,rhophi_F,rhophi_BR,K_G,
				overlap_x, overlap_y, overlap_w,overlap_h,lr);
		tEnd = clock();

		// cout << "Duration: " << (double)(tEnd-tBegin)/(CLOCKS_PER_SEC) << endl;
		nTotalSecond += (double)(tEnd-tBegin)/(CLOCKS_PER_SEC);

		// cout<<"rhophi_F: "<<endl<<rhophi_F<<endl;
		// cout<<"rhophi_R: "<<endl<<rhophi_R<<endl;
		
// 		T_GF = Sophus::SE3::exp(T_GF.log() - rhophi_F);
		// T_GF = Sophus::SE3::exp(rhophi_F).inverse()*T_GF;
		// T_FG = T_GF.inverse();
		
		
		T_GR = Sophus::SE3::exp(T_GR.log()-rhophi_R - rhophi_BR);
		T_RG = T_GR.inverse();



		adjust_pose(img_GF,img_GL,rhophi_F,rhophi_L,K_G,
				ROI_FL_x, ROI_FL_y, ROI_FL_w,ROI_FL_h,lr);

		adjust_pose(img_GB,img_GL,rhophi_B,rhophi_BL,K_G,
				ROI_BL_x, ROI_BL_y, ROI_BL_w,ROI_BL_h,lr);


		T_GL = Sophus::SE3::exp(T_GL.log()-rhophi_L - rhophi_BL);
		T_LG = T_GL.inverse();

		
		cout<<T_FG<<endl;
		cout<<T_RG<<endl;
		
		img_GF = project_on_ground(img_F,T_FG,K_F,D_F,K_G,rows,cols);
		img_GR = project_on_ground(img_R,T_RG,K_R,D_R,K_G,rows,cols);

		cv::Mat img_G = generate_surround_view(img_GF,img_GL,img_GB,img_GR,rows,cols);
	
		// cv::imshow("const cv::String &winname", img_G);
		// cv::waitKey(0);
		
		lr *= nDecay;
		// cv::waitKey(0);
	}
		

	
	fOutFile << "LastPose:" << endl;
	fOutFile << "FG: " << endl << T_FG.matrix()<<endl;
	fOutFile << "LG: " << endl << T_LG.matrix()<<endl;
	fOutFile << "BG: " << endl << T_BG.matrix()<<endl;
	fOutFile << "RG: " << endl << T_RG.matrix()<<endl;



	nTotalSecond /=(double)iter_times;

	cout << endl << endl  << endl;
	cout << "Average time is: " << nTotalSecond << endl;
	cout << endl << endl  << endl;

	T_GF = Sophus::SE3::exp(T_GF.log() - rhophi_F);
// 	T_GF = Sophus::SE3::exp(rhophi_F).inverse()*T_GF;
	T_FG = T_GF.inverse();
	
	// project img_GF with new T_FG
	img_GF = project_on_ground(img_F,T_FG,K_F,D_F,K_G,rows,cols);
	
	// Show new diff between img_GF and img_GL
	cv::Mat img_GF_gray,img_GL_gray;
	cv::cvtColor(img_GF(rectFL),img_GF_gray,cv::COLOR_BGR2GRAY);
	cv::medianBlur(img_GF_gray,img_GF_gray,5);
	img_GF_gray.convertTo(img_GF_gray, CV_64FC1);
	cv::cvtColor(img_GL(rectFL),img_GL_gray,cv::COLOR_BGR2GRAY);
	cv::medianBlur(img_GL_gray,img_GL_gray,5);
	img_GL_gray.convertTo(img_GL_gray, CV_64FC1);
	
	cv::Mat diff_FL,diff_FL_norm,diff_FL_color;
	cv::subtract(img_GF_gray,img_GL_gray,diff_FL,cv::noArray(),CV_64FC1);
	double coef = cv::mean(img_GF_gray).val[0]/cv::mean(img_GL_gray).val[0] ;
	cv::subtract(img_GF_gray,coef*img_GL_gray,diff_FL,cv::noArray(),CV_64FC1);
	cv::normalize(diff_FL,diff_FL_norm,0,255,cv::NORM_MINMAX,CV_8U);
	cv::applyColorMap(diff_FL_norm,diff_FL_color, cv::COLORMAP_JET);
	cv::namedWindow("diff_FL2",0);
	cv::imshow("diff_FL2",diff_FL_color);
	
	img_GF_gray.convertTo(img_GF_gray, CV_8U);
	cv::namedWindow("img_GF2",0);
	cv::imshow("img_GF2",img_GF_gray);
	
// 	cout<<multi_GF_x<<endl;
// 	cout<<multi_GF_x_norm<<endl;
	cv::waitKey(0);
	cv::destroyAllWindows();
	
	
// 	cv::Mat media_GF;
// // 	media_GF = img_GF_gray;
// 	cv::medianBlur(img_GF_gray,media_GF,3);
// 	cv::namedWindow("image0",CV_GUI_EXPANDED|CV_WINDOW_NORMAL);
// 	cv::imshow("image0",media_GF);
// 	
// 	cv::Mat grad_GF_x,grad_GF_x_norm,grad_GF_x_color;
// // 	cv::Sobel(media_GF, grad_GF_x, CV_64FC1, 1, 0, 7, 1, 0, cv::BORDER_DEFAULT);
// 	cv::Scharr(media_GF, grad_GF_x, CV_64FC1, 1, 0, 1, 0, cv::BORDER_DEFAULT);
// 	cv::normalize(grad_GF_x,grad_GF_x_norm,0,255,cv::NORM_MINMAX,CV_8U);
// 	cv::applyColorMap(grad_GF_x_norm,grad_GF_x_color, cv::COLORMAP_JET);
// 	
// 	cv::Mat grad_GF_y,grad_GF_y_norm,grad_GF_y_color;
// // 	cv::Sobel(media_GF, grad_GF_y, CV_64FC1, 0, 1, 7, 1, 0, cv::BORDER_DEFAULT);
// 	cv::Scharr(media_GF, grad_GF_y, CV_64FC1, 0, 1, 1, 0, cv::BORDER_DEFAULT);
// 	cv::normalize(grad_GF_y,grad_GF_y_norm,0,255,cv::NORM_MINMAX,CV_8U);
// 	cv::applyColorMap(grad_GF_y_norm,grad_GF_y_color, cv::COLORMAP_JET);
// 	
// 	cv::Mat grad_GF_xy,grad_GF_xy_norm,grad_GF_xy_color;
// 	cv::Mat pow_GF_x,pow_GF_y;
// 	cv::pow(grad_GF_x,2,pow_GF_x);
// 	cv::pow(grad_GF_y,2,pow_GF_y);
// 	cv::sqrt(pow_GF_x+pow_GF_y,grad_GF_xy);
// // 	cv::addWeighted(grad_GF_x, 0.5, grad_GF_y, 0.5, 0, grad_GF_xy);
// 	cv::normalize(grad_GF_xy,grad_GF_xy_norm,0,255,cv::NORM_MINMAX,CV_8U);
// 	cv::applyColorMap(grad_GF_xy_norm,grad_GF_xy_color, cv::COLORMAP_JET);
// 	
// 	cv::namedWindow("image1",0);
// 	cv::imshow("image1",grad_GF_x_color);
// 	cv::namedWindow("image2",0);
// 	cv::imshow("image2",grad_GF_y_color);
// 	cv::namedWindow("image3",0);
// 	cv::imshow("image3",grad_GF_xy_color);
// 	
// // 	cout<<img_GF_gray<<endl;
// 	cv::waitKey(0);
// 	cv::destroyAllWindows();
	
// 	cout<<"test"<<endl;
// 	cv::namedWindow("image4",0);
// 	cv::imshow("image4",img_GF(rect));
// 	cv::namedWindow("image5",0);
// 	cv::imshow("image5",img_GL(rect));
// 	cv::namedWindow("image6",0);
// 	cv::Mat absdiff_FL;
// 	cv::absdiff(img_GF(rect),img_GL(rect),absdiff_FL);
// 	cv::imshow("image6",absdiff_FL);
// 	cv::waitKey(0);
// 	cv::destroyAllWindows();
	return 0;
}