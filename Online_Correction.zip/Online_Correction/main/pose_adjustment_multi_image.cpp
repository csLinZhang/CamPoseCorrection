#include <iostream>
#include <cmath>
#include <string>
#include <vector>
#include <algorithm>
#include <boost/format.hpp>
#include <typeinfo>
#include <Eigen/Core>
#include <Eigen/Geometry>
#include "sophus/se3.h"
#include "sophus/so3.h"
#include <g2o/core/base_binary_edge.h>
// #include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/opencv.hpp>
#include <opencv2/core/eigen.hpp>
#include <fstream>

#include "initializer.h"
#include "surroundview.h"

#include <time.h>

using namespace std; 


double CalculatePhotometricError(cv::Mat & mImage_1 , cv::Mat & mImage_2 , cv::Rect iROI){
	cv::Mat mGrayImage_1 , mGrayImage_2;
	cv::cvtColor(mImage_1(iROI),mGrayImage_1,cv::COLOR_BGR2GRAY);
	cv::cvtColor(mImage_2(iROI),mGrayImage_2,cv::COLOR_BGR2GRAY);	
	mGrayImage_1.convertTo(mGrayImage_1, CV_64FC1);
	mGrayImage_2.convertTo(mGrayImage_2, CV_64FC1);

	cv::Mat mDiff;
	cv::subtract(mGrayImage_1, mGrayImage_2, mDiff);

	return cv::norm(mDiff , cv::NORM_L2);
}


double average_diff(cv::Mat diff, double threshold)
{
	int cnt=0;
	double sum=0;
	double avg;
	double temp;
	for(int i=0;i<150;i++)
	{
		for(int j=0;j<150;j++)
		{
			temp = abs(diff.at<double>(i,j));
			if(temp>threshold)
			{
				sum += temp;
				cnt++;
			}
		}
	}
	
	if(cnt==0)
	{
		avg = 0;
	}
	else
	{
		avg = sum/(150*150);
	}
	
	return avg;
}

int main(int argc, char** argv)
{

	ofstream fOutFile("photometric_error_v2.txt");
	cout<<"------------------Initialize camera pose----------------"<<endl;
	Sophus::SE3 T_FG;
	Sophus::SE3 T_LG;
	Sophus::SE3 T_BG;
	Sophus::SE3 T_RG;
	initializePose(T_FG, T_LG, T_BG, T_RG);

	cout<<"---------------Initialize K-------------------------------"<<endl;
	Eigen::Matrix3d K_F;
	Eigen::Matrix3d K_L;
	Eigen::Matrix3d K_B;
	Eigen::Matrix3d K_R;
	initializeK(K_F, K_L, K_B, K_R);
	
	cout<<"--------------------Initialize D--------------------------"<<endl;
	Eigen::Vector4d D_F;
	Eigen::Vector4d D_L;
	Eigen::Vector4d D_B; 
	Eigen::Vector4d D_R;
	initializeD(D_F, D_L, D_B, D_R);
	
	cout<<"--------------------Load images--------------------------"<<endl;
	// 1430_, 3322, 2391, 1599, 596_, 1363, 626, 281, 333, 1377_, 1401_, 1403_, 1440, 1829, 3071
	vector<int> gImageIndex = {1022 , 1376 , 1429 , 1430};
	int nImageNum = gImageIndex.size();
	vector<cv::Mat> gImagesFront, gImagesLeft, gImagesBack, gImagesRight;
	vector<cv::Mat> gImages_GF, gImages_GL, gImages_GB, gImages_GR;
	for (auto nImageIndex : gImageIndex){
		boost::format img_path_template("/home/kyrie/Documents/Data/1216/%06d ");
		cv::Mat img_F = cv::imread((img_path_template%nImageIndex).str()+ "F.jpg");
		cv::Mat img_L = cv::imread((img_path_template%nImageIndex).str()+ "L.jpg");
		cv::Mat img_B = cv::imread((img_path_template%nImageIndex).str()+ "B.jpg");
		cv::Mat img_R = cv::imread((img_path_template%nImageIndex).str()+ "R.jpg");
		
		gImagesFront.push_back(img_F);
		gImagesLeft.push_back(img_L);
		gImagesBack.push_back(img_B);
		gImagesRight.push_back(img_R);	
	}


	//Initialize K_G
	int rows = 1000;
	int cols = 1000;
	double dX = 0.1;
	double dY = 0.1;

	cv::Mat K_G = cv::Mat::zeros(3,3,CV_64FC1);
	K_G.at<double>(0,0) = 1/dX;
	K_G.at<double>(1,1) = -1/dY;
	K_G.at<double>(0,2) = cols/2;
	K_G.at<double>(1,2) = rows/2;
	K_G.at<double>(2,2) =   1.0;
	
	//Add noise to the pose.
	Eigen::Matrix<double,6,1>  V6;
	V6<<0.01, -0.01, 0.01, -0.01, 0.01, -0.01;
	T_LG = Sophus::SE3::exp(T_LG.log()+V6*2);
	V6<<0.01, 0.01, -0.01, 0.01, -0.01, -0.01;
	T_RG = Sophus::SE3::exp(T_RG.log()+V6*2);
	
	Sophus::SE3 T_GF = T_FG.inverse();
	Sophus::SE3 T_GL = T_LG.inverse();
	Sophus::SE3 T_GB = T_BG.inverse();
	Sophus::SE3 T_GR = T_RG.inverse();
	
	//Generate the surround-view of all pairs.
	for (int i=0;i<nImageNum;i++){
		cv::Mat img_GF = project_on_ground(gImagesFront[i],T_FG,K_F,D_F,K_G,rows,cols);
		cv::Mat img_GL = project_on_ground(gImagesLeft[i],T_LG,K_L,D_L,K_G,rows,cols);
		cv::Mat img_GB = project_on_ground(gImagesBack[i],T_BG,K_B,D_B,K_G,rows,cols);
		cv::Mat img_GR = project_on_ground(gImagesRight[i],T_RG,K_R,D_R,K_G,rows,cols);
		gImages_GF.push_back(img_GF);
		gImages_GL.push_back(img_GL);
		gImages_GB.push_back(img_GB);
		gImages_GR.push_back(img_GR);
	}
	
	//Use the last image to generate the surround-view image.
	cv::Mat img_G = generate_surround_view(	gImages_GF[gImages_GF.size()-1],
											gImages_GL[gImages_GL.size()-1],
											gImages_GB[gImages_GB.size()-1],
											gImages_GR[gImages_GR.size()-1], rows, cols);
	cv::imwrite("before.jpg",img_G);

	//--------------------------- ROI_F ----------------------------
	int ROI_FL_x = 200;
	int ROI_FL_y = 0;
	int ROI_FL_w = 200;
	int ROI_FL_h = 200;
	
	int ROI_FR_x = 650;
	int ROI_FR_y = 0;
	int ROI_FR_w = 200;
	int ROI_FR_h = 200;
	
	
	//--------------------------- ROI_L ----------------------------
	int ROI_LF_x = 200;
	int ROI_LF_y = 0;
	int ROI_LF_w = 200;
	int ROI_LF_h = 200;
	
	int ROI_LB_x = 200;
	int ROI_LB_y = 800;
	int ROI_LB_w = 200;
	int ROI_LB_h = 200;
	
	
	//--------------------------- ROI_B ----------------------------
	int ROI_BL_x = 200;
	int ROI_BL_y = 800;
	int ROI_BL_w = 200;
	int ROI_BL_h = 200;
	
	int ROI_BR_x = 650;
	int ROI_BR_y = 800;
	int ROI_BR_w = 200;
	int ROI_BR_h = 200;
	
	
	//--------------------------- ROI_R ----------------------------
	int ROI_RF_x = 650;
	int ROI_RF_y = 0;
	int ROI_RF_w = 200;
	int ROI_RF_h = 200;
	
	int ROI_RB_x = 650;
	int ROI_RB_y = 800;
	int ROI_RB_w = 200;
	int ROI_RB_h = 200;
	


	cv::Rect ROI_FL(ROI_FL_x,ROI_FL_y,ROI_FL_w,ROI_FL_h);
	cv::Rect ROI_LB(ROI_LB_x,ROI_LB_y,ROI_LB_w,ROI_LB_h);
	cv::Rect ROI_BR(ROI_BR_x,ROI_BR_y,ROI_BR_w,ROI_BR_h);
	cv::Rect ROI_RF(ROI_RF_x,ROI_RF_y,ROI_RF_w,ROI_RF_h);


	//Hyper params.
	double rate = 5e-11;
	double decay = 0.95;
	double threshold = 70000;
	int iter_max = 100;



	double nTotalTime = 0.0;
	
	for(int iter=0; iter<iter_max; iter++)
	{ 
		vector<Sophus::SE3> gRhophi_L , gRhophi_R;

		for (int nImageIndex=0; nImageIndex<nImageNum; nImageIndex++){
			//Capture the images.
			cv::Mat img_F = gImagesFront[nImageIndex];
			cv::Mat img_L = gImagesLeft[nImageIndex];
			cv::Mat img_B = gImagesBack[nImageIndex];
			cv::Mat img_R = gImagesRight[nImageIndex];
			//Capture the birds-eye images.
			cv::Mat mImage_GF = gImages_GF[nImageIndex];
			cv::Mat mImage_GL = gImages_GL[nImageIndex];
			cv::Mat mImage_GB = gImages_GB[nImageIndex];
			cv::Mat mImage_GR = gImages_GR[nImageIndex];
			
			//Convert image to gray image.						
			cv::Mat img_GF_gray, img_GL_gray, img_GB_gray, img_GR_gray;
			cv::cvtColor(mImage_GF,img_GF_gray,cv::COLOR_BGR2GRAY);
			cv::cvtColor(mImage_GL,img_GL_gray,cv::COLOR_BGR2GRAY);
			cv::cvtColor(mImage_GB,img_GB_gray,cv::COLOR_BGR2GRAY);
			cv::cvtColor(mImage_GR,img_GR_gray,cv::COLOR_BGR2GRAY);
			img_GF_gray.convertTo(img_GF_gray, CV_64FC1);
			img_GL_gray.convertTo(img_GL_gray, CV_64FC1);
			img_GB_gray.convertTo(img_GB_gray, CV_64FC1);
			img_GR_gray.convertTo(img_GR_gray, CV_64FC1);

			//Adjust left camera pose
			Sophus::SE3 rhophi_L_LB_SE3;
			adjust_pose_V2(img_L,img_B,"L","B",
						rhophi_L_LB_SE3,
						K_L, K_B, 
						D_L, D_B,
						T_LG, T_BG, 
						K_G,
						ROI_LB_x,ROI_LB_y,ROI_LB_w,ROI_LB_h,
						threshold, rate
					);

			Sophus::SE3 rhophi_L_LF_SE3;
			adjust_pose_V2(img_L,img_F,"L","F",
					rhophi_L_LF_SE3,
					K_L, K_F, 
					D_L, D_F,
					T_LG, T_FG, 
					K_G,
					ROI_LF_x,ROI_LF_y,ROI_LF_w,ROI_LF_h,
					threshold, rate
					);
			gRhophi_L.push_back(rhophi_L_LB_SE3);
			gRhophi_L.push_back(rhophi_L_LF_SE3);

			//Adjust right camera pose
			Sophus::SE3 rhophi_R_RF_SE3;
			adjust_pose_V2(img_R,img_F,"R","F",
						rhophi_R_RF_SE3,
						K_R, K_F, 
						D_R, D_F,
						T_RG, T_FG, 
						K_G,
						ROI_RF_x,ROI_RF_y,ROI_RF_w,ROI_RF_h,
						threshold, rate
						);

			Sophus::SE3 rhophi_R_RB_SE3;
			adjust_pose_V2(img_R,img_B,"R","B",
						rhophi_R_RB_SE3,
						K_R, K_B, 
						D_R, D_B,
						T_RG, T_BG, 
						K_G,
						ROI_RB_x,ROI_RB_y,ROI_RB_w,ROI_RB_h,
						threshold, rate
						);
			gRhophi_R.push_back(rhophi_R_RF_SE3);
			gRhophi_R.push_back(rhophi_R_RB_SE3);
		}

		//Update the pose matrix.
		for (auto mRhophi : gRhophi_L){
			cout << "Left Rhophi: " << endl << mRhophi << endl;
			T_LG = Sophus::SE3::exp(T_LG.log() - mRhophi.log());
		}
		T_GL = T_LG.inverse();

		for (auto mRhophi : gRhophi_R){
			cout << "Right Rhophi: " << endl << mRhophi << endl;
			T_RG = Sophus::SE3::exp(T_RG.log() - mRhophi.log());
		}
		T_GR = T_RG.inverse();


		//Decay the learning rate.
		cout<<rate<<endl;
		rate *= decay;
	
		//Generate the surround-view of again.
		for (int i=0;i<nImageNum;i++){
			cv::Mat img_GF = project_on_ground(gImagesFront[i],T_FG,K_F,D_F,K_G,rows,cols);
			cv::Mat img_GL = project_on_ground(gImagesLeft[i],T_LG,K_L,D_L,K_G,rows,cols);
			cv::Mat img_GB = project_on_ground(gImagesBack[i],T_BG,K_B,D_B,K_G,rows,cols);
			cv::Mat img_GR = project_on_ground(gImagesRight[i],T_RG,K_R,D_R,K_G,rows,cols);
			gImages_GF.push_back(img_GF);
			gImages_GL.push_back(img_GL);
			gImages_GB.push_back(img_GB);
			gImages_GR.push_back(img_GR);
		}
		
		//Use the last image to generate the surround-view image.
		cv::Mat img_G = generate_surround_view(	gImages_GF[gImages_GF.size()-1],
												gImages_GL[gImages_GL.size()-1],
												gImages_GB[gImages_GB.size()-1],
												gImages_GR[gImages_GR.size()-1], rows, cols);


		boost::format surroundview_template("./surround_view_iter%02d.png");
		cv::imwrite((surroundview_template%iter).str(),img_G);
	} 

	
	return 0;
}