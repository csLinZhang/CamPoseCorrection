//OpenCV
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <opencv2/calib3d/calib3d.hpp>

//Eigen and Sophus
#include <Eigen/Core>
#include <Eigen/Geometry>
#include "sophus/se3.h"
#include "sophus/so3.h"
#include <g2o/core/base_binary_edge.h>

//Standard
#include <iostream>
#include <vector>
#include <string>


#include "initializer.h"
#include "surroundview.h"

using namespace std;

string aFileName_Front = "./img/front.jpg";
string aFileName_Left = "./img/left.jpg";
string aFileName_Back = "./img/back.jpg";
string aFileName_Right = "./img/right.jpg";





void InitializePose(	Sophus::SE3 & T_FG, Sophus::SE3 & T_LG,
					 	Sophus::SE3 & T_BG, Sophus::SE3 & T_RG){

	//Front

	Eigen::Matrix3d R_FG = Eigen::Matrix3d();
	R_FG<< 0.9942216397551481, 0.05460715718346894, -0.09241963766929792,
          -0.05904013579647753, -0.4408689433014166, -0.8956276219486677,
          -0.08965262632917056, 0.895908830862065, -0.4350974297506823;

	Eigen::Vector3d t_FG;
	t_FG<< -0.003749144640556696,
		   1.376113393712053,
           -0.6931823004198616;
	T_FG = Sophus::SE3(R_FG,t_FG);


	//Left

	Eigen::Matrix3d R_LG = Eigen::Matrix3d();
	R_LG<<  0.01654727138455159, 0.9864353033641047, 0.163314359707567,
			0.6565911321133691, 0.1124630493017207, -0.7458150895308051,
			-0.7540651649823177, 0.1195719650199213, -0.6458237159949025;

	Eigen::Vector3d t_LG;
	t_LG<< -0.4692415681772258,
		   1.583766706660984,
           0.2258009350449484;

	T_LG = Sophus::SE3(R_LG,t_LG);


	//Back

	Eigen::Matrix3d R_BG = Eigen::Matrix3d();
	R_BG<<  -0.9987462346085392, 0.03439951387441775, -0.03636801204999285,
			0.04955255761421019, 0.5762249706515277, -0.815787550304328,
			-0.007106538479109463, -0.8165668721193934, -0.5772071036187922;

	Eigen::Vector3d t_BG;
	t_BG<< 0.1562355700913949,
		   2.243699100754701,
           -1.68392796251224;

	T_BG = Sophus::SE3(R_BG,t_BG);


	//Right

	Eigen::Matrix3d R_RG = Eigen::Matrix3d();
	R_RG<<  -0.14515064193316, -0.9767534917215429, -0.1577463392797612,
			-0.6762791236923301, 0.2143208323615997, -0.7047787792447822,
			0.7222034602550211, 0.004381463865540836, -0.691666801841804;

	Eigen::Vector3d t_RG;
	t_RG<< 0.6143734494273984,
		   1.538734291406114,
           0.3059289599719182;

	T_RG = Sophus::SE3(R_RG,t_RG);

}






void InitializeK(Eigen::Matrix3d& K_F, Eigen::Matrix3d& K_L,
				 Eigen::Matrix3d& K_B, Eigen::Matrix3d& K_R)
{
	K_F<< 	421.0385454600986, 0, 626.0185998540047,
			 0, 419.8146418676837, 533.4062781277287,
			 0, 0, 1;

	K_L<<   421.5278326114641, 0, 641.479047813513,
			0, 420.4369218355255, 538.0269741562448,
			0, 0, 1;

	K_B<<	421.5415522530467, 0, 632.6681720041742,
			 0, 420.3025315147982, 546.6392474790547,
			 0, 0, 1;

	K_R<<  	 419.4510522923914, 0, 641.7209580545031,
			 0, 418.3638205107267, 536.1898218246798,
			 0, 0, 1;
	return;
}

void InitializeD(Eigen::Vector4d& D_F, Eigen::Vector4d& D_L,
				 Eigen::Vector4d& D_B, Eigen::Vector4d& D_R)
{
	D_F<<	-0.06797563338426547,
		 	0.001441436228846391,
		 	-0.001693573472841505,
		 	0.0001830382799875705;
	
	D_L<<	-0.06808589996877272,
 			0.00186297403704037,
 			-0.002435542897235262,
 			0.0003573323190116279;

	D_B<<	 -0.06399656643720152,
			 -0.003146722153825719,
			 0.0006366806461468147,
			 -0.0003290015917772795;


	D_R<<	-0.06750666968031235,
			 0.001168848478533924,
			 -0.001130867113212834,
			 -0.0001779884252049247;
	return;
}



double CalculatePhotometricError(cv::Mat & mImage_1 , cv::Mat & mImage_2 , cv::Rect iROI){
	cv::Mat mGrayImage_1 , mGrayImage_2;
	cv::cvtColor(mImage_1(iROI),mGrayImage_1,cv::COLOR_BGR2GRAY);
	cv::cvtColor(mImage_2(iROI),mGrayImage_2,cv::COLOR_BGR2GRAY);	
	mGrayImage_1.convertTo(mGrayImage_1, CV_64FC1);
	mGrayImage_2.convertTo(mGrayImage_2, CV_64FC1);

	cv::Mat mDiff;
	cv::subtract(mGrayImage_1, mGrayImage_2, mDiff);

	return cv::norm(mDiff , cv::NORM_L2);
}



int main(){


	cout<<"------------------Initialize camera pose----------------"<<endl;
	Sophus::SE3 T_FG;
	Sophus::SE3 T_LG;
	Sophus::SE3 T_BG;
	Sophus::SE3 T_RG;
	InitializePose(T_FG, T_LG, T_BG, T_RG);
	cout<<T_FG.matrix()<<endl;

	cout<<"---------------Initialize K-------------------------------"<<endl;
	Eigen::Matrix3d K_F;
	Eigen::Matrix3d K_L;
	Eigen::Matrix3d K_B;
	Eigen::Matrix3d K_R;
	InitializeK(K_F, K_L, K_B, K_R);
	cout<<K_F<<endl;
	
	cout<<"--------------------Initialize D--------------------------"<<endl;
	Eigen::Vector4d D_F;
	Eigen::Vector4d D_L;
	Eigen::Vector4d D_B; 
	Eigen::Vector4d D_R;
	InitializeD(D_F, D_L, D_B, D_R);
	cout<<D_F<<endl;




	//Load images.
	cv::Mat mImage_Front = cv::imread(aFileName_Front);
	cv::Mat mImage_Left = cv::imread(aFileName_Left);
	cv::Mat mImage_Back = cv::imread(aFileName_Back);
	cv::Mat mImage_Right = cv::imread(aFileName_Right);

	cout<<"--------------------Init K_G--------------------------"<<endl;
	int rows = 1000;
	int cols = 1000;
	double dX = 0.01;
	double dY = 0.01;
	double fx =  1/dX;
	double fy = -1/dY;
	cv::Mat K_G = cv::Mat::zeros(3,3,CV_64FC1);
	K_G.at<double>(0,0) = fx;
	K_G.at<double>(1,1) = fy;
	K_G.at<double>(0,2) = cols/2;
	K_G.at<double>(1,2) = rows/2;
	K_G.at<double>(2,2) =   1.0;


	Sophus::SE3 T_GF = T_FG.inverse();
	Sophus::SE3 T_GL = T_LG.inverse();
	Sophus::SE3 T_GB = T_BG.inverse();
	Sophus::SE3 T_GR = T_RG.inverse();
	
	cout<<"--------------------Project images on the ground--------------------------"<<endl;
	cv::Mat img_GF = project_on_ground(mImage_Front,T_FG,K_F,D_F,K_G,rows,cols);
	cv::Mat img_GL = project_on_ground(mImage_Left,T_LG,K_L,D_L,K_G,rows,cols);
	cv::Mat img_GB = project_on_ground(mImage_Back,T_BG,K_B,D_B,K_G,rows,cols);
	cv::Mat img_GR = project_on_ground(mImage_Right,T_RG,K_R,D_R,K_G,rows,cols);
	

	// PhotometricAlignment(img_GF , img_GL , img_GB , img_GR,
	// 					1 , 1 , 1);


	cout<<"--------------------Stitch the surround view image--------------------------"<<endl;
	cv::Mat img_G = generate_surround_view(img_GF,img_GL,img_GB,img_GR,rows,cols);
	


	cv::imshow("const cv::String &winname", img_G);
	cv::waitKey(0);
	//--------------------------- ROI_F ----------------------------
	int ROI_FL_x = 320;
	int ROI_FL_y = 150;
	int ROI_FL_w = 100;
	int ROI_FL_h = 200;
	
	int ROI_FR_x = 700;
	int ROI_FR_y = 100;
	int ROI_FR_w = 200;
	int ROI_FR_h = 250;
	
	
	//--------------------------- ROI_L ----------------------------

	int ROI_LF_x = 320;
	int ROI_LF_y = 150;
	int ROI_LF_w = 100;
	int ROI_LF_h = 250;
	
	int ROI_LB_x = 100;
	int ROI_LB_y = 750;
	int ROI_LB_w = 200;
	int ROI_LB_h = 250;
	
	
	//--------------------------- ROI_B ----------------------------
	int ROI_BL_x = 100;
	int ROI_BL_y = 750;
	int ROI_BL_w = 100;
	int ROI_BL_h = 150;
	
	int ROI_BR_x = 600;
	int ROI_BR_y = 600;
	int ROI_BR_w = 200;
	int ROI_BR_h = 200;
	
	
	//--------------------------- ROI_R ----------------------------
	int ROI_RF_x = 700;
	int ROI_RF_y = 100;
	int ROI_RF_w = 200;
	int ROI_RF_h = 200;
	
	int ROI_RB_x = 600;
	int ROI_RB_y = 600;
	int ROI_RB_w = 200;
	int ROI_RB_h = 150;
	
	cv::Rect ROI_FL(ROI_FL_x,ROI_FL_y,ROI_FL_w,ROI_FL_h);
	cv::Rect ROI_LB(250,750,150,150);
	cv::Rect ROI_BR(600,750,150,150);
	cv::Rect ROI_RF(650,0,150,150);
	

	return 0;
}