#include "surroundview.h"

#include <cstdlib>

using namespace std;

cv::Mat eigen2mat(Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> A)
{
	cv::Mat B;
	cv::eigen2cv(A,B);
	
	return B;
}

void imshow_64F(cv::Mat img,string img_name)
{
	cv::Mat img_norm,img_color;
	cv::normalize(img,img_norm,0,255,cv::NORM_MINMAX,CV_8U);
	cv::applyColorMap(img_norm,img_color, cv::COLORMAP_JET);
	cv::namedWindow(img_name,0);
	cv::imshow(img_name,img_color);
	
	return;
}

void imshow_64F_gray(cv::Mat img,string img_name)
{
	cv::Mat img_8U;
	img.convertTo(img_8U,CV_8U);
	cv::namedWindow(img_name,0);
	cv::imshow(img_name,img_8U);
	
	return;
}

cv::Mat bilinear_interpolation(cv::Mat img,cv::Mat pix_table,int rows, int cols)
{
	cv::Mat img_G(rows,cols,CV_8UC3);
	// f is float
	cv::Mat img_G_f(rows,cols,CV_64FC3);
	cv::Mat img_f;
	img.convertTo(img_f, CV_64FC3);
	float x;
	float y;
	int x_floor;
	int y_floor;
	int x_ceil;
	int y_ceil;
	cv::Vec3d ul;
	cv::Vec3d ur;
	cv::Vec3d dl;
	cv::Vec3d dr;
	cv::Vec3d pix;
	
	
	for(int i=0;i<rows;i++)
	{
		for(int j=0;j<cols;j++)
		{
			x = pix_table.at<cv::Vec2d>(i,j)[1];
			y = pix_table.at<cv::Vec2d>(i,j)[0];
			if(x<0 || y<0 || (y>=img.cols-1) || (x>=img.rows-1))
			{
				img_G_f.at<cv::Vec3d>(i,j) = cv::Vec3d(0,0,0);
			}
			else{
				x_floor = int(floor(x));
				x_ceil = x_floor+1;
				y_floor = int(floor(y));
				y_ceil = y_floor+1;
				
				ul = img_f.at<cv::Vec3d>(x_floor,y_floor);
				ur = img_f.at<cv::Vec3d>(x_ceil,y_floor);
				dl = img_f.at<cv::Vec3d>(x_floor,y_ceil);
				dr = img_f.at<cv::Vec3d>(x_ceil,y_ceil);
// 				pix = (ul*(x-x_floor)+ur*(x_ceil-x))*(y-y_floor)
// 					 +(dl*(x-x_floor)+dr*(x_ceil-x))*(y_ceil-y);
				pix = (ur*(x-x_floor)+ul*(x_ceil-x))*(y_ceil-y)
					 +(dr*(x-x_floor)+dl*(x_ceil-x))*(y-y_floor);
				if(pix(0)>=0   && pix(1)>=0   && pix(2)>=0 && 
				   pix(0)<=255 && pix(1)<=255 && pix(2)<=255)
				{
					img_G_f.at<cv::Vec3d>(j,i) = pix;
				}
			}
		}
	}
	
	img_G_f.convertTo(img_G, CV_8UC3);
// 	cout<<img_G_f(cv::Rect(0,0,5,1))<<endl<<endl;
// 	cout<<img_G(cv::Rect(0,0,5,1))<<endl<<endl;
	
	return img_G;
// 	return img_G_f;
}

cv::Mat project_on_ground(cv::Mat img, Sophus::SE3 T_CG,
						  Eigen::Matrix3d K_C,Eigen::Vector4d D_C,
						  cv::Mat K_G,int rows, int cols)
{
// 	cout<<"--------------------Init p_G and P_G------------------------"<<endl;
	cv::Mat p_G = cv::Mat::ones(3,rows*cols,CV_64FC1);
	for(int i=0;i<rows;i++)
	{
		for(int j=0;j<cols;j++)
		{
			p_G.at<double>(0,cols*i+j) = j;
			p_G.at<double>(1,cols*i+j) = i;
		}
	}
	
	cv::Mat P_G = cv::Mat::ones(4,rows*cols,CV_64FC1);
	P_G(cv::Rect(0,0,rows*cols,3)) = K_G.inv()*p_G;
	P_G(cv::Rect(0,2,rows*cols,1)) = 0;
	
// 	cout<<"--------------------Init P_GF------------------------"<<endl;
// 	cout<<"P_GC: "<<endl;
// 	cout<<P_G(cv::Rect(0,0,100,4))<<endl<<endl;
	cv::Mat P_GC = cv::Mat::zeros(4,rows*cols,CV_64FC1);
	cv::Mat T_CG_(4,4,CV_64FC1);
	cv::eigen2cv(T_CG.matrix(),T_CG_);
	P_GC =  T_CG_ * P_G;
// 	cout<<"P_GC: "<<endl;
// 	cout<<P_GC(cv::Rect(0,0,100,4))<<endl<<endl;
	
// 	cout<<"--------------------Init P_GF1------------------------"<<endl;
	cv::Mat P_GC1 = cv::Mat::zeros(1,rows*cols,CV_64FC2);
	vector<cv::Mat> channels(2);
	cv::split(P_GC1, channels);
	channels[0] = P_GC(cv::Rect(0,0,rows*cols,1))/P_GC(cv::Rect(0,2,rows*cols,1));
	channels[1] = P_GC(cv::Rect(0,1,rows*cols,1))/P_GC(cv::Rect(0,2,rows*cols,1));
	cv::merge(channels, P_GC1);
// 	cout<<"P_GC1: "<<endl;
// 	cout<<P_GC1(cv::Rect(0,0,5,1))<<endl<<endl;
	
// 	cout<<"--------------------Init p_GF------------------------"<<endl;
// 	cout<<K_C.cols()<<endl;
	cv::Mat p_GC = cv::Mat::zeros(1,rows*cols,CV_64FC2);
// 	cout<<eigen2mat(K_C)<<endl;
	vector<double> D_C_{D_C(0,0),D_C(1,0),D_C(2,0),D_C(3,0)};
	cv::fisheye::distortPoints(P_GC1,p_GC,eigen2mat(K_C),D_C_);
// 	cout<<"p_GC: "<<endl;
	p_GC.reshape(rows,cols);
	cv::Mat p_GC_table = p_GC.reshape(0,rows);
	vector<cv::Mat> p_GC_table_channels(2);
	cv::split(p_GC_table, p_GC_table_channels);
	
	cv::Mat p_GC_table_32F;
	p_GC_table.convertTo(p_GC_table_32F,CV_32FC2);
	
	cv::Mat img_GC;
	cv::remap(img,img_GC,p_GC_table_32F,cv::Mat(),cv::INTER_LINEAR);
// 	img_GC = bilinear_interpolation(img,p_GC_table,rows,cols);
// 	cout<<img_GC.size<<endl;
	
	return img_GC;
}


cv::Mat generate_surround_view(cv::Mat img_GF, cv::Mat img_GL, 
							   cv::Mat img_GB, cv::Mat img_GR, 
							   int rows, int cols)
{
	cv::Mat img_G(rows,cols,CV_8UC3);
	for(int i=0;i<rows;i++)
	{
		for(int j=0;j<cols;j++)
		{
			if(i>2*j-500)
			{
				if(i>-2*j+1500)
				{
					img_G.at<cv::Vec3b>(i,j) = img_GB.at<cv::Vec3b>(i,j);
				}
				else
				{
					img_G.at<cv::Vec3b>(i,j) = img_GL.at<cv::Vec3b>(i,j);
				}
				
			}
			else
			{
				if(i>-2*j+1500)
				{
					img_G.at<cv::Vec3b>(i,j) = img_GR.at<cv::Vec3b>(i,j);
				}
				else
				{
					img_G.at<cv::Vec3b>(i,j) = img_GF.at<cv::Vec3b>(i,j);
				}
			}
			
		}
	}
	
	for(int i=300;i<700;i++)
	{
		for(int j=400;j<600;j++)
		{
			img_G.at<cv::Vec3b>(i,j) = cv::Vec3b(0,0,0);
		}
	}
	
	return img_G;
}

void adjust_pose(cv::Mat img_GA, cv::Mat img_GB,
				 Eigen::Matrix<double,6,1>& rhophi_A,
				 Eigen::Matrix<double,6,1>& rhophi_B,
				 cv::Mat K_G,
				 int overlap_x, int overlap_y, int overlap_w, int overlap_h,
				 double lr)
{
	cv::Rect rectAB(overlap_x,overlap_y ,overlap_w,overlap_h);
	double fx = K_G.at<double>(0,0);
	double fy = K_G.at<double>(1,1);
	double cols = K_G.at<double>(0,2) * 2;
	double rows = K_G.at<double>(1,2) * 2;
	
	cv::Mat img_GA_gray;
	cv::cvtColor(img_GA(rectAB),img_GA_gray,cv::COLOR_BGR2GRAY);
	cv::medianBlur(img_GA_gray,img_GA_gray,5);
	img_GA_gray.convertTo(img_GA_gray, CV_64FC1);
	
	cv::Mat img_GB_gray;
	cv::cvtColor(img_GB(rectAB),img_GB_gray,cv::COLOR_BGR2GRAY);
	cv::medianBlur(img_GB_gray,img_GB_gray,5);
	img_GB_gray.convertTo(img_GB_gray, CV_64FC1);
 
	cv::Mat diff_AB;
	double coef = cv::mean(img_GA_gray).val[0]/cv::mean(img_GB_gray).val[0] ;
	cv::subtract(img_GA_gray,coef*img_GB_gray,diff_AB,cv::noArray(),CV_64FC1);
	cv::Mat diff_BA = -diff_AB;
	
	cv::Mat diff_AB_norm,diff_AB_color;
	cv::normalize(diff_AB,diff_AB_norm,0,255,cv::NORM_MINMAX,CV_8U);
	cv::applyColorMap(diff_AB_norm,diff_AB_color, cv::COLORMAP_JET);
	// cv::namedWindow("diff_AB",0);
	// cv::imshow("diff_AB",diff_AB_color);
	
	cv::Mat grad_GA_x,grad_GA_y;
	cv::Scharr(img_GA_gray, grad_GA_x, CV_64FC1, 1, 0, 1, 0, cv::BORDER_DEFAULT);
	cv::Scharr(img_GA_gray, grad_GA_y, CV_64FC1, 0, 1, 1, 0, cv::BORDER_DEFAULT);
	
	cv::Mat grad_GA_xy;
	cv::Mat pow_GA_x,pow_GA_y;
	cv::pow(grad_GA_x,2,pow_GA_x);
	cv::pow(grad_GA_y,2,pow_GA_y);
	cv::sqrt(pow_GA_x+pow_GA_y,grad_GA_xy);
// 	cout<<grad_GA_xy<<endl;
	
	cv::Mat grad_GB_x,grad_GB_y;
	cv::Scharr(img_GB_gray, grad_GB_x, CV_64FC1, 1, 0, 1, 0, cv::BORDER_DEFAULT);
	cv::Scharr(img_GB_gray, grad_GB_y, CV_64FC1, 0, 1, 1, 0, cv::BORDER_DEFAULT);
	
	cv::Mat grad_GB_xy;
	cv::Mat pow_GB_x,pow_GB_y;
	cv::pow(grad_GB_x,2,pow_GB_x);
	cv::pow(grad_GB_y,2,pow_GB_y);
	cv::sqrt(pow_GB_x+pow_GB_y,grad_GB_xy);
// 	cout<<grad_GB_xy<<endl;
	
	cv::Mat multi_GA_x,multi_GA_y;
	cv::multiply(diff_AB, grad_GA_x, multi_GA_x,1,CV_64FC1);
	cv::multiply(diff_AB, grad_GA_y, multi_GA_y,1,CV_64FC1);
	
	cv::Mat multi_GA_x_norm,multi_GA_x_color;
	cv::normalize(multi_GA_x,multi_GA_x_norm,0,255,cv::NORM_MINMAX,CV_8U);
	cv::applyColorMap(multi_GA_x_norm,multi_GA_x_color, cv::COLORMAP_JET);
	// cv::namedWindow("multi_GA_x",0);
	// cv::imshow("multi_GA_x",multi_GA_x_color);
	
	cv::Mat multi_GA_y_norm,multi_GA_y_color;
	cv::normalize(multi_GA_y,multi_GA_y_norm,0,255,cv::NORM_MINMAX,CV_8U);
	cv::applyColorMap(multi_GA_y_norm,multi_GA_y_color, cv::COLORMAP_JET);
	// cv::namedWindow("multi_GA_y",0);
	// cv::imshow("multi_GA_y",multi_GA_y_color);
	
	cv::Mat multi_GB_x,multi_GB_y;
	cv::multiply(diff_BA, grad_GB_x, multi_GB_x,1,CV_64FC1);
	cv::multiply(diff_BA, grad_GB_y, multi_GB_y,1,CV_64FC1);
	

	Eigen::Matrix<double,6,1>  delta_A,delta_B;
	rhophi_A<<0,0,0,0,0,0;
	rhophi_B<<0,0,0,0,0,0;
	double X,Y,Z;
	Z = 0;
	double mx_A,my_A,mx_B,my_B;
	int count_A = 0;
	int count_B = 0;
	for(int y=0;y<overlap_h;y++)
	{
		for(int x=0;x<overlap_w;x++)
		{
			X =  (x+overlap_x-cols/2)/fx;
			Y =  (y+overlap_y-rows/2)/fy;
			if(x%10==0 && y%10==0)
			{
				cout<<"("<<X<<","<<Y<<"), ";
			}
			
			// calculate update rhophi for camera A
			if(abs(grad_GA_xy.at<double>(y,x))>100)
			{
				count_A++;
				mx_A = multi_GA_x.at<double>(y,x);
				my_A = multi_GA_y.at<double>(y,x);
				delta_A<<mx_A*fx,
						 my_A*fy,
						 0,
						 0,
						 0,
						 mx_A*fx*Y - my_A*fy*X;
// 				delta_A<<0,
// 						 0,
// 						 mx_A*fx*Y - my_A*fy*X,
// 						 mx_A*fx,
// 						 my_A*fy,
// 						 0;
				rhophi_A += delta_A;
			}
			
			
			// calculate update rhophi for camera B
			if(abs(grad_GB_xy.at<double>(y,x))>100)
			{
				count_B++;
				mx_B = multi_GB_x.at<double>(y,x);
				my_B = multi_GB_y.at<double>(y,x);
				delta_B<<mx_B*fx,
						 my_B*fy,
						 0,
						 0,
						 0,
						 mx_B*fx*Y - my_B*fy*X;
// 				delta_B<<0,
// 						 0,
// 						 mx_B*fx*Y - my_B*fy*X,
// 						 mx_B*fx,
// 						 my_B*fy,
// 						 0;
				rhophi_B += delta_B;
			}
		}
		
		if(y%10==0)
		{
			cout<<endl;
		}
	}
	
	cout<<"count_A: "<<count_A<<endl;
	cout<<"count_B: "<<count_B<<endl;
	
	rhophi_A = lr * (rhophi_A/count_A);
	rhophi_B = lr * (rhophi_B/count_B);
	
	return;
}

cv::Mat ground2cam(int x,int y, cv::Mat K_G, Sophus::SE3 T_CG, Eigen::Matrix3d K_C)
{
	cv::Mat p_G = cv::Mat::ones(3,1,CV_64FC1);
	p_G.at<double>(0,0) = x;
	p_G.at<double>(1,0) = y;
// 	cout<<p_G<<endl;
	cv::Mat P_G = cv::Mat::ones(4,1,CV_64FC1);
	P_G(cv::Rect(0,0,1,3)) = K_G.inv()*p_G;
	P_G.at<double>(0,2) = 0;
// 	cout<<P_G<<endl;
	cv::Mat P_C = eigen2mat(T_CG.matrix())*P_G;
// 	cout<<P_C<<endl;
	cv::Mat P_C_1 = P_C(cv::Rect(0,0,1,3))/P_C.at<double>(0,2);
// 	cout<<P_C_1<<endl;
	cv::Mat p_C = eigen2mat(K_C)*P_C_1;
// 	cout<<p_C<<endl;
	
	return p_C;
}



//Kyrie

void CalculateROI(	cv::Mat & mImage , cv::Mat & mROI , 
					cv::Mat mK , cv::Mat mD ,
					Sophus::SE3 sT_CG , cv::Mat mKG,
					int nROI_X , int nROI_Y , int nROI_W , int nROI_H,
					vector<int> & gROI){
	//The inverse pose of the camera.
	Sophus::SE3 sT_GC = sT_CG.inverse();

	Eigen::Matrix3d mEigenK;
	cv2eigen(mK , mEigenK);

	cv::Mat mMinUPoint = ground2cam(nROI_X,    nROI_Y,
								mKG, sT_CG, mEigenK);
	cv::Mat mMaxUPoint = ground2cam(nROI_X + nROI_W,    nROI_Y,
								mKG, sT_CG, mEigenK);
	cv::Mat mMinVPoint = ground2cam(nROI_X,    nROI_Y + nROI_H,
								mKG, sT_CG, mEigenK);
	cv::Mat mMaxVPoint = ground2cam(nROI_X + nROI_W,    nROI_Y + nROI_H,
								mKG, sT_CG, mEigenK);

	
// 	cout<<"--------------------determin ROI on camera A--------------------------"<<endl;
	vector<double> gPointsX{
						mMinUPoint.at<double>(0,0),
						mMaxUPoint.at<double>(0,0),
						mMinVPoint.at<double>(0,0),
						mMaxVPoint.at<double>(0,0)
					};

	vector<double> gPointsY{
						mMinUPoint.at<double>(1,0),
						mMaxUPoint.at<double>(1,0),
						mMinVPoint.at<double>(1,0),
						mMaxVPoint.at<double>(1,0)
					};

	//Get the whole area of the ROI
	int nMaxX = int(*max_element(gPointsX.begin(),gPointsX.end()))+10;
	int nMinX = int(*min_element(gPointsX.begin(),gPointsX.end()))-10;
	int nMaxY = int(*max_element(gPointsY.begin(),gPointsY.end()))+10;
	int nMinY = int(*min_element(gPointsY.begin(),gPointsY.end()))-10;
	int nWidth  = nMaxX - nMinX;
	int nHeight = nMaxY - nMinY;

	//Save ROI region.
	gROI.clear();
	gROI.reserve(4);
	gROI.push_back(nMinX);
	gROI.push_back(nMinY);
	gROI.push_back(nMaxX);
	gROI.push_back(nMaxY);


	cv::Rect iROI(nMinX, nMinY, nWidth, nHeight);
	
	cv::Size iSizeROI(nWidth,nHeight);

	//Generate new ROI K.
	cv::Mat mK_ROI = mK.clone();
	mK_ROI.at<double>(0,2) = mK_ROI.at<double>(0,2) - nMinX;
	mK_ROI.at<double>(1,2) = mK_ROI.at<double>(1,2) - nMinY;
	//Undistort image.
	cv::fisheye::undistortImage(mImage,mROI,
								mK,mD,
								mK_ROI,iSizeROI);


}




//


void calc_ROI_AB( 
				 cv::Mat& img_A, cv::Mat& img_B,
				 cv::Mat& ROI_on_A, cv::Mat& ROI_on_A_from_B, cv::Mat& P_As,
				 Eigen::Matrix3d K_A, Eigen::Matrix3d K_B, 
				 Eigen::Vector4d D_A, Eigen::Vector4d D_B,
				 Sophus::SE3 T_AG, Sophus::SE3 T_BG, 
				 cv::Mat K_G,
				 int ROI_x,int ROI_y,int ROI_w,int ROI_h
				)
{
	Sophus::SE3 T_GA = T_AG.inverse();
	Sophus::SE3 T_GB = T_BG.inverse();
	cv::Mat p_A_ul = ground2cam(ROI_x,       ROI_y,
								K_G, T_AG, K_A);
	cv::Mat p_A_ur = ground2cam(ROI_x+ROI_w, ROI_y,
								K_G, T_AG, K_A);
	cv::Mat p_A_dl = ground2cam(ROI_x,       ROI_y+ROI_h,
								K_G, T_AG, K_A);
	cv::Mat p_A_dr = ground2cam(ROI_x+ROI_w, ROI_y+ROI_h,
								K_G, T_AG, K_A);
	
// 	cout<<"--------------------determin ROI on camera A--------------------------"<<endl;
	vector<double> p_x{p_A_ul.at<double>(0,0),p_A_ur.at<double>(0,0),p_A_dl.at<double>(0,0),p_A_dr.at<double>(0,0)};
	vector<double> p_y{p_A_ul.at<double>(1,0),p_A_ur.at<double>(1,0),p_A_dl.at<double>(1,0),p_A_dr.at<double>(1,0)};
	int x_max = int(*max_element(p_x.begin(),p_x.end()));
	int x_min = int(*min_element(p_x.begin(),p_x.end()));
	int y_max = int(*max_element(p_y.begin(),p_y.end()));
	int y_min = int(*min_element(p_y.begin(),p_y.end()));
	int x_width  = x_max-x_min;
	int y_height = y_max-y_min;
	cv::Rect rect_AB_on_A(x_min, y_min, x_width, y_height);
	
// 	cout<<"--------------------cut off ROA on camera A--------------------------"<<endl;
	cv::Size sizeROI(x_width,y_height);
	cv::Mat K_A_mat = eigen2mat(K_A);
	cv::Mat K_A_mat_ROI = K_A_mat.clone();
	K_A_mat_ROI.at<double>(0,2) = K_A_mat_ROI.at<double>(0,2) - x_min;
	K_A_mat_ROI.at<double>(1,2) = K_A_mat_ROI.at<double>(1,2) - y_min;
	cv::fisheye::undistortImage(img_A,ROI_on_A,
								K_A_mat,eigen2mat(D_A),
								K_A_mat_ROI,sizeROI);
	
// 	cout<<"--------------------project ROI from camera B to camera A --------------------------"<<endl;
	double a7 = T_GA.matrix()(2,0);
	double a8 = T_GA.matrix()(2,1);
	double a9 = T_GA.matrix()(2,2);
	double t3 = T_GA.matrix()(2,3);
	cv::Mat p_A, p_A_1, P_A, P_G_A, P_B_A, P_B_A_1;
	P_As = cv::Mat::zeros(y_height,x_width,CV_64FC3);
	cv::Mat P_B_A_1s = cv::Mat::zeros(y_height,x_width,CV_64FC2);
	p_A = cv::Mat::ones(3,1,CV_64FC1);
	for(int i=0;i<x_width;i++)
	{
		for(int j=0;j<y_height;j++)
		{
			// each pixel on ROI_on_A
			p_A.at<double>(0,0) = i;
			p_A.at<double>(1,0) = j;
			p_A_1 = K_A_mat_ROI.inv()*p_A;
			// calculate depth and coodinate of the pixel on camera A
			double Z_A = -t3/(a7*p_A_1.at<double>(0,0) + a8*p_A_1.at<double>(1,0) + a9);
			P_A = cv::Mat::ones(4,1,CV_64FC1);
			P_A(cv::Rect(0,0,1,3)) = Z_A*p_A_1;
			P_As.at<cv::Vec3d>(j,i) = cv::Vec3d(P_A.at<double>(0,0),
												P_A.at<double>(1,0),
												P_A.at<double>(2,0));
			// calculate the normalized coodinate of the pixel on camera B
			P_G_A = eigen2mat(T_GA.matrix())*P_A;
			P_B_A = eigen2mat(T_BG.matrix())*P_G_A;
			P_B_A_1 = P_B_A(cv::Rect(0,0,1,2))/P_B_A.at<double>(2,0);
			P_B_A_1s.at<cv::Vec2d>(j,i) = cv::Vec2d(P_B_A_1.at<double>(0,0),
													P_B_A_1.at<double>(1,0));
		}
	}
	// calculate pixel coodinate of ROI_on_A on camera B, namely the project map from B to A
	cv::Mat p_B_As;
	cv::fisheye::distortPoints(P_B_A_1s,p_B_As,eigen2mat(K_B),eigen2mat(D_B));
	cv::Mat p_B_As_32F;
	p_B_As.convertTo(p_B_As_32F,CV_32FC2);
	
	cv::remap(img_B,ROI_on_A_from_B,p_B_As_32F,cv::Mat(),cv::INTER_LINEAR);
	return;
}


void adjust_pose_V2(
					cv::Mat img_A, cv::Mat img_B,std::string A,std::string B,
					Sophus::SE3& rhophi_A_SE3,
					Eigen::Matrix3d K_A, Eigen::Matrix3d K_B, 
					Eigen::Vector4d D_A, Eigen::Vector4d D_B,
					Sophus::SE3 T_AG, Sophus::SE3 T_BG, 
					cv::Mat K_G,
					int ROI_x,int ROI_y,int ROI_w,int ROI_h,
					double threshold,double rate
)
{
	cv::Mat ROI_on_A;
	cv::Mat ROI_on_A_from_B;
	cv::Mat P_As;
	
	calc_ROI_AB(img_A, img_B,
				ROI_on_A, ROI_on_A_from_B, P_As,
				K_A, K_B, 
				D_A,D_B,
				T_AG,T_BG, 
				K_G,
				ROI_x, ROI_y, ROI_w,ROI_h);

	
	cv::Mat ROI_on_A_gray;
	cv::Mat ROI_on_A_gray_blur;
	cv::Mat ROI_on_A_gray_64F;
	cv::cvtColor(ROI_on_A,ROI_on_A_gray,cv::COLOR_BGR2GRAY);
	// cv::medianBlur(ROI_on_A_gray,ROI_on_A_gray_blur,5);
	ROI_on_A_gray_blur = ROI_on_A_gray.clone();
	ROI_on_A_gray_blur.convertTo(ROI_on_A_gray_64F, CV_64FC1);
	
	cv::Mat ROI_on_A_from_B_gray;
	cv::Mat ROI_on_A_from_B_gray_blur;
	cv::Mat ROI_on_A_from_B_gray_64F;
	cv::cvtColor(ROI_on_A_from_B,ROI_on_A_from_B_gray,cv::COLOR_BGR2GRAY);
	// cv::medianBlur(ROI_on_A_from_B_gray,ROI_on_A_from_B_gray_blur,5);
	ROI_on_A_from_B_gray_blur = ROI_on_A_from_B_gray.clone();
	ROI_on_A_from_B_gray_blur.convertTo(ROI_on_A_from_B_gray_64F, CV_64FC1);
	
	cv::Mat diff_AB;
	double coef = cv::mean(ROI_on_A_gray_64F).val[0]/cv::mean(ROI_on_A_from_B_gray_64F).val[0];
	cv::subtract(ROI_on_A_gray_64F,coef*ROI_on_A_from_B_gray_64F,diff_AB,cv::noArray(),CV_64FC1);
// 	imshow_64F(diff_AB,"diff_"+A+B);
// 	cv::Mat diff_AB2, diff_AB_8U, diff_AB_color;
// // 	cout<<diff_AB(cv::Rect(0,0,10,10))<<endl;
// 	cv::exp(-diff_AB/24,diff_AB2);
// // 	cout<<diff_AB2(cv::Rect(0,0,10,10))<<endl;
// 	diff_AB2 = 255/(1+diff_AB2);
// // 	cout<<diff_AB2(cv::Rect(0,0,10,10))<<endl;
// 	diff_AB2.convertTo(diff_AB_8U,CV_8U);
// 	cv::applyColorMap(diff_AB_8U,diff_AB_color, cv::COLORMAP_JET);
// 	cv::namedWindow("diff_"+A+B,0);
// 	cv::imshow("diff_"+A+B,diff_AB_color);
	
	cv::Mat grad_GA_x,grad_GA_y;
// 	cv::Scharr(ROI_on_A_gray_64F, grad_GA_x, CV_64FC1, 1, 0, 1, 0, cv::BORDER_DEFAULT);
// 	cv::Scharr(ROI_on_A_gray_64F, grad_GA_y, CV_64FC1, 0, 1, 1, 0, cv::BORDER_DEFAULT);
	cv::Sobel(ROI_on_A_gray_64F, grad_GA_x, CV_64FC1, 1, 0, 7);
	cv::Sobel(ROI_on_A_gray_64F, grad_GA_y, CV_64FC1, 0, 1, 7);
// 	cv::Mat grad_GA_xy;
// 	cv::Mat pow_grad_GA_x,pow_grad_GA_y;
// 	cv::pow(grad_GA_x,2,pow_grad_GA_x);
// 	cv::pow(grad_GA_y,2,pow_grad_GA_y);
// 	cv::sqrt(pow_grad_GA_x+pow_grad_GA_y,grad_GA_xy);
	
	cv::Mat multi_GA_x,multi_GA_y;
	cv::multiply(diff_AB, grad_GA_x, multi_GA_x,1,CV_64FC1);
	cv::multiply(diff_AB, grad_GA_y, multi_GA_y,1,CV_64FC1);
	cv::Mat multi_GA_xy;
	cv::Mat pow_multi_GA_x,pow_multi_GA_y;
	cv::pow(multi_GA_x,2,pow_multi_GA_x);
	cv::pow(multi_GA_y,2,pow_multi_GA_y);
	cv::sqrt(pow_multi_GA_x+pow_multi_GA_y,multi_GA_xy);
	
	double fx = K_A(0,0);
	double fy = K_A(1,1);
	double X,Y,Z;
	Eigen::Matrix<double,1,2> J_error_xy;
	Eigen::Matrix<double,2,6> J_xy_ksai;
	Eigen::Matrix<double,1,6> rhophi,J_error_ksai;
	Eigen::Matrix<double,6,6> H;
	Eigen::Matrix<double,6,1> g;
	rhophi<<0,0,0,0,0,0;
	int count = 0;
	
	for(int j=0; j<ROI_on_A.rows; j++)
	{
		for(int i=0; i<ROI_on_A.cols; i++)
		{
			Z = P_As.at<cv::Vec3d>(j,i).val[2];
			vector<double> gAverage = {};
			int nMinX = -1 , nMaxX = 1;
			int nMinY = -1 , nMaxY = 1;
			
			if (i==0){
				nMinY = 0;
			}
			if (i==ROI_on_A.cols-1){
				nMaxY = 0;
			}
			if (j==0){
				nMinX = 0;
			}
			if (j==ROI_on_A.rows-1){
				nMaxX = 0;
			}
			for (int ii=i-nMinY;ii<=i+nMaxY;ii++){
				for (int jj=j-nMinX;jj<=j+nMaxX;jj++){
					gAverage.push_back(multi_GA_xy.at<double>(jj,ii));
				}
			}
			double nAverage = 0.0;
			for (auto item : gAverage){
				nAverage += item;
			}
			nAverage /= gAverage.size();

			if(multi_GA_xy.at<double>(j,i)>threshold && Z>0.1 && 
				multi_GA_xy.at<double>(j,i) > nAverage)
			{

				int value1 = rand()%200;
				int value2 = rand()%200;
				int value3 = rand()%200;
				for (int iii = -1; iii <=1 ; iii++){
					for (int jjj = -1; jjj <=1; jjj++){
						if (j+jjj >=0 && j+jjj < ROI_on_A.rows &&
							 i+iii >=0 && i+iii < ROI_on_A.cols ){
							ROI_on_A.at<cv::Vec3b>(j+jjj , i+iii)[0] = value1;
							ROI_on_A.at<cv::Vec3b>(j+jjj , i+iii)[1] = value2;
							ROI_on_A.at<cv::Vec3b>(j+jjj , i+iii)[2] = value3;			
						}
					}
				}
				

				X = P_As.at<cv::Vec3d>(j,i).val[0];
				Y = P_As.at<cv::Vec3d>(j,i).val[1];
				Z = P_As.at<cv::Vec3d>(j,i).val[2];
				
				J_error_xy(0,0) = multi_GA_x.at<double>(j,i);
				J_error_xy(0,1) = multi_GA_y.at<double>(j,i);
				
				
				J_xy_ksai(0,0) = fx/Z;
				J_xy_ksai(0,1) = 0;
				J_xy_ksai(0,2) = -(fx*X)/(Z*Z);
				J_xy_ksai(0,3) = -(fx*X*Y)/(Z*Z);
				J_xy_ksai(0,4) = fx+(fx*X*X)/(Z*Z);
				J_xy_ksai(0,5) = -(fx*Y)/Z;
				
				
				J_xy_ksai(1,0) = 0;
				J_xy_ksai(1,1) = fy/Z;
				J_xy_ksai(1,2) = -(fy*Y)/(Z*Z);
				J_xy_ksai(1,3) = -fy-(fy*Y*Y)/(Z*Z);
				J_xy_ksai(1,4) = (fy*X*Y)/(Z*Z);
				J_xy_ksai(1,5) = (fy*X)/Z;
				
// 				J_error_ksai =J_error_xy * J_xy_ksai * 1e-10;
// 				
// 				H +=  J_error_ksai.transpose() * J_error_ksai;
// 				g += -J_error_ksai.transpose() * diff_AB.at<double>(j,i);
// 				
				
				rhophi += J_error_xy*J_xy_ksai;
				
				
				count++;
				ROI_on_A_gray.at<char>(j,i) = 0;
			}
		}
	}

	//cv::imwrite("roi.jpg" , ROI_on_A);
	
	cout<<"=========================="<<endl<<endl;
	
	if(count>0)
	{
// 		H /= count;
// 		g /= count;
// 		cout<<g<<endl<<endl;
// 		cout<<H<<endl<<endl;
// 		cout<<H.inverse()<<endl<<endl;
// 		rhophi = H.inverse()*g;
		rhophi /= count;
	}
	rhophi *= rate;
	cout<<"rhophi: "<<rhophi<<endl;
	
	cout<<"=========================="<<endl<<endl;
	
	
// 	imshow_64F_gray(ROI_on_A_gray,"ROI_"+A+B+"_on_"+A);
// 	imshow_64F_gray(ROI_on_A_from_B_gray,"ROI_"+A+B+"_on_"+A+"_from_"+B);
	
	rhophi_A_SE3 = Sophus::SE3::exp(rhophi);
	
	return;
}



void adjust_pose_V2_2(
					cv::Mat img_A, cv::Mat img_B,std::string A,std::string B,
					Sophus::SE3& rhophi_A_SE3,
					Eigen::Matrix3d K_A, Eigen::Matrix3d K_B, 
					Eigen::Vector4d D_A, Eigen::Vector4d D_B,
					Sophus::SE3 T_AG, Sophus::SE3 T_BG, 
					cv::Mat K_G,
					int ROI_x,int ROI_y,int ROI_w,int ROI_h,
					double threshold,double rate
)
{
	cv::Mat ROI_on_A;
	cv::Mat ROI_on_A_from_B;
	cv::Mat P_As;
	
	calc_ROI_AB(img_A, img_B,
				ROI_on_A, ROI_on_A_from_B, P_As,
				K_A, K_B, 
				D_A,D_B,
				T_AG,T_BG, 
				K_G,
				ROI_x, ROI_y, ROI_w,ROI_h);

	
	cv::Mat ROI_on_A_gray;
	cv::Mat ROI_on_A_gray_blur;
	cv::Mat ROI_on_A_gray_64F;
	cv::cvtColor(ROI_on_A,ROI_on_A_gray,cv::COLOR_BGR2GRAY);
	// cv::medianBlur(ROI_on_A_gray,ROI_on_A_gray_blur,5);
	ROI_on_A_gray_blur = ROI_on_A_gray.clone();
	ROI_on_A_gray_blur.convertTo(ROI_on_A_gray_64F, CV_64FC1);
	
	cv::Mat ROI_on_A_from_B_gray;
	cv::Mat ROI_on_A_from_B_gray_blur;
	cv::Mat ROI_on_A_from_B_gray_64F;
	cv::cvtColor(ROI_on_A_from_B,ROI_on_A_from_B_gray,cv::COLOR_BGR2GRAY);
	// cv::medianBlur(ROI_on_A_from_B_gray,ROI_on_A_from_B_gray_blur,5);
	ROI_on_A_from_B_gray_blur = ROI_on_A_from_B_gray.clone();
	ROI_on_A_from_B_gray_blur.convertTo(ROI_on_A_from_B_gray_64F, CV_64FC1);
	
	cv::Mat diff_AB;
	double coef = cv::mean(ROI_on_A_gray_64F).val[0]/cv::mean(ROI_on_A_from_B_gray_64F).val[0];
	cv::subtract(ROI_on_A_gray_64F,coef*ROI_on_A_from_B_gray_64F,diff_AB,cv::noArray(),CV_64FC1);
// 	imshow_64F(diff_AB,"diff_"+A+B);
// 	cv::Mat diff_AB2, diff_AB_8U, diff_AB_color;
// // 	cout<<diff_AB(cv::Rect(0,0,10,10))<<endl;
// 	cv::exp(-diff_AB/24,diff_AB2);
// // 	cout<<diff_AB2(cv::Rect(0,0,10,10))<<endl;
// 	diff_AB2 = 255/(1+diff_AB2);
// // 	cout<<diff_AB2(cv::Rect(0,0,10,10))<<endl;
// 	diff_AB2.convertTo(diff_AB_8U,CV_8U);
// 	cv::applyColorMap(diff_AB_8U,diff_AB_color, cv::COLORMAP_JET);
// 	cv::namedWindow("diff_"+A+B,0);
// 	cv::imshow("diff_"+A+B,diff_AB_color);
	
	cv::Mat grad_GA_x,grad_GA_y;
// 	cv::Scharr(ROI_on_A_gray_64F, grad_GA_x, CV_64FC1, 1, 0, 1, 0, cv::BORDER_DEFAULT);
// 	cv::Scharr(ROI_on_A_gray_64F, grad_GA_y, CV_64FC1, 0, 1, 1, 0, cv::BORDER_DEFAULT);
	cv::Sobel(ROI_on_A_gray_64F, grad_GA_x, CV_64FC1, 1, 0, 7);
	cv::Sobel(ROI_on_A_gray_64F, grad_GA_y, CV_64FC1, 0, 1, 7);

	cv::Mat grad_GB_x , grad_GB_y;
	cv::Sobel(ROI_on_A_from_B_gray_64F, grad_GB_x, CV_64FC1, 1, 0, 7);
	cv::Sobel(ROI_on_A_from_B_gray_64F, grad_GB_y, CV_64FC1, 0, 1, 7);	
// 	cv::Mat grad_GA_xy;
// 	cv::Mat pow_grad_GA_x,pow_grad_GA_y;
// 	cv::pow(grad_GA_x,2,pow_grad_GA_x);
// 	cv::pow(grad_GA_y,2,pow_grad_GA_y);
// 	cv::sqrt(pow_grad_GA_x+pow_grad_GA_y,grad_GA_xy);
	
	cv::Mat multi_GA_x,multi_GA_y;
	cv::multiply(diff_AB, grad_GA_x, multi_GA_x,1,CV_64FC1);
	cv::multiply(diff_AB, grad_GA_y, multi_GA_y,1,CV_64FC1);
	cv::Mat multi_GA_xy;
	cv::Mat pow_multi_GA_x,pow_multi_GA_y;
	cv::pow(multi_GA_x,2,pow_multi_GA_x);
	cv::pow(multi_GA_y,2,pow_multi_GA_y);
	cv::sqrt(pow_multi_GA_x+pow_multi_GA_y,multi_GA_xy);


	cv::Mat multi_GB_x , multi_GB_y;
	cv::multiply(diff_AB, grad_GB_x, multi_GB_x,1,CV_64FC1);
	cv::multiply(diff_AB, grad_GB_y, multi_GB_y,1,CV_64FC1);
	

	// cv::subtract(multi_GA_x,multi_GB_x,multi_GA_x,cv::noArray(),CV_64FC1);
	// cv::subtract(multi_GA_y,multi_GB_y,multi_GA_y,cv::noArray(),CV_64FC1);


	
	double fx = K_A(0,0);
	double fy = K_A(1,1);
	double X,Y,Z;
	Eigen::Matrix<double,1,2> J_error_xy;
	Eigen::Matrix<double,2,6> J_xy_ksai;
	Eigen::Matrix<double,1,6> rhophi,J_error_ksai;
	Eigen::Matrix<double,6,6> H;
	Eigen::Matrix<double,6,1> g;
	rhophi<<0,0,0,0,0,0;
	int count = 0;
	
	for(int j=0; j<ROI_on_A.rows; j++)
	{
		for(int i=0; i<ROI_on_A.cols; i++)
		{
			Z = P_As.at<cv::Vec3d>(j,i).val[2];
			if(multi_GA_xy.at<double>(j,i)>threshold && Z>0.1)
			{
				X = P_As.at<cv::Vec3d>(j,i).val[0];
				Y = P_As.at<cv::Vec3d>(j,i).val[1];
				Z = P_As.at<cv::Vec3d>(j,i).val[2];
				
				J_error_xy(0,0) = multi_GA_x.at<double>(j,i);
				J_error_xy(0,1) = multi_GA_y.at<double>(j,i);
				
				
				J_xy_ksai(0,0) = fx/Z;
				J_xy_ksai(0,1) = 0;
				J_xy_ksai(0,2) = -(fx*X)/(Z*Z);
				J_xy_ksai(0,3) = -(fx*X*Y)/(Z*Z);
				J_xy_ksai(0,4) = fx+(fx*X*X)/(Z*Z);
				J_xy_ksai(0,5) = -(fx*Y)/Z;
				
				
				J_xy_ksai(1,0) = 0;
				J_xy_ksai(1,1) = fy/Z;
				J_xy_ksai(1,2) = -(fy*Y)/(Z*Z);
				J_xy_ksai(1,3) = -fy-(fy*Y*Y)/(Z*Z);
				J_xy_ksai(1,4) = (fy*X*Y)/(Z*Z);
				J_xy_ksai(1,5) = (fy*X)/Z;
				
// 				J_error_ksai =J_error_xy * J_xy_ksai * 1e-10;
// 				
// 				H +=  J_error_ksai.transpose() * J_error_ksai;
// 				g += -J_error_ksai.transpose() * diff_AB.at<double>(j,i);
// 				
				
				rhophi += J_error_xy*J_xy_ksai;
				
				
				count++;
				ROI_on_A_gray.at<char>(j,i) = 0;
			}
		}
	}

	
	
	cout<<"=========================="<<endl<<endl;
	
	if(count>0)
	{
// 		H /= count;
// 		g /= count;
// 		cout<<g<<endl<<endl;
// 		cout<<H<<endl<<endl;
// 		cout<<H.inverse()<<endl<<endl;
// 		rhophi = H.inverse()*g;
		rhophi /= count;
	}
	rhophi *= rate;
	cout<<"rhophi: "<<rhophi<<endl;
	
	cout<<"=========================="<<endl<<endl;
	
	
// 	imshow_64F_gray(ROI_on_A_gray,"ROI_"+A+B+"_on_"+A);
// 	imshow_64F_gray(ROI_on_A_from_B_gray,"ROI_"+A+B+"_on_"+A+"_from_"+B);
	
	rhophi_A_SE3 = Sophus::SE3::exp(rhophi);
	
	return;
}








cv::Mat ApplyColor(cv::Mat mDifference){
	cv::Mat diff_RF2, diff_RF_8U, diff_RF_color;
	cv::exp(-mDifference/24,diff_RF2);
	diff_RF2 = 255/(1+diff_RF2);
	diff_RF2.convertTo(diff_RF_8U,CV_8U);
	cv::applyColorMap(diff_RF_8U,diff_RF_color, cv::COLORMAP_JET);
	return diff_RF_color;
}




Eigen::Matrix<double,1,6> PoseAdjustV3(	cv::Mat mImage_A, cv::Mat mImage_B,
					cv::Mat mGroundImage_A , cv::Mat mGroundImage_B,
					cv::Mat mK_A, cv::Mat mK_B, 
					cv::Mat mD_A, cv::Mat mD_B,
					Sophus::SE3 sT_AG, Sophus::SE3 sT_BG, 
					cv::Mat mK_G,
					int nROI_X,int nROI_Y,int nROI_W,int nROI_H,
					double nThreshold,double nDecayRate){

	//Firstly, we need to calculate the difference between 2 images on the ground.
	//ROI on the ground.
	cv::Rect mROI_G(nROI_X,nROI_Y,nROI_W,nROI_H);

	//Cut the ROI on the ground.
	cv::Mat mGroundROI_A , mGroundROI_B;
	// cv::Mat mGroundROI_Color_A , mGroundROI_Color_B;
	mGroundROI_A = mGroundImage_A(mROI_G);
	mGroundROI_B = mGroundImage_B(mROI_G);

	// mGroundROI_Color_A = mGroundROI_A.clone();
	// mGroundROI_Color_B = mGroundROI_B.clone();

	// cv::imshow("1" , mGroundROI_A);
	// cv::imshow("2" , mGroundROI_B);
	// cv::waitKey(0);

	cv::Mat mColoredROI_A = mGroundROI_A.clone();
	cv::Mat mColoredROI_B = mGroundROI_B.clone();

	
	//Convert ROI to gray image.
	//Convert image A.
	cv::cvtColor(mGroundROI_A,mGroundROI_A,cv::COLOR_BGR2GRAY);

	cv::Mat mGrayROI_A = mGroundROI_A.clone();

	mGroundROI_A.convertTo(mGroundROI_A, CV_64FC1);
	//Convert image B.
	
	cv::cvtColor(mGroundROI_B,mGroundROI_B,cv::COLOR_BGR2GRAY);

	cv::Mat mGrayROI_B = mGroundROI_B.clone();

	mGroundROI_B.convertTo(mGroundROI_B, CV_64FC1);



	//Get the difference.
	cv::Mat mDifference;
	//Get the adjustment coefficient.
	double nCoefficient = cv::mean(mGroundROI_A).val[0]/cv::mean(mGroundROI_B).val[0];
	cv::subtract(	mGroundROI_A, nCoefficient*mGroundROI_B,
					mDifference,cv::noArray(),CV_64FC1
					);


	//Show difference.
	cv::Mat mDifferenceColor = ApplyColor(mDifference);
		// cv::imshow("difference" , mDifferenceColor);
		// cv::waitKey(0);	


	//Secondly, the gradient need to be computed.

	//Get the ROI on undistorted images.	
	cv::Mat mROI_A , mROI_B;
	vector<int> gROI_A , gROI_B;
	//Calculate ROI on image A.

	CalculateROI(	mImage_A , mROI_A , 
					mK_A , mD_A ,
					sT_AG , mK_G,
					nROI_X , nROI_Y,
					nROI_W , nROI_H,
					gROI_A);
	//Calculate ROI on image B.
	CalculateROI(	mImage_B , mROI_B , 
					mK_B , mD_B ,
					sT_BG , mK_G,
					nROI_X , nROI_Y,
					nROI_W , nROI_H,
					gROI_B);
	
	//Convert to gray
	//Convert image A.

	cv::cvtColor(mROI_A,mROI_A,cv::COLOR_BGR2GRAY);
	
	// cv::imshow("ROI_A" , mROI_A);
	// cv::waitKey(0);
	mROI_A.convertTo(mROI_A, CV_64FC1);
	//Convert image B.
	cv::cvtColor(mROI_B,mROI_B,cv::COLOR_BGR2GRAY);
	
	// cv::imshow("ROI_B" , mROI_B);
	// cv::waitKey(0);
	mROI_B.convertTo(mROI_B, CV_64FC1);

	//Compute gradients.
	cv::Mat mGradient_AX, mGradient_AY;
	cv::Mat mGradient_BX, mGradient_BY;

	//Compute gradients for image A.
	cv::Sobel(mROI_A, mGradient_AX, CV_64FC1, 1, 0, 7);
	cv::Sobel(mROI_A, mGradient_AY, CV_64FC1, 0, 1, 7);
	//Compute gradients for image B.
	cv::Sobel(mROI_B, mGradient_BX, CV_64FC1, 1, 0, 7);
	cv::Sobel(mROI_B, mGradient_BY, CV_64FC1, 0, 1, 7);

	//TODO: Select pixels

	vector<cv::Mat> gPointsA , gPointsB;
	vector<cv::Mat> gImagePoints_A , gImagePoints_B;

	cv::Mat mK_G_inv = mK_G.inv();
	cv::Mat mp_G = cv::Mat::ones(3 , nROI_W * nROI_H , CV_64FC1);
	cv::Mat mK_G_Augment;
	cv::vconcat( mK_G_inv.rowRange(0 , 2) , cv::Mat::zeros(1 , 3 , CV_64FC1) , mK_G_Augment);
	cv::vconcat( mK_G_Augment , mK_G_inv.rowRange(2 , 3) , mK_G_Augment);


	int nPointNum = 0;
	for (int u=0;u<nROI_W;u++){
		for (int v=0;v<nROI_H;v++){	
			if (mDifference.at<double>(v , u) > 10 ||
				mDifference.at<double>(v , u) < -10){
				cv::Vec3b mColorPointA = mColoredROI_A.at<cv::Vec3b>(v , u);
				cv::Vec3b mColorPointB = mColoredROI_B.at<cv::Vec3b>(v , u);

				float nScale1 = (float)mColorPointA[0]/(float)mColorPointB[0];
				float nScale2 = (float)mColorPointA[1]/(float)mColorPointB[1];
				float nScale3 = (float)mColorPointA[2]/(float)mColorPointB[2];
				float nAverageScale = (nScale1 + nScale2 + nScale3)/3;
				float nSigma = sqrt((nScale1 - nAverageScale) * (nScale1 - nAverageScale) + 
									(nScale2 - nAverageScale) * (nScale2 - nAverageScale) + 
									(nScale3 - nAverageScale) * (nScale3 - nAverageScale));

				if (nSigma > 0.15) {
					// cout << "nSigma is " << endl << nSigma << endl;
					continue;
				}



				mp_G.at<double>(0 , nPointNum) = u + nROI_X;
				mp_G.at<double>(1 , nPointNum) = v + nROI_Y;
				nPointNum++;
			}
		}
	}
	// cout << "nPointNum is " << nPointNum << endl;

	//Get all 3D points.
	cv::Mat mP_G = mK_G_Augment * mp_G;
	cv::Mat mP_A = eigen2mat(sT_AG.matrix()) * mP_G;
	cv::Mat mP_B = eigen2mat(sT_BG.matrix()) * mP_G;


	cv::Mat mImageP_A = mK_A * mP_A.rowRange(0,3);
	cv::Mat mImageP_B = mK_B * mP_B.rowRange(0,3);


	for (int i=0;i<nPointNum;i++){
		cv::Mat mPointA = mP_A.col(i);
		cv::Mat mPointB = mP_B.col(i);

		//No need to normalize, because points have already been normalized.
		gPointsA.push_back(mPointA);
		gPointsB.push_back(mPointB);

		cv::Mat mImagePoint = mImageP_A.col(i);
		mImagePoint /= mImagePoint.at<double>(2 , 0);
	}

	//Thirdly we calculate the rest items.






	//Calculate jacob



	Eigen::Matrix<double,1,2> J_error_xy;
	Eigen::Matrix<double,2,6> J_xy_ksai;
	Eigen::Matrix<double,1,6> rhophi,J_error_ksai;
	Eigen::Matrix<double,6,6> H;
	Eigen::Matrix<double,6,1> g;

	double fx = mK_A.at<double>(0,0);
	double fy = mK_A.at<double>(1,1);

	//Compute jacobian of A

	cv::Mat mCheckGround = mDifference.clone();

	int nNum = 0;
	// for (int u=0;u<nROI_W;u++){
	// 	for (int v=0;v<nROI_H;v++){
	// cout << "Jacobian " << endl;
	for (int nIndex = 0; nIndex < nPointNum; nIndex++)
	{
			int u = mp_G.at<double>(0 , nIndex)-nROI_X,
				v = mp_G.at<double>(1 , nIndex)-nROI_Y;
			//3D point
			cv::Mat mPoint = gPointsA[nIndex];
			cv::Mat mPoint_B = gPointsB[nIndex];
			//2D point
			cv::Mat mPoint2D = mImageP_A.col(nIndex);
			


			double X = mPoint.at<double>(0 , 0);
			double Y = mPoint.at<double>(1 , 0);
			double Z = mPoint.at<double>(2 , 0);
			
		    int 	nOriginalU_A = mPoint2D.at<double>(0 , 0) - gROI_A[0],
			 		nOriginalV_A = mPoint2D.at<double>(1 , 0) - gROI_A[1];



			double nGradientX = mGradient_AX.at<double>(nOriginalV_A, nOriginalU_A);
			double nGradientY = mGradient_AY.at<double>(nOriginalV_A, nOriginalU_A);

			// mCheckGround.at<double>(v , u) = nGradientY * mDifference.at<double>(v , u);

			J_error_xy(0,0) = nGradientX * mDifference.at<double>(v , u);
			J_error_xy(0,1) = nGradientY * mDifference.at<double>(v , u);				

			if (sqrt(J_error_xy(0,0) * J_error_xy(0,0) + J_error_xy(0,1) * J_error_xy(0,1)) > 70000 && Z > 0.1){
				// cout << "Difference is " << mDifference.at<double>(v , u) << endl;
				// cout << "Gradients are " << nGradientX << " " << nGradientY << endl;

				// cv::circle 	( 	mColoredROI_A,
				// 				cv::Point2d(u , v),
				// 				3,
				// 				cv::Scalar(100 , 0 , 0));

				// cv::circle 	( 	mColoredROI_B,
				// 				cv::Point2d(u , v),
				// 				3,
				// 				cv::Scalar(100 , 0 , 0));


				double nValue = sqrt(J_error_xy(0,0) * J_error_xy(0,0) + J_error_xy(0,1) * J_error_xy(0,1));

				


				nNum++;
				J_xy_ksai(0,0) = fx/Z;
				J_xy_ksai(0,1) = 0;
				J_xy_ksai(0,2) = -(fx*X)/(Z*Z);
				J_xy_ksai(0,3) = -(fx*X*Y)/(Z*Z);
				J_xy_ksai(0,4) = fx+(fx*X*X)/(Z*Z);
				J_xy_ksai(0,5) = -(fx*Y)/Z;
				
				
				J_xy_ksai(1,0) = 0;
				J_xy_ksai(1,1) = fy/Z;
				J_xy_ksai(1,2) = -(fy*Y)/(Z*Z);
				J_xy_ksai(1,3) = -fy-(fy*Y*Y)/(Z*Z);
				J_xy_ksai(1,4) = (fy*X*Y)/(Z*Z);
				J_xy_ksai(1,5) = (fy*X)/Z;

				double nRatio = 1;
				if (nValue > 4000000){
					nRatio = 4000000/nValue;
					cout << "Robust" << endl;
				}

				rhophi += J_error_xy*J_xy_ksai * nRatio;

				// if ((J_error_xy*J_xy_ksai)(0 , 0) < -1e+20 || (J_error_xy*J_xy_ksai)(0 , 0) > 1e+20){
				// 	// cout << "rhophi is "
				// 	cout << endl << endl;
				// 	cout << "gradients are " << J_error_xy << endl;
				// 	cout << "J_xy_ksai is " << endl << J_xy_ksai << endl;
				// 	cout << endl << endl;
				// }
			}
	}

	// cv::imshow("gradient ground " , ApplyColor(mCheckGround));
	// cv::waitKey(0);


	// cout << "Num is " << nNum << endl;
	if (nNum!=0){
		rhophi /= nNum;		
	}
	// cout << "rhophi is " << endl << rhophi << endl;

	// cv::imshow("ROI_A" , mGrayROI_A);
	// cv::waitKey(0);
	// cv::imshow("ROI_B" , mGrayROI_B);
	// cv::waitKey(0);
	// cv::imshow("Difference" , ApplyColor(mCheckGround));
	// cv::waitKey(0);

	return rhophi;
}
