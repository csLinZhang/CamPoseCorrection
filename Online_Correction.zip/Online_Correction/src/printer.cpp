#include <iostream>

using namespace std;

void printSum(int sum)
{
	cout<<"sum: "<<sum<<endl;
	return;
}


