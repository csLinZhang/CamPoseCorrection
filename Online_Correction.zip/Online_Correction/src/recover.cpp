#include "../include/recover.h"
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <opencv2/calib3d/calib3d.hpp>


cv::Point3d ConvertMatToPoint3D(cv::Mat mPoint3d){
	if (mPoint3d.rows>3){
		mPoint3d = mPoint3d.rowRange(0 , 3);
	}
	return cv::Point3d(	mPoint3d.at<double>(0 , 0),
						mPoint3d.at<double>(1 , 0),
						mPoint3d.at<double>(2 , 0));
}

cv::Point2d ConvertMatToPoint2D(cv::Mat mPoint2d){
	if (mPoint2d.rows>2){
		mPoint2d = mPoint2d.rowRange(0 , 2);
	}
	return cv::Point2d (mPoint2d.at<double>(0 , 0) , 
						mPoint2d.at<double>(1 , 0));
}


Sophus::SE3 RecoverPoseByPnP(cv::Mat mHomography , cv::Mat mK_C , cv::Mat mK_G , cv::Size iBirdsEyeSize){
	
	cv::Mat mK_G_Augmentation = mK_G.colRange(0 , 2);
	cv::Mat mK_G_inv = mK_G.inv();
	cv::Mat mK_G_inv_Augmentation = mK_G_inv.rowRange(0 , 2);

	cout << "mK_G_Augmentation is: " << endl << mK_G_Augmentation << endl;

	cv::hconcat(mK_G_Augmentation , cv::Mat::zeros(3, 1, CV_64FC1) , mK_G_Augmentation);
	cv::hconcat(mK_G_Augmentation , mK_G.col(2) , mK_G_Augmentation);


	cv::vconcat(mK_G_inv_Augmentation , cv::Mat::zeros(1, 3, CV_64FC1) , mK_G_inv_Augmentation);
	cv::vconcat(mK_G_inv_Augmentation , mK_G_inv.row(2) , mK_G_inv_Augmentation);

	cout << "mK_G_Augmentation is: " << endl << mK_G_Augmentation << endl;


	cout << "mK_G_Augmentation inv is: " << endl << mK_G_inv_Augmentation << endl;



	cv::Mat mPoint_LeftTop , mPoint_LeftBottom , mPoint_RightTop , mPoint_RightBottom , mPoint_Center;
	int nWidth = iBirdsEyeSize.width , nHeight = iBirdsEyeSize.height;
	//Set the region of birds eye image.
	mPoint_LeftTop = (cv::Mat_<double>(3 , 1) << 0 , 0 , 1);
	mPoint_LeftBottom = (cv::Mat_<double>(3 , 1) << 100 , 100 , 1);
	mPoint_RightTop = (cv::Mat_<double>(3 , 1) << nWidth , 0 , 1);
	mPoint_RightBottom = (cv::Mat_<double>(3 , 1) << nWidth -300 , 100 , 1);
	mPoint_Center = (cv::Mat_<double>(3 , 1) << nWidth/2 , nHeight/2-300 , 1);

	cv::Point3d iPoint_LeftTop = ConvertMatToPoint3D((mK_G_inv_Augmentation * mPoint_LeftTop));
	cv::Point3d iPoint_LeftBottom = ConvertMatToPoint3D((mK_G_inv_Augmentation * mPoint_LeftBottom));
	cv::Point3d iPoint_RightTop = ConvertMatToPoint3D((mK_G_inv_Augmentation * mPoint_RightTop));
	cv::Point3d iPoint_RightBottom = ConvertMatToPoint3D((mK_G_inv_Augmentation * mPoint_RightBottom));
	cv::Point3d iPoint_Center = ConvertMatToPoint3D((mK_G_inv_Augmentation * mPoint_Center));

	//Log
	cout << "Left Top 3D is " << endl << iPoint_LeftTop << endl;
	cout << "Left Bottom 3D is " << endl << iPoint_LeftBottom << endl;
	cout << "Right Top 3D is " << endl << iPoint_RightTop << endl;
	cout << "Right Bottom 3D is " << endl << iPoint_RightBottom << endl;
	cout << "Center 3D is " << endl << iPoint_Center << endl;


	cv::Mat 	mImagePoint_LeftTop , mImagePoint_LeftBottom ,
			 	mImagePoint_RightTop , mImagePoint_RightBottom , mImagePoint_Center;

	//Calculate point on the image.
	mImagePoint_LeftTop = mHomography * mPoint_LeftTop;
	mImagePoint_LeftTop /= mImagePoint_LeftTop.at<double>(2 , 0);
	cout << "mImagePoint_LeftTop is "  << endl << mImagePoint_LeftTop << endl;

	mImagePoint_LeftBottom = mHomography * mPoint_LeftBottom;
	mImagePoint_LeftBottom /= mImagePoint_LeftBottom.at<double>(2 , 0);
	cout << "mImagePoint_LeftBottom is "  << endl << mImagePoint_LeftBottom << endl;

	mImagePoint_RightTop = mHomography * mPoint_RightTop;
	mImagePoint_RightTop /= mImagePoint_RightTop.at<double>(2 , 0);
	cout << "mImagePoint_RightTop is "  << endl << mImagePoint_RightTop << endl;

	mImagePoint_RightBottom = mHomography * mPoint_RightBottom;
	mImagePoint_RightBottom /= mImagePoint_RightBottom.at<double>(2 , 0);
	cout << "mImagePoint_RightBottom is "  << endl << mImagePoint_RightBottom << endl;

	mImagePoint_Center = mHomography * mPoint_Center;
	mImagePoint_Center /= mImagePoint_Center.at<double>(2 , 0);
	cout << "mImagePoint_Center is "  << endl << mImagePoint_Center << endl;


	cv::Point2d iPoint2d_LeftTop = ConvertMatToPoint2D(mImagePoint_LeftTop);
	cv::Point2d iPoint2d_LeftBottom = ConvertMatToPoint2D(mImagePoint_LeftBottom);
	cv::Point2d iPoint2d_RightTop = ConvertMatToPoint2D(mImagePoint_RightTop);
	cv::Point2d iPoint2d_RightBottom = ConvertMatToPoint2D(mImagePoint_RightBottom);
	cv::Point2d iPoint2d_Center = ConvertMatToPoint2D(mImagePoint_Center);

	//Log
	cout << "Left Top 2D is " << endl << iPoint2d_LeftTop << endl;
	cout << "Left Bottom 2D is " << endl << iPoint2d_LeftBottom << endl;
	cout << "Right Top 2D is " << endl << iPoint2d_RightTop << endl;
	cout << "Right Bottom 2D is " << endl << iPoint2d_RightBottom << endl;
	cout << "Center 2D is " << endl << iPoint2d_Center << endl;

	vector<cv::Point2d> gPoints2d;
	vector<cv::Point3d> gPoints3d;

	gPoints3d.push_back(iPoint_LeftTop);
	gPoints3d.push_back(iPoint_LeftBottom);
	gPoints3d.push_back(iPoint_RightTop);
	gPoints3d.push_back(iPoint_RightBottom);
	gPoints3d.push_back(iPoint_Center);

	gPoints2d.push_back(iPoint2d_LeftTop);
	gPoints2d.push_back(iPoint2d_LeftBottom);
	gPoints2d.push_back(iPoint2d_RightTop);
	gPoints2d.push_back(iPoint2d_RightBottom);
	gPoints2d.push_back(iPoint2d_Center);



	// cout << "Object points are  " << endl << mObjectPoints << endl;

	// cout << "Image points are  " << endl << mImagePoints << endl;

	cv::Mat mRVec , mtVec;
	cv::solvePnP 	( 	gPoints3d,
						gPoints2d,
						mK_C,
						cv::Mat::zeros(4 , 1, CV_64FC1),
						mRVec,
						mtVec,
						false,
						cv::SOLVEPNP_ITERATIVE);

	cout << "R vec is " << endl << mRVec << endl;
	cout << "t is " << endl << mtVec << endl;					 	

}


Sophus::SE3 RecoverPoseByPnP(cv::Mat mHomography , cv::Mat mK_C , cv::Mat mK_G , vector<cv::Mat> gPointsBirdsEye,
								cv::Mat & mRVec , cv::Mat & mtVec){
	//Augment K_G
	cv::Mat mK_G_Augmentation = mK_G.colRange(0 , 2);
	cv::Mat mK_G_inv = mK_G.inv();
	cv::Mat mK_G_inv_Augmentation = mK_G_inv.rowRange(0 , 2);


	cv::hconcat(mK_G_Augmentation , cv::Mat::zeros(3, 1, CV_64FC1) , mK_G_Augmentation);
	cv::hconcat(mK_G_Augmentation , mK_G.col(2) , mK_G_Augmentation);


	cv::vconcat(mK_G_inv_Augmentation , cv::Mat::zeros(1, 3, CV_64FC1) , mK_G_inv_Augmentation);
	cv::vconcat(mK_G_inv_Augmentation , mK_G_inv.row(2) , mK_G_inv_Augmentation);

	//Generate all 3d points.
	vector<cv::Point3d> gPoints3d;
	vector<cv::Point2d> gPoints2d;

	for (auto mPoint : gPointsBirdsEye){
		cv::Point3d iPoint = ConvertMatToPoint3D((mK_G_inv_Augmentation * mPoint));
		gPoints3d.push_back(iPoint);
	}


	//Generate all 2d points.

	for (auto mPoint : gPointsBirdsEye){
		cv::Mat mImagePoint = mHomography * mPoint;
		mImagePoint /= mImagePoint.at<double>(2 , 0);	
		cv::Point2d iPoint2d = ConvertMatToPoint2D(mImagePoint);
		gPoints2d.push_back(iPoint2d);
	}	

	cv::solvePnP 	( 	gPoints3d,
						gPoints2d,
						mK_C,
						cv::Mat::zeros(4 , 1, CV_64FC1),
						mRVec,
						mtVec,
						false,
						cv::SOLVEPNP_ITERATIVE);

	cout << "R vec is " << endl << mRVec << endl;
	cout << "t is " << endl << mtVec << endl;	



}









// Sophus::SE3 RecoverPose(cv::Mat mHomography , cv::Mat mK_C , cv::Mat mK_G){
// 	//Calculate s*T_CG*K_G^-1




// 	cv::Mat mK_G_Augmentation = mK_G.colRange(0 , 2);
// 	cv::Mat mK_G_inv = mK_G.inv();
// 	cv::Mat mK_G_inv_Augmentation = mK_G_inv.rowRange(0 , 2);

// 	cout << "mK_G_Augmentation is: " << endl << mK_G_Augmentation << endl;

// 	cv::hconcat(mK_G_Augmentation , cv::Mat::zeros(3, 1, CV_64FC1) , mK_G_Augmentation);
// 	cv::hconcat(mK_G_Augmentation , mK_G.col(2) , mK_G_Augmentation);


// 	cv::vconcat(mK_G_inv_Augmentation , cv::Mat::zeros(1, 3, CV_64FC1) , mK_G_inv_Augmentation);
// 	cv::vconcat(mK_G_inv_Augmentation , mK_G_inv.row(2) , mK_G_inv_Augmentation);

// 	cout << "mK_G_Augmentation is: " << endl << mK_G_Augmentation << endl;


// 	cout << "mK_G_Augmentation inv is: " << endl << mK_G_inv_Augmentation << endl;

// 	cv::Mat mLessResult = mHomography * mK_C.inv() * mK_G_Augmentation;
// 	cout << "Less result is " << endl << mLessResult << endl;

// 	//Recover scale
// 	cv::Mat mFirstColumn;
// 	cv::normalize(mLessResult.col(0) , mFirstColumn);
// 	cout << "mFirstColumn is " << endl << mFirstColumn << endl;

// 	double nScale = mFirstColumn.at<double>(0 , 0)/mLessResult.at<double>(0 , 0);

// 	mLessResult *= nScale;
// 	cout << "Scaled result is  " << endl << mLessResult << endl; 

// 	Sophus::SE3 sResult;
// 	return sResult;
	
// }