
//Standard
#include <iostream>
#include <vector>
#include <time.h>

//OpenCV
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <opencv2/calib3d/calib3d.hpp>
#include <opencv2/imgproc/imgproc.hpp>

#include <opencv2/opencv.hpp>


#include "config.h"
#include "photometric.h"

using namespace std;
	

cv::Mat mHomographyFront = (cv::Mat_<double>(3 , 3) << 	 -0.921313 ,	1.466052 ,	-168.998622	,
														 0.182551 ,	0.729686 ,	-514.731272	,
														 0.000224 ,	0.002246 ,	-1.070975	 );



// cv::Mat mHomographyFront = (cv::Mat_<double>(3 , 3) << 	 3.624814214596401, -5.83847309925347, 671.3058947699349,
//  														-0.7260718719983652, -2.928001574692305, 2035.001483964908,
//  														-0.0008965262632917056, -0.00895908830862065, 4.234624985536317 );




cv::Mat mHomographyLeft = (cv::Mat_<double>(3 , 3) << 	 -1.251914 , -1.281507 , 1248.074434,	
														 -0.341446 , -0.291944 , 518.905259,	
														 -0.001976 , -0.000316 , 1.196932);

// cv::Mat mHomographyLeft = (cv::Mat_<double>(3 , 3) << 	 -4.76741868579833, -4.925128457046729, 4793.321759025614,
// 														 -1.296522445418182, -1.11616560802237, 1993.705019618292,
// 														 -0.007540651649823177, -0.001195719650199214, 4.593986585056144);


cv::Mat mHomographyBack = (cv::Mat_<double>(3 , 3) << 	 1.364389 , -1.604490 , 438.469726,	
														 -0.053790 , -0.655889 , 348.286934,	
														 0.000033 , -0.002588 , 1.809270);

// cv::Mat mHomographyBack = (cv::Mat_<double>(3 , 3) << 	 -4.255091187526246, 5.021150458275706, -1382.537476470596,
// 														 0.1694235256188409, 2.041786866047933, -1083.073898065339,
// 														 -7.106538479109463e-05, 0.008165668721193934, -5.73122963071366);	



cv::Mat mHomographyRight = (cv::Mat_<double>(3 , 3) << 	 1.177682 , 1.180053  , -1051.645728,	
														 0.302534 , -0.266407 ,	215.612475,	
														 0.002105 , -0.000010 ,	-0.963528);

// cv::Mat mHomographyRight = (cv::Mat_<double>(3 , 3) << 	 4.025695069253493, 4.068886027433928, -3593.269933191085,
// 														 1.043074267557375, -0.9201337857123347, 746.3165105193605,
// 														 0.007222034602550212, -4.381463865540835e-05, -3.283181021975483);




/*
Front:
[-0.9241089398994728, 1.4541930028811, -168.2183133674759;
 0.1816118422514512, 0.7362146775961238, -513.4604429660375;
 0.000224, 0.002227764687051598, -1.061628254489334]
Left: 
[-1.251914, -1.281507, 1248.074434;
 -0.341446, -0.291944, 518.905259;
 -0.001976, -0.000316, 1.196932]
Back: 
[1.364389, -1.60449, 438.469726;
 -0.05379, -0.6558890000000001, 348.286934;
 3.3e-05, -0.002588, 1.80927]
Right: 
[1.177682, 1.180053, -1051.645728;
 0.302534, -0.266407, 215.612475;
 0.002105, -1e-05, -0.9635280000000001]

*/



void LoadIntrinsics(cv::Mat & mFrontK , cv::Mat & mFrontD , cv::Mat & mFrontP,
					cv::Mat & mLeftK , cv::Mat & mLeftD , cv::Mat & mLeftP,
					cv::Mat & mBackK , cv::Mat & mBackD , cv::Mat &mBackP,
					cv::Mat & mRightK , cv::Mat & mRightD , cv::Mat & mRightP){
		string aFileName = "./config/intrinsics(3).xml";
	    cv::FileStorage fs(aFileName, cv::FileStorage::READ);
        // cv::Mat mFrontK , mFrontD , mFrontP;
        // cv::Mat mLeftK , mLeftD , mLeftP;
        // cv::Mat mBackK , mBackD , mBackP;
        // cv::Mat mRightK , mRightD , mRightP;

        fs["f_intrinsic"] >> mFrontK;
        fs["f_distortion"] >> mFrontD;
        fs["f_P"] >> mFrontP;

        fs["l_intrinsic"] >> mLeftK;
        fs["l_distortion"] >> mLeftD;
        fs["l_P"] >> mLeftP;

        fs["b_intrinsic"] >> mBackK;
        fs["b_distortion"] >> mBackD;
        fs["b_P"] >> mBackP;

        fs["r_intrinsic"] >> mRightK;
        fs["r_distortion"] >> mRightD;
        fs["r_P"] >> mRightP;

}


vector<vector<cv::Point2f>> GenerateSingleMappingTable(cv::Mat mHomography , cv::Size iCameraImageSize, cv::Size iImageSize , cv::Mat mK , cv::Mat mD , cv::Mat mP){
        vector<vector<cv::Point2f>> gMappingTable;
        gMappingTable.reserve(iImageSize.height);
        for (int y=0;y<iImageSize.height;y++){
                //Generate the table of this line.
                vector<cv::Point2f> gSubMappingTable;
                gSubMappingTable.reserve(iImageSize.width);
                for (int x=0;x<iImageSize.width;x++){
                        cv::Mat mPoint = (cv::Mat_<double>(3 , 1) << x , y , 1);
                        mPoint = mHomography * mPoint;

                        mPoint = mK.inv() * mPoint;
                        cv::Point2f iPoint(mPoint.at<double>(0 , 0)/mPoint.at<double>(2 , 0) , mPoint.at<double>(1 , 0)/mPoint.at<double>(2 , 0));
                        if (mPoint.at<double>(2 , 0) == 0){
                                iPoint = cv::Point2f(0 , 0);
                        }
                        gSubMappingTable.push_back(iPoint);

                }
                cv::fisheye::distortPoints(gSubMappingTable, gSubMappingTable, mK, mD);
                for (auto & item : gSubMappingTable){
                        if (item.x <= 0.0){
                                item.x = 0.0;
                        }else if (item.x >= (float)(iCameraImageSize.width-1)){
                                item.x = (float)(iCameraImageSize.width-1);
                        }
                        if (item.y <=0.0){
                                item.y = 0.0;
                        }else if (item.y >= (float)(iCameraImageSize.height-1)){
                                item.y = (float)(iCameraImageSize.height-1);
                        }
                }
                gMappingTable.push_back(gSubMappingTable);
        }
        return gMappingTable;
}





void Generate4BirdView(		cv::Mat & iFrontBirdsEyeFrame , 
							cv::Mat & iLeftBirdsEyeFrame , 
							cv::Mat & iBackBirdsEyeFrame , 
							cv::Mat & iRightBirdsEyeFrame){

	cv::Mat mFrontK , mFrontD , mFrontP;
	cv::Mat mLeftK , mLeftD , mLeftP;
	cv::Mat mBackK , mBackD , mBackP;
	cv::Mat mRightK , mRightD , mRightP;

	LoadIntrinsics(		mFrontK, mFrontD, mFrontP,
					 	mLeftK, mLeftD, mLeftP,
					 	mBackK, mBackD, mBackP, 
					 	mRightK, mRightD, mRightP);


	vector<vector<cv::Point2f>> gFrontMappingTable , gLeftMappingTable , gBackMappingTable , gRightMappingTable;


	cout << "Generate Front Table" << endl;
	gFrontMappingTable = GenerateSingleMappingTable(mHomographyFront , iCameraImageSize, iBirdEyeSize , mFrontK , mFrontD , mFrontP);
	cout << "Generate Left Table" << endl;
	gLeftMappingTable = GenerateSingleMappingTable(mHomographyLeft , iCameraImageSize, iBirdEyeSize , mLeftK , mLeftD , mLeftP);
	cout << "Generate Back Table" << endl;
	gBackMappingTable = GenerateSingleMappingTable(mHomographyBack , iCameraImageSize, iBirdEyeSize , mBackK , mBackD , mBackP);
	cout << "Generate Right Table" << endl;
	gRightMappingTable = GenerateSingleMappingTable(mHomographyRight , iCameraImageSize, iBirdEyeSize , mRightK , mRightD , mRightP);


	

	int H = iBirdEyeSize.height;
	int W = iBirdEyeSize.width;
	//Init images;
	iFrontBirdsEyeFrame = cv::Mat::zeros(W,H,CV_8UC3);
	iLeftBirdsEyeFrame = cv::Mat::zeros(W,H,CV_8UC3);
	iBackBirdsEyeFrame = cv::Mat::zeros(W,H,CV_8UC3);
	iRightBirdsEyeFrame = cv::Mat::zeros(W,H,CV_8UC3);



	vector<cv::Mat> gImages;
	cv::Mat iFrontFrame , iLeftFrame , iBackFrame , iRightFrame;

	iFrontFrame = cv::imread("./img/front.jpg");
	iLeftFrame = cv::imread("./img/left.jpg");
	
	// cv::Mat iLeftFrameUndistortion;
	// cv::Size iUndistSize = cv::Size(iFrontFrame.size().width * 3 , iFrontFrame.size().height * 3);
	// cv::fisheye::undistortImage(iLeftFrame, iLeftFrameUndistortion, mLeftK, mLeftD, mLeftP , iUndistSize);
	// cv::imshow("const cv::String &winname", iLeftFrameUndistortion);
	// cv::waitKey(0);
	// cv::imwrite("undistort.jpg", iLeftFrameUndistortion);

	iBackFrame = cv::imread("./img/back.jpg");
	iRightFrame = cv::imread("./img/right.jpg");


	
	gImages.push_back(iFrontFrame);
	gImages.push_back(iLeftFrame);
	gImages.push_back(iBackFrame);
	gImages.push_back(iRightFrame);		



	for (int v=0;v<iBirdEyeSize.height;v++){
		for (int u=0;u<iBirdEyeSize.width;u++){
			cv::Point2f iMapping = gFrontMappingTable[v][u];
			iFrontBirdsEyeFrame.at<cv::Vec3b>(v , u) = gImages[0].at<cv::Vec3b>((int)iMapping.y , (int) iMapping.x);

			iMapping = gLeftMappingTable[v][u];
			iLeftBirdsEyeFrame.at<cv::Vec3b>(v , u) = gImages[1].at<cv::Vec3b>((int)iMapping.y , (int) iMapping.x);

			iMapping = gBackMappingTable[v][u];
			iBackBirdsEyeFrame.at<cv::Vec3b>(v , u) = gImages[2].at<cv::Vec3b>((int)iMapping.y , (int) iMapping.x);

			iMapping = gRightMappingTable[v][u];
			iRightBirdsEyeFrame.at<cv::Vec3b>(v , u) = gImages[3].at<cv::Vec3b>((int)iMapping.y , (int) iMapping.x);
		}
	}


	PhotometricAlignment(iFrontBirdsEyeFrame, iLeftBirdsEyeFrame, iBackBirdsEyeFrame, iRightBirdsEyeFrame, 1, -1, 1);


}



cv::Mat GenerateOneBirdView(	cv::Mat & iFrontBirdsEyeFrame ,
		 						cv::Mat & iLeftBirdsEyeFrame ,
		 						cv::Mat & iBackBirdsEyeFrame , 
		 						cv::Mat & iRightBirdsEyeFrame){


	int H = iBirdEyeSize.height;
	int W = iBirdEyeSize.width;
	//Init images;
	cv::Mat iBirdsEyeImage= cv::Mat::zeros(W,H,CV_8UC3);

	int maxV , minV , maxU , minU;
	int subMaxV , subMinV , subMaxU , subMinU;
	
	//Front Area
	maxV = (BIRDS_EYE_HEIGHT-CENTER_HEIGHT)/2;
	minV = 0;
	maxU = (BIRDS_EYE_WIDTH/4*3);
	minU = BIRDS_EYE_WIDTH/4;
	for (int v=0;v<= maxV;v++){
			for (int u= minU;u<= maxU;u++){
	            //Front area                   
	                //Front area                                   
					iBirdsEyeImage.at<cv::Vec3b>(v , u) = iFrontBirdsEyeFrame.at<cv::Vec3b>(v , u);
        }
    }


    //Left
	maxV = BIRDS_EYE_HEIGHT;
    maxU = BIRDS_EYE_WIDTH/2;

    subMaxV = (BIRDS_EYE_HEIGHT - CENTER_HEIGHT)/2;
    subMinV = (BIRDS_EYE_HEIGHT + CENTER_HEIGHT)/2;
    subMaxU = (BIRDS_EYE_WIDTH - CENTER_WIDTH)/2;
	
	for (int v=0;v< maxV;v++){
			for (int u=0;u<=subMaxU;u++){
		        if (u<((BIRDS_EYE_WIDTH)/4+v/2) && u <= ((BIRDS_EYE_WIDTH+2*BIRDS_EYE_HEIGHT)/4-v/2)){
		                //Left area.            	
						iBirdsEyeImage.at<cv::Vec3b>(v , u) = iLeftBirdsEyeFrame.at<cv::Vec3b>(v , u);
		    	}
		}
    }


    //Back
	minV = (BIRDS_EYE_HEIGHT + CENTER_HEIGHT)/2;
    maxV = BIRDS_EYE_HEIGHT;
    minU = BIRDS_EYE_WIDTH/4;
    maxU = (BIRDS_EYE_WIDTH/4*3);
	for (int v= minV;v< maxV;v++){
			for (int u= minU;u<= maxU;u++){
		        if (u < ((BIRDS_EYE_WIDTH)/4+v/2) && u > ((BIRDS_EYE_WIDTH+2*BIRDS_EYE_HEIGHT)/4-v/2)){
		                //Back area.    
						iBirdsEyeImage.at<cv::Vec3b>(v , u) = iBackBirdsEyeFrame.at<cv::Vec3b>(v , u);
		    	}
		    }
    }
	


    minU = BIRDS_EYE_WIDTH/2;
    subMinV = (BIRDS_EYE_WIDTH + CENTER_WIDTH)/2;
    subMaxV = (BIRDS_EYE_HEIGHT - CENTER_HEIGHT)/2;
    subMinU = (BIRDS_EYE_WIDTH + CENTER_WIDTH)/2;
	
	for (int v=0;v<BIRDS_EYE_HEIGHT;v++){
			for (int u= subMinU;u<BIRDS_EYE_WIDTH;u++){	   		
	        if (u>=((BIRDS_EYE_WIDTH)/4+v/2) && u > ((BIRDS_EYE_WIDTH+2*BIRDS_EYE_HEIGHT)/4-v/2)) {
	            	//Right area.
					iBirdsEyeImage.at<cv::Vec3b>(v , u) = iRightBirdsEyeFrame.at<cv::Vec3b>(v , u);	
	        }
        }
    }


    return iBirdsEyeImage;

}


void ShowMatrix(cv::Mat & mMat , string aWindowName = "show"){
	cv::Mat mCloneMat = mMat.clone();
	cv::Mat mNormalize , mColor;
	cv::normalize(mCloneMat,mNormalize,0,255,cv::NORM_MINMAX,CV_8U);
	cv::applyColorMap(mNormalize, mColor, cv::COLORMAP_JET);
	cv::imshow(aWindowName,mColor);
	cv::waitKey(0);	
}


cv::Mat CompareDifference(cv::Mat & mOverlapFirst, cv::Mat & mOverlapSecond , bool bShow){
	cv::Mat mOverlapFirstGray , mOverlapSecondGray;
	cv::Mat mDiffGray;
	//Convert overlap region to gray image.
	cv::cvtColor(mOverlapFirst,mOverlapFirstGray,cv::COLOR_BGR2GRAY);
	cv::cvtColor(mOverlapSecond,mOverlapSecondGray,cv::COLOR_BGR2GRAY);
	//Convert the data type so it can be computed efficiently.
	mOverlapFirstGray.convertTo(mOverlapFirstGray, CV_64FC1);
	mOverlapSecondGray.convertTo(mOverlapSecondGray, CV_64FC1);
	//Calculate the difference.

	double nMeanFirst = 0.0 , nMeanSecond = 0.0;
	for (int u=0;u<mOverlapFirst.size().width;u++){
		for (int v=0;v<mOverlapFirst.size().height;v++){
			nMeanFirst += mOverlapFirstGray.at<double>(v , u);
			nMeanSecond += mOverlapSecondGray.at<double>(v , u);
		}
	}
	nMeanFirst/=(mOverlapFirst.size().width * mOverlapFirst.size().height);
	nMeanSecond/=(mOverlapSecond.size().width * mOverlapSecond.size().height);

	double nRatio = nMeanFirst / nMeanSecond;
	if (nRatio >1){
		mOverlapFirstGray = mOverlapFirstGray/nRatio; 
	}else{
		mOverlapSecondGray = mOverlapSecondGray/nRatio;
	}
	// for (int u=0;u<mOverlapFirst.size().width;u++){
	// 	for (int v=0;v<mOverlapFirst.size().height;v++){
	// 		mOverlapFirstGray.at<double>(v , u) -= nMeanFirst;
	// 		mOverlapSecondGray.at<double>(v , u) -= nMeanSecond;
	// 	}
	// }
	cv::subtract(mOverlapFirstGray,mOverlapSecondGray,mDiffGray,cv::noArray(),CV_64FC1);

	//Whether show the difference.
	if (bShow){
		ShowMatrix(mDiffGray);
	}
	
	return mDiffGray;
}

// vector<double> CompareSparseDifference(	cv::Mat & mOverlapFirst, cv::Mat & mOverlapSecond ,
// 										vector<cv::Point2f> & gKeyPoint1, vector<cv::Point2f> & gKeyPoint2,
// 										cv::Mat & mHomographyFirst , cv::Mat & mHomographySecond){
// 	vector<double> gDifference;
// 	gDifference.reserve(gKeyPoint.size());
// 		// cv::Mat mPoint = cv::Vec3d(item.x , item.y , 1);
// 		// cv::Mat mPointFirst = mHomographyFirst * mPoint;
// 		// cv::Mat mPointSecond = mHomographySecond * mPoint;

// 		// cv::Point2f iPoint1(	mPointFirst.at<double>(0 , 0)/mPointFirst.at<double>(2 , 0) ,
// 		// 						mPointFirst.at<double>(1 , 0)/mPointFirst.at<double>(2 , 0));
// 	  //       if (mPointFirst.at<double>(2 , 0) == 0){
// 	  //               iPoint = cv::Point2f(0 , 0);
// 	  //       }

// 	  //       cv::Point2f iPoint2(	mPointSecond.at<double>(0 , 0)/mPointSecond.at<double>(2 , 0) ,
// 			// 						mPointSecond.at<double>(1 , 0)/mPointSecond.at<double>(2 , 0));
// 	  //       if (mPointSecond.at<double>(2 , 0) == 0){
// 	  //               iPoint = cv::Point2f(0 , 0);
// 	  //       }


// 	double nMeanFirst = 0.0 , nMeanSecond = 0.0;
	
// 	//Normalize
// 	for (int i=0;i<gKeyPoint1.size();i++){
// 		cv::Point2f iPoint1 = gKeyPoint1[i];
// 		cv::Point2f iPoint2 = gKeyPoint2[i];
// 		nMeanFirst += mOverlapFirst.at<double>(iPoint1.y , iPoint1.x);
// 		nMeanSecond += mOverlapSecond.at<double>(iPoint2.y , iPoint2.x);
// 	}

// 	nMeanFirst /= gKeyPoint1.size();
// 	nMeanSecond /= gKeyPoint2.size();

// 	double nRatio = nMeanFirst / nMeanSecond;
// 	if (nRatio >1){
// 		for (int i=0;i<gKeyPoint1.size();i++){
// 			cv::Point2f iPoint1 = gKeyPoint1[i];
// 			cv::Point2f iPoint2 = gKeyPoint2[i];
// 			gDifference.push_back(
// 					mOverlapFirst.at<double>(iPoint1.y , iPoint1.x) / nRatio 
// 					- mOverlapSecond.at<double>(iPoint2.y , iPoint2.x)
// 				);
// 		}		
// 	}else{
// 		for (int i=0;i<gKeyPoint1.size();i++){
// 			cv::Point2f iPoint1 = gKeyPoint1[i];
// 			cv::Point2f iPoint2 = gKeyPoint2[i];
// 			gDifference.push_back(
// 					mOverlapFirst.at<double>(iPoint1.y , iPoint1.x) 
// 					- mOverlapSecond.at<double>(iPoint2.y , iPoint2.x) / nRatio
// 				);
// 		}
// 	}
// 	return gDifference;
// }


//Calculate the gradient in 2 directions.
//mOriginalImage need to be gray image.
void CalculateGradient(		cv::Mat & mOriginalImage , cv::Mat mOverlap,
							cv::Mat mK , cv::Mat mD , int nMinX , int nMinY,
							cv::Mat mHomography,
						 	cv::Mat & mGradientU , cv::Mat & mGradientV){
	//ROI_on_A_gray_64F, grad_GA_x, CV_64FC1, 1, 0, 7
	//Convert color img to gray img firstly.
	cv::Mat mOverlapGray;
	cv::cvtColor(mOverlap,mOverlapGray,cv::COLOR_BGR2GRAY);
	//Convert the data type so it can be computed efficiently.
	mOverlapGray.convertTo(mOverlapGray, CV_64FC1);
	mGradientU = mOverlapGray.clone();
	mGradientV = mOverlapGray.clone();


	for (int v=0;v<mOverlapGray.size().height;v++){
		for (int u=0;u<mOverlapGray.size().width;u++){
			int nX = u + nMinX;
			int nY = v + nMinY;
			cv::Mat mPg = (cv::Mat_<double>(3 , 1) << nX , nY , 1);
			cv::Mat mPci = mHomography * mPg;
			vector<cv::Point2f> gGradientPoints;
			gGradientPoints.reserve(9);
			//Calculate the Pci and its neighbours in the original image
			for (int i=0;i<3;i++){
				for (int j=0;j<3;j++){
					cv::Mat mPciNeighbour = mPci.clone();
					mPciNeighbour.at<double>(0 , 0) = mPciNeighbour.at<double>(0 , 0) + (j-1);
					mPciNeighbour.at<double>(1 , 0) = mPciNeighbour.at<double>(1 , 0) + (i-1);
					cv::Mat mPci3 = mK.inv() * mPciNeighbour;
					cv::Point2f iPoint(	mPci3.at<double>(0 , 0)/mPci3.at<double>(2 , 0) ,
										mPci3.at<double>(1 , 0)/mPci3.at<double>(2 , 0));
                    if (mPci3.at<double>(2 , 0) == 0){
                            iPoint = cv::Point2f(0 , 0);
                    }
                    gGradientPoints.push_back(iPoint);
				}
			}
			//Distort points
			cv::fisheye::distortPoints(gGradientPoints, gGradientPoints, mK, mD);
			//Weights to calculate the gradient.
			vector<int> gWeightsX = {-1 , 0 , 1 , -2 , 0 , 2 , -1 , 0 , 1};
			vector<int> gWeightsY = {-1 , -2 , -1 , 0 , 0 , 0 , 1 , 2, 1};
			double nGradientX = 0.0 , nGradientY = 0.0;
			for (int i=0;i<9;i++){
				cv::Point2f iPoint = gGradientPoints[i];
				int nOriginalX = (int)iPoint.x;
				int nOriginalY = (int)iPoint.y;
				nGradientX += gWeightsX[i] * mOriginalImage.at<double>(nOriginalY , nOriginalX);
				nGradientY += gWeightsY[i] * mOriginalImage.at<double>(nOriginalY , nOriginalX);
			}
			mGradientU.at<double>(v , u) = nGradientX;
			mGradientV.at<double>(v , u) = nGradientY;
		}
	}

}



cv::Mat CalculateDiffForHomography(	cv::Mat & mHomography , cv::Mat & mOverlap ,
									int nMinX , int nMinY,
									cv::Mat & mDifference ,
									cv::Mat & mGradientU , cv::Mat & mGradientV){
	int nWidth , nHeight;
	nWidth = mOverlap.size().width;
	nHeight = mOverlap.size().height;

	//Convert mOverlap to gray image.
	cv::Mat mOverlapGray;
	cv::cvtColor(mOverlap,mOverlapGray,cv::COLOR_BGR2GRAY);
	//Convert the data type so it can be computed efficiently.
	mOverlapGray.convertTo(mOverlapGray, CV_64FC1);

	// cv::Mat mGradientAll = (cv::Mat_<double>(1 , 8) << 	0.0 , 0.0 , 0.0 , 0.0 ,
	// 													0.0 , 0.0 , 0.0 , 0.0);
	cv::Mat mGradientAll = (cv::Mat_<double>(1 , 9) << 	0.0 , 0.0 , 0.0 , 0.0 ,
														0.0 , 0.0 , 0.0 , 0.0 , 0.0);
	//Get the inverse homography.
	
	cv::Mat mHomographyInv = mHomography.inv();


	double nMeanDiff = 0.0;
	for (int u=0;u<nWidth;u++){
		for (int v=0;v<nHeight;v++){
			nMeanDiff += mDifference.at<double>(v , u) * mDifference.at<double>(v , u);
		}
	}
	nMeanDiff /= (nWidth * nHeight);

	double nMeanGradient = 0.0;

	for (int u=0;u<nWidth;u++){
		for (int v=0;v<nHeight;v++){
			nMeanGradient += mGradientU.at<double>(v , u) * mGradientU.at<double>(v , u);
			nMeanGradient += mGradientV.at<double>(v , u) * mGradientV.at<double>(v , u);
		}
	}
	nMeanGradient /= (nWidth * nHeight);


	int nPointNum = 0;
	vector<cv::Point2f> gPoints;
	vector<cv::Point2f> gAllPoints;
	for (int u=0;u<nWidth;u++){
		for (int v=0;v<nHeight;v++){
			double nGradient2 = 	mGradientU.at<double>(v , u) * mGradientU.at<double>(v , u)
								+ 	mGradientV.at<double>(v , u) * mGradientV.at<double>(v , u);
			if (mDifference.at<double>(v , u) * mDifference.at<double>(v , u) < 1.5 * nMeanDiff
				|| nGradient2 <  1.5 * nMeanGradient){
				continue;
			}

			gAllPoints.push_back(cv::Point2f(u , v));
			nPointNum ++ ;

			int nXg = u + nMinX;
			int nYg = v + nMinY;

			cv::Mat mPg = (cv::Mat_<double>(3 , 1) << nXg , nYg , 1);
			cv::Mat mPci = mHomography * mPg;
			//divide by z
			double nZci = mPci.at<double>(2 , 0);
			mPci /= nZci;
			


			cv::Mat mPgNotNormalize = mHomographyInv * mPci;
			double nZg = mPgNotNormalize.at<double>(2 , 0);

			//nZg * nZci = 1
			// cv::Mat mGradientPg2Hi = (cv::Mat_<double>(2 , 8));
			cv::Mat mGradientPg2Hi = (cv::Mat_<double>(2 , 9));

			double nXci = mPci.at<double>(0 , 0);
			double nYci = mPci.at<double>(1 , 0);


			//Use nXci , nYci , nXg , nYg , nZg to calculate the gradient.
			// mGradientPg2Hi.at<double>(0 , 0) = nXci/nZg;
			// mGradientPg2Hi.at<double>(1 , 0) = 0;

			// mGradientPg2Hi.at<double>(0 , 1) = nYci/nZg;
			// mGradientPg2Hi.at<double>(1 , 1) = 0;

			// mGradientPg2Hi.at<double>(0 , 2) = 1/nZg;
			// mGradientPg2Hi.at<double>(1 , 2) = 0;

			// mGradientPg2Hi.at<double>(0 , 3) = 0;
			// mGradientPg2Hi.at<double>(1 , 3) = nXci/nZg;

			// mGradientPg2Hi.at<double>(0 , 4) = 0;
			// mGradientPg2Hi.at<double>(1 , 4) = nYci/nZg;

			// mGradientPg2Hi.at<double>(0 , 5) = 0;
			// mGradientPg2Hi.at<double>(1 , 5) = 1/nZg;

			// mGradientPg2Hi.at<double>(0 , 6) = -nXg * nXci / nZg;
			// mGradientPg2Hi.at<double>(1 , 6) = -nYg * nXci / nZg;

			// mGradientPg2Hi.at<double>(0 , 7) = -nXg * nYci / nZg;
			// mGradientPg2Hi.at<double>(1 , 7) = -nYg * nYci / nZg;


			// mGradientPg2Hi.at<double>(0 , 8) = -nXg * 1 / nZg;
			// mGradientPg2Hi.at<double>(1 , 8) = -nYg * 1 / nZg;


			//Use differential in fisheye 
			mGradientPg2Hi.at<double>(0 , 0) = nXg/nZci;
			mGradientPg2Hi.at<double>(1 , 0) = 0;

			mGradientPg2Hi.at<double>(0 , 1) = nYg/nZci;
			mGradientPg2Hi.at<double>(1 , 1) = 0;

			mGradientPg2Hi.at<double>(0 , 2) = 1/nZci;
			mGradientPg2Hi.at<double>(1 , 2) = 0;

			mGradientPg2Hi.at<double>(0 , 3) = 0;
			mGradientPg2Hi.at<double>(1 , 3) = nXg/nZci;

			mGradientPg2Hi.at<double>(0 , 4) = 0;
			mGradientPg2Hi.at<double>(1 , 4) = nYg/nZci;

			mGradientPg2Hi.at<double>(0 , 5) = 0;
			mGradientPg2Hi.at<double>(1 , 5) = 1/nZci;

			mGradientPg2Hi.at<double>(0 , 6) = -nXg * nXci / nZci;
			mGradientPg2Hi.at<double>(1 , 6) = -nYg * nXci / nZci;

			mGradientPg2Hi.at<double>(0 , 7) = -nXg * nYci / nZci;
			mGradientPg2Hi.at<double>(1 , 7) = -nYg * nYci / nZci;


			mGradientPg2Hi.at<double>(0 , 8) = -nXci * 1 / nZci;
			mGradientPg2Hi.at<double>(1 , 8) = -nYci * 1 / nZci;



			cv::Mat mGradientI2Pg = (cv::Mat_<double>(1 , 2));
			mGradientI2Pg.at<double>(0 , 0) = mGradientU.at<double>(v , u);
			mGradientI2Pg.at<double>(0 , 1) = mGradientV.at<double>(v , u);





			double nGradientLoss2I = mDifference.at<double>(v , u);

			cv::Mat mGradientOneItem = nGradientLoss2I * mGradientI2Pg * mGradientPg2Hi;


			// if ( mGradientU.at<double>(v , u) * mGradientV.at<double>(v , u) < 0){
			// 	cout << "At " << v <<  " , " << u << endl;
			// 	cout << "Difference is " << mDifference.at<double>(v , u) << endl;
			// 	cout << "Gradient u is " << mGradientU.at<double>(v , u) << endl;
			// 	cout << "Gradient v is " << mGradientV.at<double>(v , u) << endl;
			// 	cout << "Zci is " << nZci << endl;
			// 	cout << "nGradientLoss2I is " << endl << nGradientLoss2I << endl;
			// 	cout << "mGradientI2Pg is " << endl << mGradientI2Pg << endl;
			// 	cout << "mGradientPg2Hi is " << endl << mGradientPg2Hi << endl;
			// 	cout << "mGradientOneItem is " << endl << mGradientOneItem << endl;
			// 	gPoints.push_back(cv::Point2f(u , v));
			// 	cout << endl << endl;
			// }



			mGradientAll = mGradientAll + mGradientOneItem;

		}
	}
	cout << "Point num is " << nPointNum << endl;
	cout << "Efficient point " << gPoints.size() << endl;

	// double nMeanAllDiff = 0.0;
	// double nMeanEfficientDiff = 0.0;
	// double nMeanAllGradient = 0.0;
	// double nMeanEfficientGradient = 0.0;
	// for (auto item : gAllPoints){
	// 	float v = item.y;
	// 	float u = item.x; 
	// 	nMeanAllDiff += mDifference.at<double>(v , u) * mDifference.at<double>(v , u);
	// 	nMeanAllGradient += mGradientU.at<double>(v , u) * mGradientU.at<double>(v , u);
	// 	nMeanAllGradient += mGradientV.at<double>(v , u) * mGradientV.at<double>(v , u);
	// }
	// nMeanAllDiff /= gAllPoints.size();
	// nMeanAllGradient /= gAllPoints.size();

	// for (auto item : gPoints){
	// 	float v = item.y;
	// 	float u = item.x; 
	// 	nMeanEfficientDiff += mDifference.at<double>(v , u) * mDifference.at<double>(v , u);
	// 	nMeanEfficientGradient += mGradientU.at<double>(v , u) * mGradientU.at<double>(v , u);
	// 	nMeanEfficientGradient += mGradientV.at<double>(v , u) * mGradientV.at<double>(v , u);	
	// }

	// nMeanEfficientDiff /= gPoints.size();
	// nMeanEfficientGradient /= gPoints.size();

	// cout << "Mean diff is " << nMeanAllDiff << endl;
	// cout << "Mean grad is " << nMeanAllGradient << endl;
	// cout << "Mean Efficient diff is " << nMeanEfficientDiff << endl;
	// cout << "Mean Efficient grad is " << nMeanEfficientGradient << endl;



	//Normalize
	mGradientAll /= nPointNum;


	// for (auto item : gPoints){
	// 	cv::circle(mOverlapGray, item, 5, cv::Scalar(100 , 1 , 1));		
	// }
	// // ShowMatrix(mOverlapGray);


	// cv::Mat iMat =  mGradientU.clone();
	// for (int u=0;u<nWidth;u++){
	// 	for (int v=0;v<nHeight;v++){
	// 		if (mGradientU.at<double>(v,  u)<0){
	// 			iMat.at<double>(v , u) = 0.0;
	// 		}else{
	// 			iMat.at<double>(v , u) = 100.0;
	// 		}
	// 	}
	// }
	// ShowMatrix(iMat);


	return mGradientAll;
}


cv::Mat UpdateHomography(cv::Mat mUpdateHomography , double nLearningRate , cv::Mat & mDiff){

	double nOriginalDet = cv::determinant(mUpdateHomography);

	cv::Mat mOriginalHomography = mUpdateHomography/*.inv()*/;

	cout << "Step is " << endl << mDiff * nLearningRate << endl;

	//First row
	mOriginalHomography.at<double>(0 , 0) = mOriginalHomography.at<double>(0 , 0) + mDiff.at<double>(0 , 0) * nLearningRate;
	mOriginalHomography.at<double>(0 , 1) = mOriginalHomography.at<double>(0 , 1) + mDiff.at<double>(0 , 1) * nLearningRate;
	mOriginalHomography.at<double>(0 , 2) = mOriginalHomography.at<double>(0 , 2) + mDiff.at<double>(0 , 2) * nLearningRate;
	//Second row
	mOriginalHomography.at<double>(1 , 0) = mOriginalHomography.at<double>(1 , 0) + mDiff.at<double>(0 , 3) * nLearningRate;
	mOriginalHomography.at<double>(1 , 1) = mOriginalHomography.at<double>(1 , 1) + mDiff.at<double>(0 , 4) * nLearningRate;
	mOriginalHomography.at<double>(1 , 2) = mOriginalHomography.at<double>(1 , 2) +  mDiff.at<double>(0 , 5) * nLearningRate;
	//Third row
	// mOriginalHomography.at<double>(2 , 0) = mOriginalHomography.at<double>(2 , 0) + mDiff.at<double>(0 , 6) * nLearningRate /10000000;
	// mOriginalHomography.at<double>(2 , 1) = mOriginalHomography.at<double>(2 , 1) + mDiff.at<double>(0 , 7) * nLearningRate /10000000;
	// mOriginalHomography.at<double>(2 , 2) = mOriginalHomography.at<double>(2 , 2) + mDiff.at<double>(0 , 8) * nLearningRate /1000000;


	mUpdateHomography = mOriginalHomography/*.inv()*/;

	mUpdateHomography = mUpdateHomography/(cv::determinant(mUpdateHomography)/nOriginalDet);


	return mUpdateHomography;
}


double CalculateLoss(cv::Mat & mOverlapFirst , cv::Mat & mOverlapSecond){
	cv::Mat mDiff = CompareDifference(mOverlapFirst, mOverlapSecond, false);
	int nWidth = mDiff.size().width , nHeight = mDiff.size().height;
	double nLoss = 0.0;
	for (int u=0;u<nWidth;u++){
		for (int v=0;v<nHeight;v++){
			nLoss += mDiff.at<double>(v , u) * mDiff.at<double>(v , u);
		}
	}
	return nLoss;
}



void Adjust(	cv::Mat & mFrontBirdsEyeFrame,
				cv::Mat & mLeftBirdsEyeFrame,
				cv::Mat & mBackBirdsEyeFrame,
				cv::Mat & mRightBirdsEyeFrame , 
				int nIteration){



			cv::Mat iFrontFrame , iLeftFrame , iBackFrame , iRightFrame;

			iFrontFrame = cv::imread("./img/front.jpg");
			iLeftFrame = cv::imread("./img/left.jpg");
			iBackFrame = cv::imread("./img/back.jpg");
			iRightFrame = cv::imread("./img/right.jpg");
			
			//Convert the data type so it can be computed efficiently.
			cv::cvtColor(iFrontFrame,iFrontFrame,cv::COLOR_BGR2GRAY);
			iFrontFrame.convertTo(iFrontFrame, CV_64FC1);

			cv::cvtColor(iLeftFrame,iLeftFrame,cv::COLOR_BGR2GRAY);
			iLeftFrame.convertTo(iLeftFrame, CV_64FC1);

			cv::cvtColor(iBackFrame,iBackFrame,cv::COLOR_BGR2GRAY);
			iBackFrame.convertTo(iBackFrame, CV_64FC1);

			cv::cvtColor(iRightFrame,iRightFrame,cv::COLOR_BGR2GRAY);
			iRightFrame.convertTo(iRightFrame, CV_64FC1);
	



			cv::Mat mFrontK , mFrontD , mFrontP;
			cv::Mat mLeftK , mLeftD , mLeftP;
			cv::Mat mBackK , mBackD , mBackP;
			cv::Mat mRightK , mRightD , mRightP;

			LoadIntrinsics(		mFrontK, mFrontD, mFrontP,
							 	mLeftK, mLeftD, mLeftP,
							 	mBackK, mBackD, mBackP, 
					 			mRightK, mRightD, mRightP);



	        cv::Mat mLFAreaF , mLFAreaL , mBLAreaB , mBLAreaL , mRBAreaR , mRBAreaB , mFRAreaF , mFRAreaR;
	        int W = BIRDS_EYE_WIDTH;
	        int H = BIRDS_EYE_HEIGHT;


        	mLFAreaF = mFrontBirdsEyeFrame(cv::Rect( W/4, 0, W/8 , W/8*2));
        	mLFAreaL = mLeftBirdsEyeFrame(cv::Rect( W/4, 0,W/8 , W/8*2));
        	mBLAreaL = mLeftBirdsEyeFrame(cv::Rect( W/4, H- W/10*2 , W/10 , W/10*2));
        	mBLAreaB = mBackBirdsEyeFrame(cv::Rect( W/4, H- W/10*2, W/10 , W/10*2));
        	mRBAreaB = mBackBirdsEyeFrame(cv::Rect( 13*W/20, H- W/10*2,W/10 , W/10*2));
        	mRBAreaR = mRightBirdsEyeFrame(cv::Rect( 13*W/20, H- W/10*2,W/10 , W/10*2));
        	mFRAreaR = mRightBirdsEyeFrame(cv::Rect( 13*W/20, 0,W/8, W/8*2));
        	mFRAreaF = mFrontBirdsEyeFrame(cv::Rect( 13*W/20, 0,W/8, W/8*2));



        	//All difference in overlap region.
        	cv::Mat mDiffLF , mDiffBL , mDiffRB , mDiffFR;
        	//All gradients in overlap region.
        	cv::Mat mLFGradientFU , mLFGradientFV , mLFGradientLU , mLFGradientLV;
        	cv::Mat mBLGradientLU , mBLGradientLV , mBLGradientBU , mBLGradientBV;
        	cv::Mat mRBGradientBU , mRBGradientBV , mRBGradientRU , mRBGradientRV;
        	cv::Mat mFRGradientRU , mFRGradientRV , mFRGradientFU , mFRGradientFV;


        	//Calculate the difference between 2 images.
        	mDiffLF = CompareDifference(mLFAreaF, mLFAreaL , false);
        	mDiffBL = CompareDifference(mBLAreaB, mBLAreaL , false);
        	mDiffRB = CompareDifference(mRBAreaR, mRBAreaB , false);
        	mDiffFR = CompareDifference(mFRAreaF, mFRAreaR , false);

        	cv::Mat mDiffFL = CompareDifference(mLFAreaL, mLFAreaF , false);
        	cv::Mat mDiffLB = -mDiffBL;
        	cv::Mat mDiffBR = -mDiffRB;
        	cv::Mat mDiffRF = -mDiffFR;

        	//Calculate the gradient in overlap regions.
        	CalculateGradient(		iFrontFrame, mLFAreaF,
        							mFrontK , mFrontD , W/4 , 0,
        							mHomographyFront,
        						 	mLFGradientFU , mLFGradientFV);

        	CalculateGradient(		iLeftFrame, mLFAreaL,
        							mLeftK , mLeftD , W/4 , 0,
        							mHomographyLeft,
        						 	mLFGradientLU , mLFGradientLV);


        	CalculateGradient(		iLeftFrame, mBLAreaL,
        							mLeftK , mLeftD , W/4 , H-W/10*2,
        							mHomographyLeft,
        						 	mBLGradientLU , mBLGradientLV);

        	CalculateGradient(		iBackFrame, mBLAreaB,
        							mBackK , mBackD , W/4 , H-W/10*2,
        							mHomographyBack,
        						 	mBLGradientBU , mBLGradientBV);



        	CalculateGradient(		iBackFrame, mRBAreaB,
        							mBackK , mBackD , 13 * W/20 , H-W/10*2,
        							mHomographyBack,
        						 	mRBGradientBU , mRBGradientBV);

        	CalculateGradient(		iRightFrame, mRBAreaR,
        							mRightK , mRightD , 13 * W/20 , H-W/10*2,
        							mHomographyRight,
        						 	mRBGradientRU , mRBGradientRV);


        	CalculateGradient(		iRightFrame, mFRAreaR,
        							mRightK , mRightD , 13 * W/20 , 0,
        							mHomographyRight,
        						 	mFRGradientRU , mFRGradientRV);

        	CalculateGradient(		iFrontFrame, mFRAreaF,
        							mFrontK , mFrontD , 13 * W/20 , 0,
        							mHomographyFront,
        						 	mFRGradientFU , mFRGradientFV);



        	// CalculateGradient2(		mLFAreaF, mLFGradientFU , mLFGradientFV);

        	// CalculateGradient2(		mLFAreaL, mLFGradientLU , mLFGradientLV);


        	// CalculateGradient2(		mBLAreaL, mBLGradientLU , mBLGradientLV);

        	// CalculateGradient2(		mBLAreaB, mBLGradientBU , mBLGradientBV);



        	// CalculateGradient2(		mRBAreaB, mRBGradientBU , mRBGradientBV);

        	// CalculateGradient2(		mRBAreaR, mRBGradientRU , mRBGradientRV);


        	// CalculateGradient2(		mFRAreaR, mFRGradientRU , mFRGradientRV);

        	// CalculateGradient2(		mFRAreaF, mFRGradientFU , mFRGradientFV);





        	// CalculateGradient(mLFAreaL, mLFGradientLU , mLFGradientLV);


        	cv::Mat mLFDiff =  CalculateDiffForHomography(mHomographyFront, mLFAreaF, W/4, 0, mDiffLF, mLFGradientFU, mLFGradientFV);


        	cv::Mat mLFDiff2 =  CalculateDiffForHomography(mHomographyLeft, mLFAreaL, W/4, 0, mDiffLF, mLFGradientLU, mLFGradientLV);



        	cv::Mat mBLDiff =  CalculateDiffForHomography(mHomographyLeft, mBLAreaL, W/4, H-W/10*2, mDiffBL, mBLGradientLU, mBLGradientLV);

        	cv::Mat mBLDiff2 =  CalculateDiffForHomography(mHomographyBack, mBLAreaB, W/4, H-W/10*2, mDiffBL, mBLGradientBU, mBLGradientBV);


        	cv::Mat mRBDiff =  CalculateDiffForHomography(mHomographyBack, mRBAreaB, 13 * W/4, H-W/10*2, mDiffBR, mRBGradientBU, mRBGradientBV);

        	cv::Mat mRBDiff2 =  CalculateDiffForHomography(mHomographyRight, mRBAreaR, 13 * W/4, H-W/10*2, mDiffRB, mRBGradientRU, mRBGradientRV);


        	cv::Mat mFRDiff =  CalculateDiffForHomography(mHomographyRight, mFRAreaR, 13 * W/4, 0, mDiffFR, mFRGradientRU, mFRGradientRV);

        	cv::Mat mFRDiff2 =  CalculateDiffForHomography(mHomographyFront, mFRAreaF, 13 * W/4, 0, mDiffFR, mFRGradientFU, mFRGradientFV);

        	double nLearningRate = 0.00000000005;
        	for (int i=0;i<nIteration;i++){
        		nLearningRate/=1.1;
        	}
        	

        	// mHomographyFront = UpdateHomography(mHomographyFront, nLearningRate, mLFDiff);
        	// mHomographyLeft = UpdateHomography(mHomographyLeft, nLearningRate, mLFDiff2);


        	// mHomographyLeft = UpdateHomography(mHomographyLeft, nLearningRate, mBLDiff);
        	mHomographyBack = UpdateHomography(mHomographyBack, nLearningRate * 100, mBLDiff2);


        	mHomographyBack = UpdateHomography(mHomographyBack, nLearningRate * 100, mRBDiff);
        	// mHomographyRight = UpdateHomography(mHomographyRight, nLearningRate, mRBDiff2);

        	// mHomographyRight = UpdateHomography(mHomographyRight, nLearningRate/1000, mFRDiff);
        	mHomographyFront = UpdateHomography(mHomographyFront, nLearningRate*2, mFRDiff2);
        	// mHomographyFront = UpdateHomography(mHomographyFront, nLearningRate, mFRDiff2);
// 
        	int nLoss = CalculateLoss(mFRAreaR, mFRAreaF);
        	cout << "Loss F R is " << nLoss << endl;
}


cv::Mat Blur(cv::Mat mMat){
	srand((unsigned)time(NULL)); 
	for(int i=0;i<3;i++){
		for (int j=0;j<3;j++){
			double ratio = rand() / double(RAND_MAX);
			if (i==2 && j==0){
				continue;
			}
			mMat.at<double>(i , j) = mMat.at<double>(i , j) * (1+((ratio - 0.5)/30));
		}
	}
	return mMat;
}



int main(){


	// mHomographyFront.at<double>(0 , 0) = mHomographyFront.at<double>(0 , 0) + 0.05;

	// mHomographyLeft.at<double>(0 , 1) = mHomographyLeft.at<double>(0 , 1) + 0.03;

	// mHomographyBack.at<double>(1 , 0) = mHomographyBack.at<double>(1 , 0) + 0.005;

	// mHomographyRight.at<double>(1 , 1) = mHomographyRight.at<double>(1 , 1) + 0.03;

	// mHomographyFront = Blur(mHomographyFront);
	// mHomographyLeft = Blur(mHomographyLeft);
	// mHomographyBack = Blur(mHomographyBack);
	// mHomographyRight = Blur(mHomographyRight);

	cout << "Now homography matrices are as below " << endl;
	cout << "Front: " << endl << mHomographyFront << endl;



	
	cout << "Left: " << endl << mHomographyLeft << endl;
	cout << "Back: " << endl << mHomographyBack << endl;
	cout << "Right: " << endl << mHomographyRight << endl;

	cv::Mat iFrontBirdsEyeFrame , iLeftBirdEyeFrame , iBackBirdEyeFrame , iRightBirdEyeFrame;


	for (int i=0;i<50;i++){
		Generate4BirdView(	iFrontBirdsEyeFrame,
							iLeftBirdEyeFrame,
							iBackBirdEyeFrame,
							iRightBirdEyeFrame);
		cv::Mat iBirdsEyeImage = GenerateOneBirdView(	iFrontBirdsEyeFrame,
														iLeftBirdEyeFrame,
														iBackBirdEyeFrame,
														iRightBirdEyeFrame);



		cv::imshow("const cv::String &winname", iBirdsEyeImage);
		stringstream ss;
		ss << "./result/" << i << ".jpg";
		string aFileName = ss.str();
		cout << "Save to " << aFileName << endl;
		cout << "Now homography front is " << endl << mHomographyFront << endl;
		cv::imwrite(aFileName, iBirdsEyeImage);
		cv::waitKey(0);
		
		Adjust(		iFrontBirdsEyeFrame, iLeftBirdEyeFrame,
				 	iBackBirdEyeFrame, iRightBirdEyeFrame , i);
	
	}
	
	return 0;
}