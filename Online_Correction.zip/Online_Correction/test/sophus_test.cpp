#include <iostream>
#include <cmath>
// #include <math.h>
using namespace std;

#include <Eigen/Core>
#include <Eigen/Geometry>

#include "sophus/se3.h"
#include "sophus/so3.h"

void genRt(Eigen::Matrix3d &R,Eigen::Vector3d &t)
{
	R = Eigen::AngleAxis<double>(M_PI/2, Eigen::Vector3d(0,1,0)).toRotationMatrix();
	t<<1,2,3;
	return;
}

int main(int argc, char** argv)
{
// 	Eigen::Matrix<double,2,3> matrix_23;
// 	matrix_23<<1,2,3,
// 	           4,5,6;
// 	cout<<matrix_23<<endl<<endl;
	
	Eigen::Matrix3d R = Eigen::Matrix3d();
	R<<-1.17297741e-02, -7.87126895e-01,  6.16679547e-01,
	    8.24472845e-01,  3.41339672e-01,  4.51366544e-01,
	   -5.65779941e-01,  5.13729968e-01,  6.44960913e-01;
// 	Eigen::Matrix3d R = Eigen::AngleAxis<double>(M_PI/2, Eigen::Vector3d(0,0,1)).toRotationMatrix();
	cout<< "R:"<<endl;
	cout<<R<<endl;
	cout<< "--------------------------------------------"<<endl;
	
	Eigen::Vector3d t;
	t<<3,2,1;
	cout<< "t:"<<endl;
	cout<<t<<endl;
	cout<< "--------------------------------------------"<<endl;
	
// 	genRt(R,t);
// 	cout<< "R:"<<endl;
// 	cout<<R<<endl;
// 	cout<< "t:"<<endl;
// 	cout<<t<<endl;
// 	cout<< "--------------------------------------------"<<endl;
	
	
	Sophus::SO3 SO3_R(R);
	Sophus::SO3 SO3_v(0,M_PI/2,0);
	Eigen::Quaterniond q(R);
	Sophus::SO3 SO3_q(q);
	cout<<"SO3 from matrix:     "<<SO3_R<<endl;
	cout<<"SO3 from vector:     "<<SO3_v<<endl;
	cout<<"SO3 from quaternion: "<<SO3_q<<endl;
	
	Eigen::Vector3d so3 = SO3_R.log();
	cout<<"SO3.log: "<<so3<<endl;
	cout<<"SO3.matrix: "<<endl;
	cout<<SO3_R.matrix()<<endl;
	cout<< "--------------------------------------------"<<endl;
	
	
	Sophus::SE3 SE3_Rt(R,t);
	cout<< "SE3_Rt:"<<endl;
	cout<< SE3_Rt<<endl;
	cout<<"SE3_Rt.matrix: "<<endl;
	cout<<SE3_Rt.matrix()<<endl;
	cout<< "--------------------------------------------"<<endl;
	cout<< "SE3_Rt.log():"<<endl;
	cout<< SE3_Rt.log()<<endl;
		cout<< "SE3_Rt.exp():"<<endl;
	cout<< Sophus::SE3::exp(SE3_Rt.log()).matrix()<<endl;
	cout<< "--------------------------------------------"<<endl;
	
	cout<< "--------------------------------------------"<<endl;
	
		// Initialize R and t
	Eigen::Matrix3d R_FG = Eigen::Matrix3d();
	R_FG<< 9.99277118e-01,  3.82390286e-04, -3.80143958e-02,
		  -2.30748265e-02, -7.88582447e-01, -6.14495953e-01,
	      -3.02124625e-02,  6.14928921e-01, -7.88003572e-01;
	Eigen::Vector3d t_FG;
	t_FG<< 6.75437418e-01,  2.50896883e+01, 3.17779305e+00;
	
	// Initailize SE3 T
	Sophus::SE3 T_FG(R_FG,t_FG);
	Eigen::Matrix4d T_FG_Mat = T_FG.matrix();
	
	// Check SE3 and se3
	cout<<"------------------Check SE3 and se3-------------------"<<endl;
	cout<<T_FG_Mat<<endl;
	cout<<T_FG.log()<<endl;
	
	// Check plus for se3
	cout<<"------------------Check plus for se3------------------"<<endl;
	Eigen::Matrix<double,6,1>  V6;
	V6<<0.1, 0.1, 0.1, 0.1, 0.1, 0.1;
	cout<<"origin T_FG"<<endl;
	cout<<T_FG<<endl;
	cout<<T_FG.log()<<endl;
	T_FG = Sophus::SE3::exp(T_FG.log()+V6);
	cout<<"after plus 0.1"<<endl;
	cout<<T_FG<<endl;
	cout<<T_FG.log()<<endl;
	
	// Check T multiply vector4d
	cout<<"-----------------Check T multiply vector4d------------"<<endl;
	Eigen::Vector4d p(4,3,2,1);
	cout<<T_FG_Mat*p<<endl;
	cout<<T_FG.matrix()*p<<endl;

	
	
	
	return 0;
}