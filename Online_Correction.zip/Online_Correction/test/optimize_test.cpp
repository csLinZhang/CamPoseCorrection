#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <opencv2/calib3d/calib3d.hpp>
#include <opencv2/imgproc/imgproc.hpp>

#include <opencv2/opencv.hpp>

#include <iostream>
#include <vector>

#include "config.h"
#include "photometric.h"

#include "point_selection.h"
#include "converter.h"

#include <cmath>
#include <time.h>
#include <initializer.h>
using namespace std;


cv::Mat mHomographyFront = (cv::Mat_<double>(3 , 3) << 	 -0.921313 ,	1.466052 ,	-168.998622	,
														 0.182551 ,	0.729686 ,	-514.731272	,
														 0.000224 ,	0.002246 ,	-1.070975	 );


cv::Mat mHomographyLeft = (cv::Mat_<double>(3 , 3) << 	 -1.251914 , -1.281507 , 1248.074434,	
														 -0.341446 , -0.291944 , 518.905259,	
														 -0.001976 , -0.000316 , 1.196932);


cv::Mat mHomographyBack = (cv::Mat_<double>(3 , 3) << 	 1.364389 , -1.604490 , 438.469726,	
														 -0.053790 , -0.655889 , 348.286934,	
														 0.000033 , -0.002588 , 1.809270);


cv::Mat mHomographyRight = (cv::Mat_<double>(3 , 3) << 	 1.177682 , 1.180053  , -1051.645728,	
														 0.302534 , -0.266407 ,	215.612475,	
														 0.002105 , -0.000010 ,	-0.963528);






void LoadIntrinsics(cv::Mat & mFrontK , cv::Mat & mFrontD , cv::Mat & mFrontP,
					cv::Mat & mLeftK , cv::Mat & mLeftD , cv::Mat & mLeftP,
					cv::Mat & mBackK , cv::Mat & mBackD , cv::Mat &mBackP,
					cv::Mat & mRightK , cv::Mat & mRightD , cv::Mat & mRightP){
		string aFileName = "./config/intrinsics(3).xml";
	    cv::FileStorage fs(aFileName, cv::FileStorage::READ);
        // cv::Mat mFrontK , mFrontD , mFrontP;
        // cv::Mat mLeftK , mLeftD , mLeftP;
        // cv::Mat mBackK , mBackD , mBackP;
        // cv::Mat mRightK , mRightD , mRightP;

        fs["f_intrinsic"] >> mFrontK;
        fs["f_distortion"] >> mFrontD;
        fs["f_P"] >> mFrontP;

        fs["l_intrinsic"] >> mLeftK;
        fs["l_distortion"] >> mLeftD;
        fs["l_P"] >> mLeftP;

        fs["b_intrinsic"] >> mBackK;
        fs["b_distortion"] >> mBackD;
        fs["b_P"] >> mBackP;

        fs["r_intrinsic"] >> mRightK;
        fs["r_distortion"] >> mRightD;
        fs["r_P"] >> mRightP;

}


vector<vector<cv::Point2f>> GenerateSingleMappingTable(cv::Mat mHomography , cv::Size iCameraImageSize, cv::Size iImageSize , cv::Mat mK , cv::Mat mD , cv::Mat mP){
        vector<vector<cv::Point2f>> gMappingTable;
        gMappingTable.reserve(iImageSize.height);
        for (int y=0;y<iImageSize.height;y++){
                //Generate the table of this line.
                vector<cv::Point2f> gSubMappingTable;
                gSubMappingTable.reserve(iImageSize.width);
                for (int x=0;x<iImageSize.width;x++){
                        cv::Mat mPoint = (cv::Mat_<double>(3 , 1) << x , y , 1);
                        mPoint = mHomography * mPoint;

                        mPoint = mK.inv() * mPoint;
                        cv::Point2f iPoint(mPoint.at<double>(0 , 0)/mPoint.at<double>(2 , 0) , mPoint.at<double>(1 , 0)/mPoint.at<double>(2 , 0));
                        if (mPoint.at<double>(2 , 0) == 0){
                                iPoint = cv::Point2f(0 , 0);
                        }
                        gSubMappingTable.push_back(iPoint);

                }
                cv::fisheye::distortPoints(gSubMappingTable, gSubMappingTable, mK, mD);
                for (auto & item : gSubMappingTable){
                        if (item.x <= 0.0){
                                item.x = 0.0;
                        }else if (item.x >= (float)(iCameraImageSize.width-1)){
                                item.x = (float)(iCameraImageSize.width-1);
                        }
                        if (item.y <=0.0){
                                item.y = 0.0;
                        }else if (item.y >= (float)(iCameraImageSize.height-1)){
                                item.y = (float)(iCameraImageSize.height-1);
                        }
                }
                gMappingTable.push_back(gSubMappingTable);
        }
        return gMappingTable;
}





void Generate4BirdView(		cv::Mat & iFrontBirdsEyeFrame , 
							cv::Mat & iLeftBirdsEyeFrame , 
							cv::Mat & iBackBirdsEyeFrame , 
							cv::Mat & iRightBirdsEyeFrame){

	cv::Mat mFrontK , mFrontD , mFrontP;
	cv::Mat mLeftK , mLeftD , mLeftP;
	cv::Mat mBackK , mBackD , mBackP;
	cv::Mat mRightK , mRightD , mRightP;

	LoadIntrinsics(		mFrontK, mFrontD, mFrontP,
					 	mLeftK, mLeftD, mLeftP,
					 	mBackK, mBackD, mBackP, 
					 	mRightK, mRightD, mRightP);


	vector<vector<cv::Point2f>> gFrontMappingTable , gLeftMappingTable , gBackMappingTable , gRightMappingTable;


	cout << "Generate Front Table" << endl;
	gFrontMappingTable = GenerateSingleMappingTable(mHomographyFront , iCameraImageSize, iBirdEyeSize , mFrontK , mFrontD , mFrontP);
	cout << "Generate Left Table" << endl;
	gLeftMappingTable = GenerateSingleMappingTable(mHomographyLeft , iCameraImageSize, iBirdEyeSize , mLeftK , mLeftD , mLeftP);
	cout << "Generate Back Table" << endl;
	gBackMappingTable = GenerateSingleMappingTable(mHomographyBack , iCameraImageSize, iBirdEyeSize , mBackK , mBackD , mBackP);
	cout << "Generate Right Table" << endl;
	gRightMappingTable = GenerateSingleMappingTable(mHomographyRight , iCameraImageSize, iBirdEyeSize , mRightK , mRightD , mRightP);


	

	int H = iBirdEyeSize.height;
	int W = iBirdEyeSize.width;
	//Init images;
	iFrontBirdsEyeFrame = cv::Mat::zeros(W,H,CV_8UC3);
	iLeftBirdsEyeFrame = cv::Mat::zeros(W,H,CV_8UC3);
	iBackBirdsEyeFrame = cv::Mat::zeros(W,H,CV_8UC3);
	iRightBirdsEyeFrame = cv::Mat::zeros(W,H,CV_8UC3);



	vector<cv::Mat> gImages;
	cv::Mat iFrontFrame , iLeftFrame , iBackFrame , iRightFrame;

	iFrontFrame = cv::imread("./img/front.jpg");
	iLeftFrame = cv::imread("./img/left.jpg");
	
	// cv::Mat iLeftFrameUndistortion;
	// cv::Size iUndistSize = cv::Size(iFrontFrame.size().width * 3 , iFrontFrame.size().height * 3);
	// cv::fisheye::undistortImage(iLeftFrame, iLeftFrameUndistortion, mLeftK, mLeftD, mLeftP , iUndistSize);
	// cv::imshow("const cv::String &winname", iLeftFrameUndistortion);
	// cv::waitKey(0);
	// cv::imwrite("undistort.jpg", iLeftFrameUndistortion);

	iBackFrame = cv::imread("./img/back.jpg");
	iRightFrame = cv::imread("./img/right.jpg");


	
	gImages.push_back(iFrontFrame);
	gImages.push_back(iLeftFrame);
	gImages.push_back(iBackFrame);
	gImages.push_back(iRightFrame);		



	for (int v=0;v<iBirdEyeSize.height;v++){
		for (int u=0;u<iBirdEyeSize.width;u++){
			cv::Point2f iMapping = gFrontMappingTable[v][u];
			iFrontBirdsEyeFrame.at<cv::Vec3b>(v , u) = gImages[0].at<cv::Vec3b>((int)iMapping.y , (int) iMapping.x);

			iMapping = gLeftMappingTable[v][u];
			iLeftBirdsEyeFrame.at<cv::Vec3b>(v , u) = gImages[1].at<cv::Vec3b>((int)iMapping.y , (int) iMapping.x);

			iMapping = gBackMappingTable[v][u];
			iBackBirdsEyeFrame.at<cv::Vec3b>(v , u) = gImages[2].at<cv::Vec3b>((int)iMapping.y , (int) iMapping.x);

			iMapping = gRightMappingTable[v][u];
			iRightBirdsEyeFrame.at<cv::Vec3b>(v , u) = gImages[3].at<cv::Vec3b>((int)iMapping.y , (int) iMapping.x);
		}
	}


	PhotometricAlignment(iFrontBirdsEyeFrame, iLeftBirdsEyeFrame, iBackBirdsEyeFrame, iRightBirdsEyeFrame, 1, -1, 1);


}



cv::Mat GenerateOneBirdView(	cv::Mat & iFrontBirdsEyeFrame ,
		 						cv::Mat & iLeftBirdsEyeFrame ,
		 						cv::Mat & iBackBirdsEyeFrame , 
		 						cv::Mat & iRightBirdsEyeFrame){


	int H = iBirdEyeSize.height;
	int W = iBirdEyeSize.width;
	//Init images;
	cv::Mat iBirdsEyeImage= cv::Mat::zeros(W,H,CV_8UC3);

	int maxV , minV , maxU , minU;
	int subMaxV , subMinV , subMaxU , subMinU;
	
	//Front Area
	maxV = (BIRDS_EYE_HEIGHT-CENTER_HEIGHT)/2;
	minV = 0;
	maxU = (BIRDS_EYE_WIDTH/4*3);
	minU = BIRDS_EYE_WIDTH/4;
	for (int v=0;v<= maxV;v++){
			for (int u= minU;u<= maxU;u++){
	            //Front area                   
	                //Front area                                   
					iBirdsEyeImage.at<cv::Vec3b>(v , u) = iFrontBirdsEyeFrame.at<cv::Vec3b>(v , u);
        }
    }


    //Left
	maxV = BIRDS_EYE_HEIGHT;
    maxU = BIRDS_EYE_WIDTH/2;

    subMaxV = (BIRDS_EYE_HEIGHT - CENTER_HEIGHT)/2;
    subMinV = (BIRDS_EYE_HEIGHT + CENTER_HEIGHT)/2;
    subMaxU = (BIRDS_EYE_WIDTH - CENTER_WIDTH)/2;
	
	for (int v=0;v< maxV;v++){
			for (int u=0;u<=subMaxU;u++){
		        if (u<((BIRDS_EYE_WIDTH)/4+v/2) && u <= ((BIRDS_EYE_WIDTH+2*BIRDS_EYE_HEIGHT)/4-v/2)){
		                //Left area.            	
						iBirdsEyeImage.at<cv::Vec3b>(v , u) = iLeftBirdsEyeFrame.at<cv::Vec3b>(v , u);
		    	}
		}
    }


    //Back
	minV = (BIRDS_EYE_HEIGHT + CENTER_HEIGHT)/2;
    maxV = BIRDS_EYE_HEIGHT;
    minU = BIRDS_EYE_WIDTH/4;
    maxU = (BIRDS_EYE_WIDTH/4*3);
	for (int v= minV;v< maxV;v++){
			for (int u= minU;u<= maxU;u++){
		        if (u < ((BIRDS_EYE_WIDTH)/4+v/2) && u > ((BIRDS_EYE_WIDTH+2*BIRDS_EYE_HEIGHT)/4-v/2)){
		                //Back area.    
						iBirdsEyeImage.at<cv::Vec3b>(v , u) = iBackBirdsEyeFrame.at<cv::Vec3b>(v , u);
		    	}
		    }
    }
	


    minU = BIRDS_EYE_WIDTH/2;
    subMinV = (BIRDS_EYE_WIDTH + CENTER_WIDTH)/2;
    subMaxV = (BIRDS_EYE_HEIGHT - CENTER_HEIGHT)/2;
    subMinU = (BIRDS_EYE_WIDTH + CENTER_WIDTH)/2;
	
	for (int v=0;v<BIRDS_EYE_HEIGHT;v++){
			for (int u= subMinU;u<BIRDS_EYE_WIDTH;u++){	   		
	        if (u>=((BIRDS_EYE_WIDTH)/4+v/2) && u > ((BIRDS_EYE_WIDTH+2*BIRDS_EYE_HEIGHT)/4-v/2)) {
	            	//Right area.
					iBirdsEyeImage.at<cv::Vec3b>(v , u) = iRightBirdsEyeFrame.at<cv::Vec3b>(v , u);	
	        }
        }
    }


    return iBirdsEyeImage;

}


void ShowMatrix(cv::Mat & mMat , string aWindowName = "show"){
	cv::Mat mCloneMat = mMat.clone();
	cv::Mat mNormalize , mColor;
	cv::normalize(mCloneMat,mNormalize,0,255,cv::NORM_MINMAX,CV_8U);
	cv::applyColorMap(mNormalize, mColor, cv::COLORMAP_JET);
	cv::imshow(aWindowName,mColor);
	cv::waitKey(0);	
}


cv::Mat Blur(cv::Mat mMat){
	srand((unsigned)time(NULL)); 
	
	for(int i=0;i<3;i++){
		for (int j=0;j<3;j++){
			
			// if (i==2 && j==0){
			// 	continue;
			// }
			double ratio = rand() / double(RAND_MAX);
			mMat.at<double>(i , j) = mMat.at<double>(i , j) * (1+((ratio - 0.5)/30));
		}
	}
	// mMat.at<double>(0 , 2) = mMat.at<double>(0 , 2)-5;
	// mMat.at<double>(1 , 2) = mMat.at<double>(1 , 2)-5;
	return mMat;
}

double CalculateLoss(vector<double> gDifference1 , vector<double> gDifference2){
	double nTotalLoss = 0.0;
	for (auto nDifference : gDifference1){
		nTotalLoss += nDifference * nDifference;
	}
	for (auto nDifference : gDifference2){
		nTotalLoss += nDifference * nDifference;
	}
	return nTotalLoss;
}

double CalculateLearningRate(double nTotalLoss,
							 cv::Mat mDiff1 , cv::Mat mDiff2){
	// double nTotalLoss = 0.0;
	// for (auto nDifference : gDifference1){
	// 	nTotalLoss += nDifference * nDifference;
	// }
	// for (auto nDifference : gDifference2){
	// 	nTotalLoss += nDifference * nDifference;
	// }
	// cout << "nTotalLoss is " << nTotalLoss << endl;
	double nAllDiff = 0.0;
	for (int i=0;i<6;i++){
		nAllDiff += abs(mDiff1.at<double>(0 , i));
		nAllDiff += abs(mDiff2.at<double>(0 , i));
	}
	double nLearningRate = nTotalLoss / nAllDiff;
	nLearningRate *= 0.000000005;
	cout << "Learning rate is " << nLearningRate << endl;
	return nLearningRate;
}


cv::Mat UpdateHomography(cv::Mat mOriginalUpdateHomography , double nLearningRate , cv::Mat & mDiff){
	// mUpdateHomography = mUpdateHomography;

	
	cv::Mat mUpdateHomography = mOriginalUpdateHomography.clone();
	// cout << "Old Homo is " << endl << mUpdateHomography << endl;
			

	double nOriginalDet = cv::determinant(mUpdateHomography);

	cv::Mat mOriginalHomography = mUpdateHomography/*.inv()*/;


	//First row
	mOriginalHomography.at<double>(0 , 0) = mOriginalHomography.at<double>(0 , 0) + mDiff.at<double>(0 , 0) * nLearningRate;
	mOriginalHomography.at<double>(0 , 1) = mOriginalHomography.at<double>(0 , 1) + mDiff.at<double>(0 , 1) * nLearningRate;
	mOriginalHomography.at<double>(0 , 2) = mOriginalHomography.at<double>(0 , 2) + mDiff.at<double>(0 , 2) * nLearningRate;
	//Second row
	mOriginalHomography.at<double>(1 , 0) = mOriginalHomography.at<double>(1 , 0) + mDiff.at<double>(0 , 3) * nLearningRate;
	mOriginalHomography.at<double>(1 , 1) = mOriginalHomography.at<double>(1 , 1) + mDiff.at<double>(0 , 4) * nLearningRate;
	mOriginalHomography.at<double>(1 , 2) = mOriginalHomography.at<double>(1 , 2) +  mDiff.at<double>(0 , 5) * nLearningRate;
	//Third row
	// mOriginalHomography.at<double>(2 , 0) = mOriginalHomography.at<double>(2 , 0) + mDiff.at<double>(0 , 6) * nLearningRate/200;
	// mOriginalHomography.at<double>(2 , 1) = mOriginalHomography.at<double>(2 , 1) + mDiff.at<double>(0 , 7) * nLearningRate/200;
	// mOriginalHomography.at<double>(2 , 2) = mOriginalHomography.at<double>(2 , 2) + mDiff.at<double>(0 , 8) * nLearningRate/200;


	mUpdateHomography = mOriginalHomography/*.inv()*/;

	mUpdateHomography = mUpdateHomography/(cv::determinant(mUpdateHomography)/nOriginalDet);

	// cout << "New Homo is " << endl << mUpdateHomography << endl;

	return mUpdateHomography;
}

vector<cv::Point2f> UpdatePointsPos(vector<cv::Point2f> gOldPoints , cv::Mat mOldHomography , cv::Mat mNewHomography){
	vector<cv::Point2f> gNewPoints;
	for (auto item : gOldPoints){
		cv::Mat mMatPoint = (cv::Mat_<double>(3 , 1)<< item.x , item.y , 1);
		cv::Mat mUndistortPoint1 = mNewHomography * mOldHomography.inv() * mMatPoint;
		
		//Normalize.
		cv::Point2f iUndistortPoint1(	mUndistortPoint1.at<double>(0 , 0) , 
										mUndistortPoint1.at<double>(1 , 0));

		//Check if z ==0 
		if (mUndistortPoint1.at<double>(2 , 0) == 0){
			mUndistortPoint1.at<double>(0 , 0) = 0;
			mUndistortPoint1.at<double>(1 , 0) = 0;
			continue;
		}
		//Normalize.
		iUndistortPoint1.x /= mUndistortPoint1.at<double>(2 , 0);
		iUndistortPoint1.y /= mUndistortPoint1.at<double>(2 , 0);
		gNewPoints.push_back(iUndistortPoint1);
	}
	return gNewPoints;
}


int main(){
	mHomographyFront = Blur(mHomographyFront);
	for (int nIteration=0;nIteration<50;nIteration++){
		cv::Mat mFrontBirdsEyeFrame , mLeftBirdsEyeFrame , mBackBirdsEyeFrame , mRightBirdsEyeFrame;

		
		Generate4BirdView(	mFrontBirdsEyeFrame,
							mLeftBirdsEyeFrame,
							mBackBirdsEyeFrame,
							mRightBirdsEyeFrame);
		cv::Mat mBirdsEyeImage = GenerateOneBirdView(	mFrontBirdsEyeFrame,
														mLeftBirdsEyeFrame,
														mBackBirdsEyeFrame,
														mRightBirdsEyeFrame);

		cv::imshow("const cv::String &winname", mBirdsEyeImage);
		stringstream ss;
		ss << nIteration;
		string aFileName = "";
		ss >> aFileName;
		aFileName += "birdseye_image.jpg";
		aFileName = "./img/" + aFileName;
		cv::imwrite(aFileName , mBirdsEyeImage);
		cv::waitKey(0);

		cv::Mat mFrontK , mFrontD , mFrontP;
		cv::Mat mLeftK , mLeftD , mLeftP;
		cv::Mat mBackK , mBackD , mBackP;
		cv::Mat mRightK , mRightD , mRightP;

		LoadIntrinsics(		mFrontK, mFrontD, mFrontP,
						 	mLeftK, mLeftD, mLeftP,
						 	mBackK, mBackD, mBackP, 
				 			mRightK, mRightD, mRightP);



	    cv::Mat mLFAreaF , mLFAreaL , mBLAreaB , mBLAreaL , mRBAreaR , mRBAreaB , mFRAreaF , mFRAreaR;
	    int W = BIRDS_EYE_WIDTH;
	    int H = BIRDS_EYE_HEIGHT;




		mLFAreaF = mFrontBirdsEyeFrame(cv::Rect( W/4, 0, W/8 , W/8*2));
		mLFAreaL = mLeftBirdsEyeFrame(cv::Rect( W/4, 0,W/8 , W/8*2));
		mBLAreaL = mLeftBirdsEyeFrame(cv::Rect( W/4, H- W/10*2 , W/10 , W/10*2));
		mBLAreaB = mBackBirdsEyeFrame(cv::Rect( W/4, H- W/10*2, W/10 , W/10*2));
		mRBAreaB = mBackBirdsEyeFrame(cv::Rect( 13*W/20, H- W/10*2,W/10 , W/10*2));
		mRBAreaR = mRightBirdsEyeFrame(cv::Rect( 13*W/20, H- W/10*2,W/10 , W/10*2));
		mFRAreaR = mRightBirdsEyeFrame(cv::Rect( 13*W/20, 0,W/8, W/8*2));
		mFRAreaF = mFrontBirdsEyeFrame(cv::Rect( 13*W/20, 0,W/8, W/8*2));


		cv::Mat mLFAreaLGray = ConvertColorToGray(mLFAreaL);
		cv::Mat mLFAreaFGray = ConvertColorToGray(mLFAreaF);

		cv::Mat mFRAreaFGray = ConvertColorToGray(mFRAreaF);
		cv::Mat mFRAreaRGray = ConvertColorToGray(mFRAreaR);

		//Original image.
		cv::Mat iFrontFrame , iLeftFrame , iBackFrame , iRightFrame;

		iFrontFrame = cv::imread("./img/front.jpg");
		iFrontFrame = ConvertColorToGray(iFrontFrame);
		iLeftFrame = cv::imread("./img/left.jpg");
		iLeftFrame = ConvertColorToGray(iLeftFrame);
		iBackFrame = cv::imread("./img/back.jpg");
		iBackFrame = ConvertColorToGray(iBackFrame);
		iRightFrame = cv::imread("./img/right.jpg");
		iRightFrame = ConvertColorToGray(iRightFrame);



		vector<cv::Point2f> gPointsFront1 , gPointsLeft2;
		vector<cv::Point2f> gPointsFront2 , gPointsRight1;
		time_t tBegin , tEnd;

		tBegin = clock();
		SelectPoint(mLFAreaFGray , mLFAreaLGray,
					mHomographyFront , mHomographyLeft,
					iFrontFrame , iLeftFrame,
					mFrontK , mFrontD , mLeftK , mLeftD ,
					W/4 , 0,
					gPointsFront1 , gPointsLeft2
					);


		// cout << "Point size " << gPointsFront1.size() << endl;
		// for (auto item : gPointsFront1){
		// 	item.x = item.x - W/4;
		// 	cout << item << endl;
		// 	cv::circle(mLFAreaL, item, 10, cv::Scalar(100 , 100 , 0));			
		// }

		// cv::imshow("const cv::String &winname", mLFAreaL);
		// cv::waitKey(0);

		SelectPoint(mFRAreaRGray , mFRAreaFGray,
					mHomographyRight , mHomographyFront,
					iRightFrame , iFrontFrame,
					mRightK , mRightD , mFrontK , mFrontD,
					13*W/20, 0,
					gPointsRight1 , gPointsFront2
					);


		vector<double> gDifferenceFL = CompareSparseDifference(iFrontFrame, iLeftFrame,
											gPointsFront1, gPointsLeft2,
											mFrontK , mFrontD , mLeftK , mLeftD,
											mHomographyFront , mHomographyLeft);

		vector<double> gDifferenceLF = CompareSparseDifference(iLeftFrame,iFrontFrame,
											gPointsLeft2, gPointsFront1,
											mLeftK , mLeftD, mFrontK , mFrontD ,
											mHomographyLeft , mHomographyFront);


		vector<double> gDifferenceRF = CompareSparseDifference(iRightFrame , iFrontFrame,
											gPointsRight1 , gPointsFront2,
											mRightK , mRightD , mFrontK , mFrontD,
											mHomographyRight , mHomographyFront);


		vector<double> gDifferenceFR = CompareSparseDifference(iFrontFrame, iRightFrame,
											gPointsFront2, gPointsRight1,
											mFrontK , mFrontD, mRightK , mRightD,
											mHomographyFront , mHomographyRight);

		vector<double> gFrontGradientU1 , gFrontGradientV1;
		vector<double> gLeftGradientU2 , gLeftGradientV2;

		vector<double> gFrontGradientU2 , gFrontGradientV2;
		vector<double> gRightGradientU1 , gRightGradientV1;

		CalculateSparseGradient(iFrontFrame ,
							 	gFrontGradientU1 , gFrontGradientV1 ,
							 	mFrontK , mFrontD , gPointsFront1);

		CalculateSparseGradient(iLeftFrame , 
							 	gLeftGradientU2 , gLeftGradientV2 ,
							 	mLeftK , mLeftD , gPointsLeft2);

		CalculateSparseGradient(iRightFrame , 
								gRightGradientU1 , gRightGradientV1 ,
								mRightK , mRightD , gPointsRight1);

		CalculateSparseGradient(iFrontFrame ,
								gFrontGradientU2 , gFrontGradientV2 ,
								mFrontK , mFrontD , gPointsFront2);


		cv::Mat mDiffFront1 = CalculateSparseDiffForHomography(	mHomographyFront ,gDifferenceLF ,
																gPointsFront1,
																gFrontGradientU1 , gFrontGradientU1);

		cv::Mat mDiffFront2 = CalculateSparseDiffForHomography(	mHomographyFront ,gDifferenceFR ,
																gPointsFront2,
																gFrontGradientU2 , gFrontGradientU2);

	    // double nLearningRate = 0.0000001;
		
		double nTotalLoss = CalculateLoss(gDifferenceLF, gDifferenceFR);
		double nLearningRate = CalculateLearningRate(nTotalLoss, mDiffFront1 , mDiffFront2);
		cout << "Points size " << gPointsFront1.size() << endl;
		cout << "Difference size " << gDifferenceFL.size() << endl;
		double nNewTotalLoss = nTotalLoss;

		// for (int i=0;i<nIteration;i++){
		// 	nLearningRate/=1.1;
		// }

		cv::Mat mNewHomographyFront = mHomographyFront;
		do{
			cout << "LearningRate is " << nLearningRate << endl;
			
			mNewHomographyFront = UpdateHomography(mHomographyFront, -nLearningRate, mDiffFront1);
			
			mNewHomographyFront = UpdateHomography(mNewHomographyFront, -nLearningRate, mDiffFront2);
		
			cout << "Old Homo is " << endl << mHomographyFront << endl;

			cout << "New Homo is " << endl << mNewHomographyFront << endl;

			cout << "Divide!!!!!!!!!!!!!!!" << endl;
			// nLearningRate /=1.1;

			vector<cv::Point2f> gNewPointsFront1 , gNewPointsFront2;




			gNewPointsFront1 = UpdatePointsPos(gPointsFront1, mHomographyFront, mNewHomographyFront);
			gNewPointsFront2 = UpdatePointsPos(gPointsFront2, mHomographyFront, mNewHomographyFront);


			vector<double> gNewDifferenceFR = CompareSparseDifference(iFrontFrame, iRightFrame,
												gNewPointsFront2, gPointsRight1,
												mFrontK , mFrontD, mRightK , mRightD,
												mNewHomographyFront , mHomographyRight);

			for (int ii=0;ii<gNewPointsFront2.size();ii++){
				if (gNewPointsFront2[ii].x!=gPointsFront2[ii].x){
					cout << "Different!!!" << endl;
					break;
				}
			}


			vector<double> gNewDifferenceLF = CompareSparseDifference(iLeftFrame,iFrontFrame,
												gPointsLeft2, gNewPointsFront1,
												mLeftK , mLeftD, mFrontK , mFrontD ,
												mHomographyLeft , mNewHomographyFront);

			nNewTotalLoss = CalculateLoss(gNewDifferenceLF, gNewDifferenceFR);
		}while(nTotalLoss < nNewTotalLoss * 0.95);
		cout << "nTotalLoss is " << nTotalLoss << endl;
		cout << "nNewTotalLoss is " << nNewTotalLoss << endl;

		mHomographyFront = mNewHomographyFront;

		tEnd = clock();
		cout << "Duration " << (double)(tEnd - tBegin) / CLOCKS_PER_SEC << endl;
	}

	cout << iClass.m_nData << endl;
	return 0;
}