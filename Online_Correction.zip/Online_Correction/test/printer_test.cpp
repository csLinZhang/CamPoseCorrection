#include <iostream>
#include <opencv2/core/core.hpp>
#include <Eigen/Core>
#include <g2o/core/base_binary_edge.h>
#include "printer.h"
#include "sophus/so3.h"

using namespace std; 

int main(int argc, char** argv)
{
	
	int sum = 0;
	for(int i=0;i<100;i++)
	{
		sum += i;
		printSum(sum);
	}
// test2
	return 0;
}