#include "../include/recover.h"


using namespace std;



cv::Mat mHomographyFront = (cv::Mat_<double>(3 , 3) << 	 -0.921313 ,	1.466052 ,	-168.998622	,
														 0.182551 ,	0.729686 ,	-514.731272	,
														 0.000224 ,	0.002246 ,	-1.070975	 );


cv::Mat mHomographyLeft = (cv::Mat_<double>(3 , 3) << 	 -1.251914 , -1.281507 , 1248.074434,	
														 -0.341446 , -0.291944 , 518.905259,	
														 -0.001976 , -0.000316 , 1.196932);


cv::Mat mHomographyBack = (cv::Mat_<double>(3 , 3) << 	 1.364389 , -1.604490 , 438.469726,	
														 -0.053790 , -0.655889 , 348.286934,	
														 0.000033 , -0.002588 , 1.809270);


cv::Mat mHomographyRight = (cv::Mat_<double>(3 , 3) << 	 1.177682 , 1.180053  , -1051.645728,	
														 0.302534 , -0.266407 ,	215.612475,	
														 0.002105 , -0.000010 ,	-0.963528);



void LoadIntrinsics(cv::Mat & mFrontK , cv::Mat & mFrontD , cv::Mat & mFrontP,
					cv::Mat & mLeftK , cv::Mat & mLeftD , cv::Mat & mLeftP,
					cv::Mat & mBackK , cv::Mat & mBackD , cv::Mat &mBackP,
					cv::Mat & mRightK , cv::Mat & mRightD , cv::Mat & mRightP){
		string aFileName = "../config/intrinsics(3).xml";
	    cv::FileStorage fs(aFileName, cv::FileStorage::READ);
        // cv::Mat mFrontK , mFrontD , mFrontP;
        // cv::Mat mLeftK , mLeftD , mLeftP;
        // cv::Mat mBackK , mBackD , mBackP;
        // cv::Mat mRightK , mRightD , mRightP;
        fs["f_intrinsic"] >> mFrontK;
        fs["f_distortion"] >> mFrontD;
        fs["f_P"] >> mFrontP;

	    cout << "Front intrinsics" << endl;
        cout << "mFrontK is  " << endl << mFrontK << endl;
        cout << "mFrontD is  " << endl << mFrontD << endl;

        //Left
        fs["l_intrinsic"] >> mLeftK;
        fs["l_distortion"] >> mLeftD;
        fs["l_P"] >> mLeftP;

        cout << "Left intrinsics" << endl;
        cout << "mLeftK is  " << endl << mLeftK << endl;
        cout << "mLeftD is  " << endl << mLeftD << endl;

        //Back
        fs["b_intrinsic"] >> mBackK;
        fs["b_distortion"] >> mBackD;
        fs["b_P"] >> mBackP;

        cout << "Back intrinsics" << endl;
        cout << "mBackK is  " << endl << mBackK << endl;
        cout << "mBackD is  " << endl << mBackD << endl;

        //Right
        fs["r_intrinsic"] >> mRightK;
        fs["r_distortion"] >> mRightD;
        fs["r_P"] >> mRightP;

        cout << "Right intrinsics" << endl;
        cout << "mRightK is  " << endl << mRightK << endl;
        cout << "mRightD is  " << endl << mRightD << endl;

}


void ConvertPoseToHomography(cv::Mat mRVec , cv::Mat mtVec , cv::Mat mK_G , cv::Mat mK_C){

	// cv::Mat mRVec = (cv::Mat_<double>(3 , 1) << 	2.023297409978371,
	// 											 	-0.003124963976634152,
	// 											 	-0.1283492017014912);

	// cv::Mat mtVec = (cv::Mat_<double>(3 , 1) <<  -0.003749144640556696,
	// 											 1.376113393712053,
	// 											 -0.6931823004198616);

	cv::Mat mR;
	cv::Rodrigues(mRVec, mR); 	

	cout << "R is " << endl << mR << endl;

	cv::Mat mT;
	cv::hconcat(mR, mtVec , mT);
	cout << "T is " << endl << mT << endl;


	cv::Mat mK_G_Augmentation = mK_G.colRange(0 , 2);
	cv::Mat mK_G_inv = mK_G.inv();
	cv::Mat mK_G_inv_Augmentation = mK_G_inv.rowRange(0 , 2);


	cv::hconcat(mK_G_Augmentation , cv::Mat::zeros(3, 1, CV_64FC1) , mK_G_Augmentation);
	cv::hconcat(mK_G_Augmentation , mK_G.col(2) , mK_G_Augmentation);


	cv::vconcat(mK_G_inv_Augmentation , cv::Mat::zeros(1, 3, CV_64FC1) , mK_G_inv_Augmentation);
	cv::vconcat(mK_G_inv_Augmentation , mK_G_inv.row(2) , mK_G_inv_Augmentation);

	cout << "Multiply!" << endl;
	cout << "Last result " << endl << mK_C * mT * mK_G_inv_Augmentation << endl;

}


int main(){
	
	cv::Mat mFrontK , mFrontD , mFrontP;
	cv::Mat mLeftK , mLeftD , mLeftP;
	cv::Mat mBackK , mBackD , mBackP;
	cv::Mat mRightK , mRightD , mRightP;

	LoadIntrinsics(		mFrontK, mFrontD, mFrontP,
					 	mLeftK, mLeftD, mLeftP,
					 	mBackK, mBackD, mBackP, 
					 	mRightK, mRightD, mRightP);

	int W = 1000, H = 1000;
	double dX_G = 100 , dY_G = 100;

	cv::Mat mK_G = (cv::Mat_<double>(3 , 3) << dX_G , 0.0 , W/2,
												0.0   , -dY_G , H/2,
												0.0   , 0.0 , 1.0);

	// RecoverPose(mHomographyFront, mFrontK, mK_G);


	vector<cv::Mat> gFrontPointsBirdsEye = {
		(cv::Mat_<double>(3 , 1) << 0 	 , 0   , 1),
		(cv::Mat_<double>(3 , 1) << 100  , 100 , 1),
		(cv::Mat_<double>(3 , 1) << 1000 , 0   , 1),
		(cv::Mat_<double>(3 , 1) << 700  , 100 , 1),
		(cv::Mat_<double>(3 , 1) << 500  , 200 , 1),
	};

	cout << "Recover Front Pose!" << endl;
	cv::Mat mRVec , mtVec;
	RecoverPoseByPnP(mHomographyFront, mFrontK, mK_G , gFrontPointsBirdsEye , mRVec , mtVec);
	ConvertPoseToHomography(mRVec, mtVec, mK_G, mFrontK);


	vector<cv::Mat> gLeftPointsBirdsEye = {
		(cv::Mat_<double>(3 , 1) << 0 	 , 0      , 1),
		(cv::Mat_<double>(3 , 1) << 100  , 100 	  , 1),
		(cv::Mat_<double>(3 , 1) << 0 	 , 1000   , 1),
		(cv::Mat_<double>(3 , 1) << 200  , 700    , 1),
		(cv::Mat_<double>(3 , 1) << 200  , 500 , 1),
	};

	cout << "Recover Left Pose!" << endl;
	RecoverPoseByPnP(mHomographyLeft, mLeftK, mK_G , gLeftPointsBirdsEye , mRVec , mtVec);
	ConvertPoseToHomography(mRVec, mtVec, mK_G, mLeftK);



	vector<cv::Mat> gBackPointsBirdsEye = {
		(cv::Mat_<double>(3 , 1) << 0 	 , 1000   , 1),
		(cv::Mat_<double>(3 , 1) << 100  , 900 , 1),
		(cv::Mat_<double>(3 , 1) << 1000 , 1000   , 1),
		(cv::Mat_<double>(3 , 1) << 700  , 700 , 1),
		(cv::Mat_<double>(3 , 1) << 500  , 800 , 1),
	};


	cout << "Recover Back Pose!" << endl;
	RecoverPoseByPnP(mHomographyBack, mBackK, mK_G , gBackPointsBirdsEye , mRVec , mtVec);
	ConvertPoseToHomography(mRVec, mtVec, mK_G, mBackK);




	vector<cv::Mat> gRightPointsBirdsEye = {
		(cv::Mat_<double>(3 , 1) << 1000 	 , 0   , 1),
		(cv::Mat_<double>(3 , 1) << 900  , 100 , 1),
		(cv::Mat_<double>(3 , 1) << 1000 , 1000   , 1),
		(cv::Mat_<double>(3 , 1) << 700  , 800 , 1),
		(cv::Mat_<double>(3 , 1) << 900  , 500 , 1),
	};


	cout << "Recover Right Pose!" << endl;
	RecoverPoseByPnP(mHomographyRight, mRightK, mK_G , gRightPointsBirdsEye , mRVec , mtVec);
	ConvertPoseToHomography(mRVec, mtVec, mK_G, mRightK);

	return 0;
}