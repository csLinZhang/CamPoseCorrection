#ifndef PHOTOMETRIC_H_
#define PHOTOMETRIC_H_

#include "config.h"

//Standard
#include <iostream>
#include <string>
#include <vector>

//OpenCV
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <opencv2/calib3d/calib3d.hpp>
#include <opencv2/imgproc/imgproc.hpp>

//Eigen
#include <Eigen/Core>
#include <Eigen/Dense>
#include <Eigen/Geometry>

//DownSample the image to reduce the affect of noise.
void DownSample(cv::Mat & iImage , cv::Mat & iResult, double scale){
        int W = iImage.cols;
        int H = iImage.rows;
        int WResult = W/scale + 1;
        int HResult = H/scale + 1;
        cv::Size iDownSampleSize((int)(W/scale) , (int)(H/scale));
        cv::resize(iImage, iResult, iDownSampleSize);
}


//rho is the number of legal pair.
void Compare(cv::Mat & iImage1 , cv::Mat & iImage2 , int & rho , cv::Mat & iMask , double dThresScale){
	//The size of the image.
	int W , H;
	W = iImage1.cols;
	H = iImage1.rows;
	iMask = (cv::Mat_<int>(H , W));
	rho = 0;

	double totalError = 0.0;
	for (int u=0;u<W;u++){
		for (int v=0;v<H;v++){
			cv::Vec3b iPt1 = iImage1.at<cv::Vec3b>(v , u);
			cv::Vec3b iPt2 = iImage2.at<cv::Vec3b>(v , u);
			double dErr = 	(iPt1[0]-iPt2[0]) * (iPt1[0]-iPt2[0]) + 
							(iPt1[1]-iPt2[1]) * (iPt1[1]-iPt2[1]) + 
							(iPt1[2]-iPt2[2]) * (iPt1[2]-iPt2[2]);
			dErr/=3;
			totalError += dErr;
		}
	}
	double Threshold = 0.0;
	//The average error.
	if (dThresScale == -1){
		Threshold = totalError;
	}else{
		totalError /=(W*H);
		Threshold = totalError/dThresScale;	
	}
	
	for (int u=0;u<W;u++){
		for (int v=0;v<H;v++){
			cv::Vec3b iPt1 = iImage1.at<cv::Vec3b>(v , u);
			cv::Vec3b iPt2 = iImage2.at<cv::Vec3b>(v , u);
			double dErr = 	(iPt1[0]-iPt2[0]) * (iPt1[0]-iPt2[0]) + 
							(iPt1[1]-iPt2[1]) * (iPt1[1]-iPt2[1]) + 
							(iPt1[2]-iPt2[2]) * (iPt1[2]-iPt2[2]);
			dErr/=3;
			if (dErr < Threshold){
				rho++;
				iMask.at<int>(v , u) = 1;
			}else{
				iMask.at<int>(v , u) = 0;
			}
		}
	}
	//Show the image.

	cv::Mat iCopyImage1 = iImage1.clone();
	cv::Mat iCopyImage2 = iImage2.clone();

	for (int u=0;u<W;u++){
		for (int v=0;v<H;v++){
			if (iMask.at<int>(v , u) == 0){
				iCopyImage1.at<cv::Vec3b>(v , u) = cv::Vec3b(0 , 0 , 0);
				iCopyImage2.at<cv::Vec3b>(v , u) = cv::Vec3b(0 , 0 , 0);
			}

		}
	}
}


double clamp(double x)
{
    if (x > 255.0)
        return 255.0;
    if (x < 0.0)
        return 0.0;
	
    return x;
}





void PhotometricAlignment(cv::Mat & iImageFront , cv::Mat & iImageLeft , cv::Mat & iImageBack , cv::Mat & iImageRight,
						double dSampleScale , double dThresScale , int SolveType){

	cv::Mat iImageFrontYCRCB , iImageLeftYCRCB , iImageBackYCRCB , iImageRightYCRCB;
	iImageFrontYCRCB = iImageFront.clone();
	iImageLeftYCRCB = iImageLeft.clone();
	iImageBackYCRCB = iImageBack.clone();
	iImageRightYCRCB = iImageRight.clone();

	//Initialize the iterators.
	cv::MatIterator_<cv::Vec3b> pIterFront , pIterLeft , pIterBack , pIterRight;
	pIterFront = iImageFrontYCRCB.begin<cv::Vec3b>();
	pIterLeft = iImageLeftYCRCB.begin<cv::Vec3b>();
	pIterBack = iImageBackYCRCB.begin<cv::Vec3b>();
	pIterRight = iImageRightYCRCB.begin<cv::Vec3b>();


	int H = BIRDS_EYE_HEIGHT , W = BIRDS_EYE_WIDTH;

	double value;

	int maxV = (BIRDS_EYE_HEIGHT - CENTER_HEIGHT)/2;
	int minV = 0;
	int maxU = (BIRDS_EYE_WIDTH)/4*3;
	int minU = (BIRDS_EYE_WIDTH)/4;
	for (int v=0;v<H;v++){
		for (int u=0;u<W;u++){
                    //Front area                                   
                    cv::Vec3b iOriginPt = iImageFront.at<cv::Vec3b>(v , u);
	                //Front area       
	                value = ((0.299 * iOriginPt[2]) + (0.587 * iOriginPt[1]) + (0.114 * iOriginPt[0]));
	                if (value > 255.0){
	                	value = 255;
	                } else if (value < 0){
	                	value = 0;
	                }         
					iImageFrontYCRCB.at<cv::Vec3b>(v , u)[0] = value;
					value = 128 - (0.168736 * iOriginPt[2]) - (0.331264 * iOriginPt[1]) + (0.5 * iOriginPt[0]);
					if (value > 255.0){
	                	value = 255;
	                } else if (value < 0){
	                	value = 0;
	                }         
					iImageFrontYCRCB.at<cv::Vec3b>(v , u)[1] = value;
					value = 128 + (0.5 * iOriginPt[2]) - (0.418688 * iOriginPt[1]) - (0.081312 * iOriginPt[0]);
					if (value > 255.0){
	                	value = 255;
	                } else if (value < 0){
	                	value = 0;
	                }         
					iImageFrontYCRCB.at<cv::Vec3b>(v , u)[2] = value;	
				}
    }


    int subMaxV = (BIRDS_EYE_HEIGHT - CENTER_HEIGHT)/2;
    int subMaxU = (BIRDS_EYE_WIDTH - CENTER_WIDTH)/2;
    int subMinV = (BIRDS_EYE_HEIGHT + CENTER_HEIGHT)/2;
	for (int v=0;v<H;v++){
			for (int u=0;u<W;u++){		
                //Left area.
                cv::Vec3b iOriginPt = iImageLeft.at<cv::Vec3b>(v , u);
				value = ((0.299 * iOriginPt[2]) + (0.587 * iOriginPt[1]) + (0.114 * iOriginPt[0]));
				if (value > 255.0){
                	value = 255;
                } else if (value < 0){
                	value = 0;
                }		                
				iImageLeftYCRCB.at<cv::Vec3b>(v , u)[0] = value;
				value = 128 - (0.168736 * iOriginPt[2]) - (0.331264 * iOriginPt[1]) + (0.5 * iOriginPt[0]);
				if (value > 255.0){
                	value = 255;
                } else if (value < 0){
                	value = 0;
                }		                
				iImageLeftYCRCB.at<cv::Vec3b>(v , u)[1] = value;
				value = 128 + (0.5 * iOriginPt[2]) - (0.418688 * iOriginPt[1]) - (0.081312 * iOriginPt[0]);
				if (value > 255.0){
                	value = 255;
                } else if (value < 0){
                	value = 0;
                }
				iImageLeftYCRCB.at<cv::Vec3b>(v , u)[2] = value;
        	}
    }

	    minV = (H + CENTER_HEIGHT)/2;
	    minU = W/4;
	    maxU = W/4*3;
		for (int v=0;v<H;v++){
				for (int u=0;u<W;u++){					
	                    //Back area.    
	                    cv::Vec3b iOriginPt = iImageBack.at<cv::Vec3b>(v , u);
	                    value = ((0.299 * iOriginPt[2]) + (0.587 * iOriginPt[1]) + (0.114 * iOriginPt[0]));
						if (value > 255.0){
		                	value = 255;
		                } else if (value < 0){
		                	value = 0;
		                }
						iImageBackYCRCB.at<cv::Vec3b>(v , u)[0] = value;
						value = 128 - (0.168736 * iOriginPt[2]) - (0.331264 * iOriginPt[1]) + (0.5 * iOriginPt[0]);
						if (value > 255.0){
		                	value = 255;
		                } else if (value < 0){
		                	value = 0;
		                }
						iImageBackYCRCB.at<cv::Vec3b>(v , u)[1] = value;
						value = 128 + (0.5 * iOriginPt[2]) - (0.418688 * iOriginPt[1]) - (0.081312 * iOriginPt[0]);
						if (value > 255.0){
		                	value = 255;
		                } else if (value < 0){
		                	value = 0;
		                }
						iImageBackYCRCB.at<cv::Vec3b>(v , u)[2] = value;	
            		}
	    }


	    subMaxV = (BIRDS_EYE_HEIGHT - CENTER_HEIGHT)/2;
	    subMinV = (BIRDS_EYE_HEIGHT + CENTER_HEIGHT)/2;
	    int subMinU = (BIRDS_EYE_WIDTH + CENTER_WIDTH)/2;

		for (int v=0;v<H;v++){
			for (int u=0;u<W;u++){		   		
            		//Right area.
            		cv::Vec3b iOriginPt = iImageRight.at<cv::Vec3b>(v , u);
            		value = ((0.299 * iOriginPt[2]) + (0.587 * iOriginPt[1]) + (0.114 * iOriginPt[0]));
					if (value > 255.0){
	                	value = 255;
	                } else if (value < 0){
	                	value = 0;
	                }
					iImageRightYCRCB.at<cv::Vec3b>(v , u)[0] = value;
					value = 128 - (0.168736 * iOriginPt[2]) - (0.331264 * iOriginPt[1]) + (0.5 * iOriginPt[0]);
					if (value > 255.0){
	                	value = 255;
	                } else if (value < 0){
	                	value = 0;
	                }
					iImageRightYCRCB.at<cv::Vec3b>(v , u)[1] = value;
					value = 128 + (0.5 * iOriginPt[2]) - (0.418688 * iOriginPt[1]) - (0.081312 * iOriginPt[0]);
					if (value > 255.0){
	                	value = 255;
	                } else if (value < 0){
	                	value = 0;
	                }
					iImageRightYCRCB.at<cv::Vec3b>(v , u)[2] = value;	
            	}
	    }

	//Get overlapping areas.
	cv::Mat iLFAreaF , iLFAreaL , iBLAreaB , iBLAreaL , iRBAreaR , iRBAreaB , iFRAreaF , iFRAreaR;

	cv::Mat iLFMask , iBLMask, iRBMask , iFRMask;
	int rhoLF , rhoBL , rhoRB , rhoFR;

	iLFAreaF = iImageFrontYCRCB(cv::Rect( W/4, 0, W/10 , W/10*2));
	iLFAreaL = iImageLeftYCRCB(cv::Rect( W/4, 0,W/10 , W/10*2));
	iBLAreaL = iImageLeftYCRCB(cv::Rect( W/4, H- W/10*2 , W/10 , W/10*2));
	iBLAreaB = iImageBackYCRCB(cv::Rect( W/4, H- W/10*2, W/10 , W/10*2));
	iRBAreaB = iImageBackYCRCB(cv::Rect( 13*W/20, H- W/10*2,W/10 , W/10*2));
	iRBAreaR = iImageRightYCRCB(cv::Rect( 13*W/20, H- W/10*2,W/10 , W/10*2));
	iFRAreaR = iImageRightYCRCB(cv::Rect( 13*W/20, 0,W/10, W/10*2));
	iFRAreaF = iImageFrontYCRCB(cv::Rect( 13*W/20, 0,W/10, W/10*2));


	// vector<cv::Mat> 	gLFChannels_L , gLFChannels_F , gBLChannels_B , gBLChannels_L ,
	// 				 	gRBChannels_R , gRBChannels_B , gFRChannels_F , gFRChannels_R;

	// cv::split(iLFAreaL, gLFChannels_L);
	// cv::split(iLFAreaF, gLFChannels_F);
	// cv::split(iBLAreaB, gBLChannels_B);
	// cv::split(iBLAreaL, gBLChannels_L);
	// cv::split(iRBAreaR, gRBChannels_R);
	// cv::split(iRBAreaB, gRBChannels_B);
	// cv::split(iFRAreaF, gFRChannels_F);
	// cv::split(iFRAreaR, gFRChannels_R);


	// DownSample(iLFAreaF, iLFAreaF, dSampleScale);
	// DownSample(iLFAreaL, iLFAreaL, dSampleScale);
	// DownSample(iBLAreaL, iBLAreaL, dSampleScale);
	// DownSample(iBLAreaB, iBLAreaB, dSampleScale);
	// DownSample(iRBAreaB, iRBAreaB, dSampleScale);
	// DownSample(iRBAreaR, iRBAreaR, dSampleScale);
	// DownSample(iFRAreaR, iFRAreaR, dSampleScale);
	// DownSample(iFRAreaF, iFRAreaF, dSampleScale);

	H = iLFAreaF.rows;
	W = iLFAreaF.cols;

	// double dThreshold = 100;

	// Compare(iLFAreaF, iLFAreaL, rhoLF, iLFMask , dThresScale);
	// Compare(iBLAreaL, iBLAreaB, rhoBL, iBLMask , dThresScale);
	// Compare(iRBAreaB, iRBAreaR, rhoRB, iRBMask , dThresScale);
	// Compare(iFRAreaR, iFRAreaF, rhoFR, iFRMask , dThresScale);

	vector<double> iGFront , iGLeft , iGBack , iGRight;
	
	int NowH , NowW;
	NowH = iLFAreaL.rows;
	NowW = iLFAreaF.cols;
	int iTotalPixel = NowH * NowW;
	for (int iChannel = 0;iChannel<3;iChannel++){
		

		double 	dAverageLF_F = 0.0 , dAverageLF_L = 0.0,
			 	dAverageBL_L = 0.0 , dAverageBL_B = 0.0,
			  	dAverageRB_B = 0.0 , dAverageRB_R = 0.0 ,
			  	dAverageFR_R = 0.0 , dAverageFR_F = 0.0;
		//Update the average value;
		for (int u=0;u<NowW;u++){
			for (int v=0;v<NowH;v++){
				dAverageLF_F += (double)iLFAreaF.at<cv::Vec3b>(v , u)[iChannel];
				dAverageLF_L += (double)iLFAreaL.at<cv::Vec3b>(v , u)[iChannel];
				dAverageBL_L += (double)iBLAreaL.at<cv::Vec3b>(v , u)[iChannel];
				dAverageBL_B += (double)iBLAreaB.at<cv::Vec3b>(v , u)[iChannel];
				dAverageRB_B += (double)iRBAreaB.at<cv::Vec3b>(v , u)[iChannel];
				dAverageRB_R += (double)iRBAreaR.at<cv::Vec3b>(v , u)[iChannel];
				dAverageFR_R += (double)iFRAreaR.at<cv::Vec3b>(v , u)[iChannel];
				dAverageFR_F += (double)iFRAreaF.at<cv::Vec3b>(v , u)[iChannel];
			}
		}

		dAverageLF_F /= iTotalPixel;
		dAverageLF_L /= iTotalPixel;
		dAverageBL_L /= iTotalPixel;
		dAverageBL_B /= iTotalPixel;
		dAverageRB_B /= iTotalPixel;
		dAverageRB_R /= iTotalPixel;
		dAverageFR_R /= iTotalPixel;
		dAverageFR_F /= iTotalPixel;



		Eigen::Vector4d iNewG(1.0 , 1.0 , 1.0 , 1.0);


		//Solved by least multiplier.
		Eigen::Matrix4d iA;
		iA << 	dAverageLF_F , -dAverageLF_L ,	 0.0  			,	 	0.0		,
				0.0 		 , dAverageBL_L  , 	 -dAverageBL_B 	,		0.0		,
				0.0			 , 0.0			 ,   dAverageRB_B 	,  -dAverageRB_R,
				-dAverageFR_F, 0.0			 , 	0.0				,  dAverageFR_R ;



		Eigen::EigenSolver<Eigen::Matrix4d> solver(iA);
		Eigen::Vector4d values = solver.eigenvalues().real();
		Eigen::Matrix4d vectors = solver.eigenvectors().real();
		double minValue = values[0];
		int minPos = 0;
		for (int i=1;i<4;i++){
			if (values[i] < minValue){
				minValue = values[i];
				minPos = i;
			}
		}
		iNewG = vectors.block<4,1>(0 , minPos);
		double min = iNewG[0];
		for (int i=0;i<4;i++){
			if (min * min < iNewG[i] * iNewG[i]){
				min = iNewG[i];
			}
		}
		iNewG /= min;

		iGFront.push_back(iNewG[0]);
		iGLeft.push_back(iNewG[1]);
		iGBack.push_back(iNewG[2]);
		iGRight.push_back(iNewG[3]);
	}
	
	//Initialize all iterators again.
	pIterFront = iImageFrontYCRCB.begin<cv::Vec3b>();
	pIterLeft = iImageLeftYCRCB.begin<cv::Vec3b>();
	pIterBack = iImageBackYCRCB.begin<cv::Vec3b>();
	pIterRight = iImageRightYCRCB.begin<cv::Vec3b>();


	W = iImageFront.cols;
	H = iImageFront.rows;
	cv::Vec3b iPt;


	maxV = (BIRDS_EYE_HEIGHT - CENTER_HEIGHT)/2;
	maxU = (BIRDS_EYE_WIDTH)/4*3;
	minU = (BIRDS_EYE_WIDTH)/4;
	for (int v=0;v<H;v++){
		for (int u= 0;u<W;u++){
                //Front area                                   
				iImageFrontYCRCB.at<cv::Vec3b>(v , u)[0] *= iGFront[0];
				iImageFrontYCRCB.at<cv::Vec3b>(v , u)[1] *= iGFront[1];
				iImageFrontYCRCB.at<cv::Vec3b>(v , u)[2] *= iGFront[2];	

				//Left area.            	
				iImageLeftYCRCB.at<cv::Vec3b>(v , u)[0] *= iGLeft[0];
				iImageLeftYCRCB.at<cv::Vec3b>(v , u)[1] *= iGLeft[1];
				iImageLeftYCRCB.at<cv::Vec3b>(v , u)[2] *= iGLeft[2];

				//Back area.    
				iImageBackYCRCB.at<cv::Vec3b>(v , u)[0] *= iGBack[0];
				iImageBackYCRCB.at<cv::Vec3b>(v , u)[1] *= iGBack[1];
				iImageBackYCRCB.at<cv::Vec3b>(v , u)[2] *= iGBack[2];

                //Right area.
				iImageRightYCRCB.at<cv::Vec3b>(v , u)[0] *= iGRight[0];
				iImageRightYCRCB.at<cv::Vec3b>(v , u)[1] *= iGRight[1];
				iImageRightYCRCB.at<cv::Vec3b>(v , u)[2] *= iGRight[2];
        }
    }





	//Initialize all iterators again.
	pIterFront = iImageFront.begin<cv::Vec3b>();
	pIterLeft = iImageLeft.begin<cv::Vec3b>();
	pIterBack = iImageBack.begin<cv::Vec3b>();
	pIterRight = iImageRight.begin<cv::Vec3b>();

	//Change YCRCB image to BGR again.


	maxV = (BIRDS_EYE_HEIGHT - CENTER_HEIGHT)/2;
	maxU = (BIRDS_EYE_WIDTH)/4*3;
	minU = (BIRDS_EYE_WIDTH)/4;
	for (int v=0;v<H;v++){
		for (int u= 0;u<W;u++){
				cv::Vec3b iOriginPt = iImageFrontYCRCB.at<cv::Vec3b>(v , u);
                value = (iOriginPt[0] + 1.772 * (iOriginPt[1] - 128));
                if (value > 255){
                	value = 255;
                } else if (value < 0){
                	value = 0;
                }
				iImageFront.at<cv::Vec3b>(v , u)[0] = (int)value;
				value = (iOriginPt[0] - 0.344136 * (iOriginPt[1] - 128) - 0.714136 * (iOriginPt[2] - 128));
				if (value > 255){
                	value = 255;
                } else if (value < 0){
                	value = 0;
                }
				iImageFront.at<cv::Vec3b>(v , u)[1] = (int)value;
				value = (iOriginPt[0] + 1.402 * (iOriginPt[2] - 128));
				if (value > 255){
                	value = 255;
                } else if (value < 0){
                	value = 0;
                }
				iImageFront.at<cv::Vec3b>(v , u)[2] = (int)value;	

        }
    }


    maxU = (W- CENTER_WIDTH)/2;
	for (int v=0;v<H;v++){
		for (int u= 0;u<W;u++){	
                //Left area.            	
				cv::Vec3b iOriginPt = iImageLeftYCRCB.at<cv::Vec3b>(v , u);
				value = (iOriginPt[0] + 1.772 * (iOriginPt[1] - 128));
                if (value > 255){
                	value = 255;
                } else if (value < 0){
                	value = 0;
                }
				iImageLeft.at<cv::Vec3b>(v , u)[0] = (int)(value);
				value = (iOriginPt[0] - 0.344136 * (iOriginPt[1] - 128) - 0.714136 * (iOriginPt[2] - 128));
				if (value > 255){
                	value = 255;
                } else if (value < 0){
                	value = 0;
                }
				iImageLeft.at<cv::Vec3b>(v , u)[1] = (int)(value);
				value = (iOriginPt[0] + 1.402 * (iOriginPt[2] - 128));
				if (value > 255){
                	value = 255;
                } else if (value < 0){
                	value = 0;
                }
				iImageLeft.at<cv::Vec3b>(v , u)[2] = (int)(value);	
        	} 
    }


    minV = (H + CENTER_HEIGHT)/2;
    minU = W/4;
    maxU = W/4*3;
	for (int v=0;v<H;v++){
		for (int u= 0;u<W;u++){				
        		//Back area.            	
				cv::Vec3b iOriginPt = iImageBackYCRCB.at<cv::Vec3b>(v , u);
				value = (iOriginPt[0] + 1.772 * (iOriginPt[1] - 128));
                if (value > 255){
                	value = 255;
                } else if (value < 0){
                	value = 0;
                }
				iImageBack.at<cv::Vec3b>(v , u)[0] = (int)(value);
				value = (iOriginPt[0] - 0.344136 * (iOriginPt[1] - 128) - 0.714136 * (iOriginPt[2] - 128));
				if (value > 255){
                	value = 255;
                } else if (value < 0){
                	value = 0;
                }
				iImageBack.at<cv::Vec3b>(v , u)[1] = (int)(value);
				value = (iOriginPt[0] + 1.402 * (iOriginPt[2] - 128));
				if (value > 255){
                	value = 255;
                } else if (value < 0){
                	value = 0;
                }
				iImageBack.at<cv::Vec3b>(v , u)[2] = (int)(value);	
        }
    }


	minU = (W+CENTER_WIDTH)/2;
	for (int v=0;v<H;v++){
		for (int u= 0;u<W;u++){		   		
	                //Right area.            	
					cv::Vec3b iOriginPt = iImageRightYCRCB.at<cv::Vec3b>(v , u);
					value = (iOriginPt[0] + 1.772 * (iOriginPt[1] - 128));
	                if (value > 255){
	                	value = 255;
	                } else if (value < 0){
	                	value = 0;
	                }
					iImageRight.at<cv::Vec3b>(v , u)[0] = (int)(value);
					value = (iOriginPt[0] - 0.344136 * (iOriginPt[1] - 128) - 0.714136 * (iOriginPt[2] - 128));
					if (value > 255){
	                	value = 255;
	                } else if (value < 0){
	                	value = 0;
	                }
					iImageRight.at<cv::Vec3b>(v , u)[1] = (int)(value);
					value = (iOriginPt[0] + 1.402 * (iOriginPt[2] - 128));
					if (value > 255){
	                	value = 255;
	                } else if (value < 0){
	                	value = 0;
	                }
					iImageRight.at<cv::Vec3b>(v , u)[2] = (int)(value);	
        }
    }

}






#endif