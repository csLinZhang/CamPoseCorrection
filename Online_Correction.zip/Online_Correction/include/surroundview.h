#ifndef SURROUNDVIEW_h_
#define SURROUNDVIEW_h_

#include <iostream>
#include <string>
#include <vector>
#include <Eigen/Core>
#include <Eigen/Geometry>
#include <Eigen/Dense>
#include "sophus/se3.h"
#include "sophus/so3.h"
#include <opencv2/opencv.hpp>
#include <opencv2/core/eigen.hpp>




cv::Mat eigen2mat(Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> A);
void imshow_64F(cv::Mat img,std::string img_name);
cv::Mat bilinear_interpolation(cv::Mat img,cv::Mat pix_table,int rows, int cols);
cv::Mat project_on_ground(cv::Mat img, Sophus::SE3 T_CG,
						  Eigen::Matrix3d K_C,Eigen::Vector4d D_C,
						  cv::Mat K_G,int rows, int cols);
cv::Mat generate_surround_view(cv::Mat img_GF, cv::Mat img_GL, 
							   cv::Mat img_GB, cv::Mat img_GR, 
							   int rows, int cols);

void adjust_pose(cv::Mat img_GA, cv::Mat img_GB,
				 Eigen::Matrix<double,6,1>& rhophi_A,
				 Eigen::Matrix<double,6,1>& rhophi_B,
				 cv::Mat K_G,
				 int overlap_x, int overlap_y, int overlap_w, int overlap_h,
				 double lr);

cv::Mat ground2cam(int x,int y,cv::Mat K_G, Sophus::SE3 T_CG, Eigen::Matrix3d K_C);

//Kyrie

void CalculateROI(	cv::Mat & mImage , cv::Mat & mROI , 
					cv::Mat mK , cv::Mat mD ,
					Sophus::SE3 sT_CG , cv::Mat mKG,
					int nROI_X , int nROI_Y , int nROI_W , int nROI_H);

//


void calc_ROI_AB(
				 cv::Mat& img_A, cv::Mat& img_B,
				 cv::Mat& ROI_on_A, cv::Mat& ROI_on_A_from_B,cv::Mat& P_As,
				 Eigen::Matrix3d K_A, Eigen::Matrix3d K_B, 
				 Eigen::Vector4d D_A, Eigen::Vector4d D_B,
				 Sophus::SE3 T_AG, Sophus::SE3 T_BG, 
				 cv::Mat K_G,
				 int ROI_x,int ROI_y,int ROI_w,int ROI_h,
					std::vector<cv::Mat> & gPointsCorner
				);

void adjust_pose_V2(
					cv::Mat img_A, cv::Mat img_B,std::string A,std::string B,
					Sophus::SE3& rhophi_A_SE3,
					Eigen::Matrix3d K_A, Eigen::Matrix3d K_B, 
					Eigen::Vector4d D_A, Eigen::Vector4d D_B,
					Sophus::SE3 T_AG, Sophus::SE3 T_BG, 
					cv::Mat K_G,
					int ROI_x,int ROI_y,int ROI_w,int ROI_h,
					double threshold, double rate
				   );


void adjust_pose_V2_2(
					cv::Mat img_A, cv::Mat img_B,std::string A,std::string B,
					Sophus::SE3& rhophi_A_SE3,
					Eigen::Matrix3d K_A, Eigen::Matrix3d K_B, 
					Eigen::Vector4d D_A, Eigen::Vector4d D_B,
					Sophus::SE3 T_AG, Sophus::SE3 T_BG, 
					cv::Mat K_G,
					int ROI_x,int ROI_y,int ROI_w,int ROI_h,
					double threshold, double rate
				   );



Eigen::Matrix<double,1,6> PoseAdjustV3(	cv::Mat mImage_A, cv::Mat mImage_B,
					cv::Mat mGroundImage_A , cv::Mat mGroundImage_B,
					cv::Mat mK_A, cv::Mat mK_B, 
					cv::Mat mD_A, cv::Mat mD_B,
					Sophus::SE3 sT_AG, Sophus::SE3 sT_BG, 
					cv::Mat mK_G,
					int nROI_X,int nROI_Y,int nROI_W,int nROI_H,
					double nThreshold,double nDecayRate);

#endif 