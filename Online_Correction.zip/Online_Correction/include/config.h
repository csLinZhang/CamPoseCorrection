#ifndef CONFIG_H_
#define CONFIG_H_

#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <opencv2/calib3d/calib3d.hpp>

#include <iostream>
using namespace std;


const cv::Size iCameraImageSize(1280 , 1080);

const cv::Size iBirdEyeSize(1000 , 1000);


int BIRDS_EYE_WIDTH = 1000;
const int BIRDS_EYE_HEIGHT = 1000;
const int CENTER_HEIGHT = 500;
const int CENTER_WIDTH = 250;

#endif
