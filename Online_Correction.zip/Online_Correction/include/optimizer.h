#ifndef OPTIMIZER_H_
#define OPTIMIZER_H_

#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <opencv2/calib3d/calib3d.hpp>

#include <vector>
#include <iostream>
#include "converter.h"

using namespace std;

double CheckQuality(vector<cv::Point2f> gPointsCamera , cv::Mat mHomography1,
					cv::Mat mHomography2 , cv::Mat mK1 , cv::Mat mD1 , 
					cv::Mat mK2 , cv::Mat mD2 , 
					cv::Mat mGrayImage1 , cv::Mat mGrayImage2){
	vector<cv::Point2f> gPointsGround , gPointsCamera2;
	
	gPointsGround = ConvertCameraToGround(mHomography1, gPointsCamera);
	gPointsCamera2 = ConvertGroundToCamera(mHomography2, gPointsGround);

	return 0.0;

}

#endif