#ifndef CONVERTER_H_
#define CONVERTER_H_

#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <opencv2/calib3d/calib3d.hpp>

#include <vector>
#include <iostream>
using namespace std;

cv::Mat ConvertColorToGray(cv::Mat & mMat){
	cv::Mat mGray;
	//Convert overlap region to gray image.
	cv::cvtColor(mMat,mGray,cv::COLOR_BGR2GRAY);
	//Convert the data type so it can be computed efficiently.
	mGray.convertTo(mGray, CV_64FC1);
	return mGray;
}

vector<cv::Point2f> ConvertCameraToGround(	cv::Mat mHomography ,
									 		vector<cv::Point2f> gPointsCamera){
	vector<cv::Point2f> gPointsGround;
	// gPointsGround.reserve(gPointsCamera)
	for (auto item : gPointsCamera){
		cv::Mat mPointCamera = (cv::Mat_<double>(3 , 1) << item.x , item.y , 1);
		cv::Mat mPointGround = mHomography.inv() * mPointCamera;
		cv::Point2f iPoint(	mPointGround.at<double>(0 , 0)/mPointGround.at<double>(2 , 0) ,
							mPointGround.at<double>(1 , 0)/mPointGround.at<double>(2 , 0));
        if (mPointGround.at<double>(2 , 0) == 0){
            iPoint = cv::Point2f(0 , 0);
        }
        gPointsGround.push_back(iPoint);
	}
	return gPointsGround;
}


vector<cv::Point2f> ConvertCameraToDistort(	cv::Mat mHomography , 
											cv::Mat mK , cv::Mat mD,
									 		vector<cv::Point2f> gPointsCamera){
	vector<cv::Point2f> gPointsHomogeneous;
	gPointsHomogeneous.reserve(gPointsCamera.size());

	for (auto item : gPointsCamera){
		cv::Mat mPointCamera = (cv::Mat_<double>(3 , 1) << item.x , item.y , 1);
		cv::Mat mPointHomogeneous = mK.inv() * mPointCamera;
		cv::Point2f iPoint(	mPointHomogeneous.at<double>(0 , 0)/mPointHomogeneous.at<double>(2 , 0) ,
							mPointHomogeneous.at<double>(1 , 0)/mPointHomogeneous.at<double>(2 , 0));
        if (mPointHomogeneous.at<double>(2 , 0) == 0){
            iPoint = cv::Point2f(0 , 0);
        }
        gPointsHomogeneous.push_back(iPoint);
	}
	cv::fisheye::distortPoints(gPointsHomogeneous, gPointsHomogeneous, mK, mD);
	return gPointsHomogeneous;
}

vector<cv::Point2f> ConvertGroundToCamera(cv::Mat mHomography ,
									 		vector<cv::Point2f> gPointsGround){
	vector<cv::Point2f> gPointsCamera;
	// gPointsCamera.reserve(gPointsGround)
	for (auto item : gPointsGround){
		cv::Mat mPointGround = (cv::Mat_<double>(3 , 1) << item.x , item.y , 1);
		cv::Mat mPointCamera = mHomography.inv() * mPointGround;
		cv::Point2f iPoint(	mPointCamera.at<double>(0 , 0)/mPointCamera.at<double>(2 , 0) ,
							mPointCamera.at<double>(1 , 0)/mPointCamera.at<double>(2 , 0));
        if (mPointCamera.at<double>(2 , 0) == 0){
            iPoint = cv::Point2f(0 , 0);
        }
        gPointsCamera.push_back(iPoint);
	}
	return gPointsCamera;	
}


#endif