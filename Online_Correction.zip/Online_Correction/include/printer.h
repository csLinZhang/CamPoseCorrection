#ifndef LIBHELLO_h_
#define LIBHELLO_h_

void printSum(int sum);

#endif 