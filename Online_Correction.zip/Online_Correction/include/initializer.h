#ifndef INITIALIZER_h_
#define INITIALIZER_h_

#include <iostream>
#include <Eigen/Core>
#include <Eigen/Geometry>
#include "sophus/se3.h"
#include <queue>

using namespace std;
struct CMyClass
{
	int m_nData;
};

CMyClass iClass;
queue<CMyClass> gMyClassQueue;

void initializePose(Sophus::SE3& T_FG,Sophus::SE3& T_LG,
					Sophus::SE3& T_BG,Sophus::SE3& T_RG);
void initializeK(Eigen::Matrix3d& K_F, Eigen::Matrix3d& K_L,
				 Eigen::Matrix3d& K_B, Eigen::Matrix3d& K_R);
void initializeD(Eigen::Vector4d& D_F, Eigen::Vector4d& D_L,
				 Eigen::Vector4d& D_B, Eigen::Vector4d& D_R);

#endif 