#ifndef CALCULATE_H_
#define CALCULATE_H_

#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <opencv2/calib3d/calib3d.hpp>

#include <iostream>
#include <vector>
using namespace std;

//Step 1
vector<double> CompareSparseDifference(	cv::Mat & mOriginalFirst, cv::Mat & mOriginalSecond ,
										vector<cv::Point2f> & gKeyPoint1, vector<cv::Point2f> & gKeyPoint2,
										cv::Mat & mKFirst , cv::Mat & mDFirst , cv::Mat & mKSecond , cv::Mat & mDSecond,
										cv::Mat & mHomographyFirst , cv::Mat & mHomographySecond){
	vector<double> gDifference;
	gDifference.reserve(gKeyPoint1.size());
	double nMeanFirst = 0.0 , nMeanSecond = 0.0;
	
	//Generate distort points.
	vector<cv::Point2f> gDistortPoint1 , gDistortPoint2;
	gDistortPoint1.reserve(gKeyPoint1.size());
	gDistortPoint2.reserve(gKeyPoint2.size());
	for (int i=0;i<gKeyPoint1.size();i++){
		cv::Point2f iPoint1 = gKeyPoint1[i];
		cv::Point2f iPoint2 = gKeyPoint2[i];

		cv::Mat mPoint1 = mKFirst.inv() * (cv::Mat_<double>(3 , 1) << iPoint1.x , iPoint1.y , 1);
		cv::Mat mPoint2 = mKSecond.inv() * (cv::Mat_<double>(3 , 1) << iPoint2.x , iPoint2.y , 1);

		//Homogeneous coordination.
		cv::Point2f iPoint1Homo(	mPoint1.at<double>(0 , 0) ,
									mPoint1.at<double>(1 , 0));
		//Check if z == 0
        if (mPoint1.at<double>(2 , 0) == 0){
                iPoint1Homo = cv::Point2f(0 , 0);
        }else{
        	iPoint1Homo.x /= mPoint1.at<double>(2 , 0);
        	iPoint1Homo.y /= mPoint1.at<double>(2 , 0);
        }

        cv::Point2f iPoint2Homo(	mPoint2.at<double>(0 , 0) ,
									mPoint2.at<double>(1 , 0));
        //Check if z == 0
        if (mPoint2.at<double>(2 , 0) == 0){
                iPoint2Homo = cv::Point2f(0 , 0);
        }else{
        	iPoint2Homo.x /= mPoint2.at<double>(2 , 0);
        	iPoint2Homo.y /= mPoint2.at<double>(2 , 0);
        }
        gDistortPoint1.push_back(iPoint1Homo);
        gDistortPoint2.push_back(iPoint2Homo);
	}

	//Distort points.
	cv::fisheye::distortPoints(gDistortPoint1, gDistortPoint1, mKFirst, mDFirst);
	cv::fisheye::distortPoints(gDistortPoint2, gDistortPoint2, mKSecond, mDSecond);

	//Normalize
	for (int i=0;i<gDistortPoint1.size();i++){
		cv::Point2f iPoint1 = gDistortPoint1[i];
		cv::Point2f iPoint2 = gDistortPoint2[i];
		nMeanFirst += mOriginalFirst.at<double>(iPoint1.y , iPoint1.x);
		nMeanSecond += mOriginalSecond.at<double>(iPoint2.y , iPoint2.x);
	}

	nMeanFirst /= gDistortPoint1.size();
	nMeanSecond /= gDistortPoint2.size();
	double nRatio = nMeanFirst / nMeanSecond;

	//Compute the difference.
	if (nRatio >1){
		for (int i=0;i<gDistortPoint1.size();i++){
			cv::Point2f iPoint1 = gDistortPoint1[i];
			cv::Point2f iPoint2 = gDistortPoint2[i];
			gDifference.push_back(
					mOriginalFirst.at<double>(iPoint1.y , iPoint1.x) / nRatio 
					- mOriginalSecond.at<double>(iPoint2.y , iPoint2.x)
				);
		}		
	}else{
		for (int i=0;i<gKeyPoint1.size();i++){
			cv::Point2f iPoint1 = gDistortPoint1[i];
			cv::Point2f iPoint2 = gDistortPoint2[i];
			gDifference.push_back(
					mOriginalFirst.at<double>(iPoint1.y , iPoint1.x) 
					- mOriginalSecond.at<double>(iPoint2.y , iPoint2.x) / nRatio
				);
		}
	}
	return gDifference;
}

//Step 2

//The input points are on the undistorted image.
void CalculateSparseGradient(cv::Mat & mOriginalImage ,
						 	vector<double> & gGradientU , vector<double> & gGradientV ,
						 	cv::Mat mK , cv::Mat mD ,
						 	vector<cv::Point2f> gPoints){
	for (auto iPoint : gPoints){
		vector<cv::Point2f> gGradientPoints;
		gGradientPoints.reserve(9);
		//Calculate the Pci and its neighbours in the original image
		for (int i=0;i<3;i++){
			for (int j=0;j<3;j++){
				cv::Mat mPciNeighbour = (cv::Mat_<double>(3 , 1) << iPoint.x , iPoint.y , 1);
				mPciNeighbour.at<double>(0 , 0) = mPciNeighbour.at<double>(0 , 0) + (j-1);
				mPciNeighbour.at<double>(1 , 0) = mPciNeighbour.at<double>(1 , 0) + (i-1);
				cv::Mat mPci3 = mK.inv() * mPciNeighbour;
				cv::Point2f iPoint(	mPci3.at<double>(0 , 0)/mPci3.at<double>(2 , 0) ,
									mPci3.at<double>(1 , 0)/mPci3.at<double>(2 , 0));
                if (mPci3.at<double>(2 , 0) == 0){
                    iPoint = cv::Point2f(0 , 0);
                }
                gGradientPoints.push_back(iPoint);
			}
		}
		cv::fisheye::distortPoints(gGradientPoints, gGradientPoints, mK, mD);
		vector<int> gWeightsX = {-1 , 0 , 1 , -2 , 0 , 2 , -1 , 0 , 1};
		vector<int> gWeightsY = {-1 , -2 , -1 , 0 , 0 , 0 , 1 , 2, 1};
		double nGradientX = 0.0 , nGradientY = 0.0;
		for (int i=0;i<9;i++){
			cv::Point2f iPoint = gGradientPoints[i];
			int nOriginalX = (int)iPoint.x;
			int nOriginalY = (int)iPoint.y;
			nGradientX += gWeightsX[i] * mOriginalImage.at<double>(nOriginalY , nOriginalX);
			nGradientY += gWeightsY[i] * mOriginalImage.at<double>(nOriginalY , nOriginalX);
		}
		gGradientU.push_back(nGradientX);
		gGradientV.push_back(nGradientY);
	}
}




//Step 3
//The input points are on the undistorted image.
cv::Mat CalculateSparseDiffForHomography(	cv::Mat & mHomography ,vector<double> & gDifference ,
											vector<cv::Point2f> & gPoints ,
											vector<double> & gGradientU , vector<double> & gGradientV){

	cv::Mat mGradientAll = (cv::Mat_<double>(1 , 9) << 	0.0 , 0.0 , 0.0 , 0.0 ,
														0.0 , 0.0 , 0.0 , 0.0 , 0.0);
	//Get the inverse homography.
	
	cv::Mat mHomographyInv = mHomography.inv();

	//Use sparse method, there is no need to thres here.
	
	//Initialize variables.
	int nPointNum = 0;
	vector<cv::Point2f> gAllPoints;

	//Loop for all points.
	for (int i=0;i<gPoints.size();i++){
		//Get the position of the point.
		double nXci = gPoints[i].x;
		double nYci = gPoints[i].y;

		cv::Mat mPci = (cv::Mat_<double>(3 , 1) << nXci , nYci , 1);
		cv::Mat mPg = mHomographyInv * mPci;
		//divide by z
		double nZg = mPg.at<double>(2 , 0);
		mPg /= nZg;
		//Get nXg , nYg
		double nXg = mPg.at<double>(0 , 0);
		double nYg = mPg.at<double>(1 , 0);

		cv::Mat mPciNotNormalize = mHomography * mPg;
		double nZci = mPciNotNormalize.at<double>(2 , 0);

		//Now we get nXg , nYg , nXci , nYci , nZg , nZci.
		cv::Mat mGradientPg2Hi = (cv::Mat_<double>(2 , 9));

		//Use differential in fisheye 
		mGradientPg2Hi.at<double>(0 , 0) = nXg/nZci;
		mGradientPg2Hi.at<double>(1 , 0) = 0;

		mGradientPg2Hi.at<double>(0 , 1) = nYg/nZci;
		mGradientPg2Hi.at<double>(1 , 1) = 0;

		mGradientPg2Hi.at<double>(0 , 2) = 1/nZci;
		mGradientPg2Hi.at<double>(1 , 2) = 0;

		mGradientPg2Hi.at<double>(0 , 3) = 0;
		mGradientPg2Hi.at<double>(1 , 3) = nXg/nZci;

		mGradientPg2Hi.at<double>(0 , 4) = 0;
		mGradientPg2Hi.at<double>(1 , 4) = nYg/nZci;

		mGradientPg2Hi.at<double>(0 , 5) = 0;
		mGradientPg2Hi.at<double>(1 , 5) = 1/nZci;

		mGradientPg2Hi.at<double>(0 , 6) = -nXg * nXci / nZci;
		mGradientPg2Hi.at<double>(1 , 6) = -nYg * nXci / nZci;

		mGradientPg2Hi.at<double>(0 , 7) = -nXg * nYci / nZci;
		mGradientPg2Hi.at<double>(1 , 7) = -nYg * nYci / nZci;


		mGradientPg2Hi.at<double>(0 , 8) = -nXci * 1 / nZci;
		mGradientPg2Hi.at<double>(1 , 8) = -nYci * 1 / nZci;

		//Calculate the gradient of the image.
		cv::Mat mGradientI2Pg = (cv::Mat_<double>(1 , 2));
		mGradientI2Pg.at<double>(0 , 0) = gGradientU[i];
		mGradientI2Pg.at<double>(0 , 1) = gGradientV[i];

		//Calculate the gradient of the difference.
		double nGradientLoss2I = gDifference[i];

		cv::Mat mGradientOneItem = nGradientLoss2I * mGradientI2Pg * mGradientPg2Hi;


		mGradientAll = mGradientAll + mGradientOneItem;

	}

	//Normalize
	mGradientAll /= gPoints.size();

	return mGradientAll;
}


#endif