#ifndef POINT_SELECTION_H_
#define POINT_SELECTION_H_


#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <opencv2/calib3d/calib3d.hpp>

#include <vector>
#include <iostream>
#include "calculate.h"
#include "initializer.h"
using namespace std;

//Return points on undistorted image.
void  SelectPoint(	cv::Mat mOverlapFirst , cv::Mat mOverlapSecond ,
					cv::Mat mHomographyFirst , cv::Mat mHomographySecond,
					cv::Mat mOriginalImageFirst , cv::Mat mOriginalImageSecond,
					cv::Mat mKFirst , cv::Mat mDFirst , cv::Mat mKSecond , cv::Mat mDSecond ,
					int nMinX , int nMinY,
					vector<cv::Point2f> & gPointsFirst , vector<cv::Point2f> & gPointsSecond){
	//1. Check the difference.
	//Compute the difference between 2 images.
	//Normalize firstly.
	double nMeanFirst = 0.0 , nMeanSecond = 0.0;
	for (int u=0;u<mOverlapFirst.size().width;u++){
		for (int v=0;v<mOverlapFirst.size().height;v++){
			nMeanFirst += mOverlapFirst.at<double>(v , u);
			nMeanSecond += mOverlapSecond.at<double>(v , u);
		}
	}
	nMeanFirst/=(mOverlapFirst.size().width * mOverlapFirst.size().height);
	nMeanSecond/=(mOverlapSecond.size().width * mOverlapSecond.size().height);

	double nRatio = nMeanFirst / nMeanSecond;
	if (nRatio >1){
		mOverlapFirst = mOverlapFirst/nRatio; 
	}else{
		mOverlapSecond = mOverlapSecond/nRatio;
	}
	cv::Mat mDiffGray;
	//Compute the difference.
	cv::subtract(mOverlapFirst,mOverlapSecond,mDiffGray,cv::noArray(),CV_64FC1);
	//Delete points that difference is not obvious.
	//Calculate the mean difference.
	double nMeanDifference2 = 0.0;
	for (int u=0;u<mOverlapFirst.size().width;u++){
		for (int v=0;v<mOverlapFirst.size().height;v++){
			nMeanDifference2 += mDiffGray.at<double>(v , u) * mDiffGray.at<double>(v , u);
		}
	}
	nMeanDifference2 /= mOverlapFirst.size().width * mOverlapFirst.size().height;


	//Select points that difference is more than 1.5 * mean value.
	vector<cv::Point2f> gDifferenceEnoughPoints;
	gDifferenceEnoughPoints.reserve(mOverlapFirst.size().width * mOverlapFirst.size().height);
	for (int u=0;u<mOverlapFirst.size().width;u++){
		for (int v=0;v<mOverlapFirst.size().height;v++){
			//Add proper points.
			if (mDiffGray.at<double>(v , u) * mDiffGray.at<double>(v , u) > nMeanDifference2*0.9){
				gDifferenceEnoughPoints.push_back(cv::Point2f(u + nMinX , v + nMinY));
			}
		}
	}

	//Use the homography matrix to calculate keypoints on undistorted image.
	//Make preparations.
	vector<cv::Point2f> gPointsFirstDiff , gPointsSecondDiff;
	
	gPointsFirstDiff.reserve(gDifferenceEnoughPoints.size());
	gPointsSecondDiff.reserve(gDifferenceEnoughPoints.size());

	for (auto item : gDifferenceEnoughPoints){
		cv::Mat mMatPoint = (cv::Mat_<double>(3 , 1)<< item.x , item.y , 1);
		cv::Mat mUndistortPoint1 = mHomographyFirst * mMatPoint;
		cv::Mat mUndistortPoint2 = mHomographySecond * mMatPoint;
		//Normalize.
		cv::Point2f iUndistortPoint1(	mUndistortPoint1.at<double>(0 , 0) , 
										mUndistortPoint1.at<double>(1 , 0));

		cv::Point2f iUndistortPoint2(	mUndistortPoint2.at<double>(0 , 0) , 
										mUndistortPoint2.at<double>(1 , 0));
		//Check if z ==0 
		if (mUndistortPoint1.at<double>(2 , 0) == 0 || 
			mUndistortPoint2.at<double>(2 , 0) == 0){
			continue;
		}
		//Normalize.
		iUndistortPoint1.x /= mUndistortPoint1.at<double>(2 , 0);
		iUndistortPoint1.y /= mUndistortPoint1.at<double>(2 , 0);
		iUndistortPoint2.x /= mUndistortPoint2.at<double>(2 , 0);
		iUndistortPoint2.y /= mUndistortPoint2.at<double>(2 , 0);
		//Add points to the container.
		gPointsFirstDiff.push_back(iUndistortPoint1);
		gPointsSecondDiff.push_back(iUndistortPoint2);
	}

	cout << "First size " << gPointsFirstDiff.size() << endl; 

	//2. Check gradient.
	vector<double> gFirstGradientU , gFirstGradientV;
	vector<double> gSecondGradientU , gSecondGradientV;
	//Calculate the gradient of 2 images.
	CalculateSparseGradient(	mOriginalImageFirst, gFirstGradientU, gFirstGradientV,
							 	mKFirst, mDFirst, gPointsFirstDiff);
	CalculateSparseGradient(	mOriginalImageSecond, gSecondGradientU, gSecondGradientV,
							 	mKSecond, mDSecond, gPointsSecondDiff);
	//Calculate mean gradient.
	double nMeanGradient1 = 0.0 , nMeanGradient2 = 0.0;
	for (int i=0;i<gFirstGradientV.size();i++){
		nMeanGradient1 += gFirstGradientU[i] * gFirstGradientU[i];
		nMeanGradient1 += gFirstGradientV[i] * gFirstGradientV[i];

		nMeanGradient2 += gSecondGradientU[i] * gSecondGradientU[i];
		nMeanGradient2 += gSecondGradientV[i] * gSecondGradientV[i];
	}
	nMeanGradient1 /= gFirstGradientV.size();
	nMeanGradient2 /= gFirstGradientV.size();

	for (int i=0;i<gFirstGradientV.size();i++){
		double nLocalGradient1 = 0.0 , nLocalGradient2 = 0.0;
		//Calculate 2 gradients.
		nLocalGradient1 += gFirstGradientU[i] * gFirstGradientU[i];
		nLocalGradient1 += gFirstGradientV[i] * gFirstGradientV[i];
		nLocalGradient2 += gSecondGradientU[i] * gSecondGradientU[i];
		nLocalGradient2 += gSecondGradientV[i] * gSecondGradientV[i];
		if (nLocalGradient1 > nMeanGradient1*0.9 || nLocalGradient2 > nMeanGradient2*0.9){
			gPointsFirst.push_back(gPointsFirstDiff[i]);
			gPointsSecond.push_back(gPointsSecondDiff[i]);
		}
	}
}



#endif