#ifndef RECOVER_H_
#define RECOVER_H_

#include <iostream>
#include <string>
#include <vector>
#include <Eigen/Core>
#include <Eigen/Geometry>
#include <Eigen/Dense>
#include "sophus/se3.h"
#include "sophus/so3.h"
#include <opencv2/opencv.hpp>
#include <opencv2/core/eigen.hpp>

using namespace std;

Sophus::SE3 RecoverPose(cv::Mat mHomography , cv::Mat mK_C , cv::Mat mK_G);
Sophus::SE3 RecoverPoseByPnP(cv::Mat mHomography , cv::Mat mK_C , cv::Mat mK_G , cv::Size iBirdsEyeSize);

Sophus::SE3 RecoverPoseByPnP(cv::Mat mHomography , cv::Mat mK_C , cv::Mat mK_G , vector<cv::Mat> gPointsBirdsEye,
								cv::Mat & mRVec , cv::Mat & mtVec);

#endif