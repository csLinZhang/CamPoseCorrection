Online Pose Correction System
1. Prerequisites
We have tested the library in Ubuntu 14.04, but it should be easy to compile in other platforms.

C++11 or C++0x Compiler
We use the new thread and chrono functionalities of C++11.


OpenCV
We use OpenCV to manipulate images and features. Dowload and install instructions can be found at: http://opencv.org. We use 3.4.1, but it should also work for other version at least 3.0.

Eigen3
Download and install instructions can be found at: http://eigen.tuxfamily.org.

g2o
We use g2o library to perform non-linear optimizations. More info can be found in http://openslam.org/g2o.html.

Sophus
It's an Lie algebra library. More info can be found in https://strasdat.github.io/Sophus/.

2. Building the project
We use CMake to build the project on ubuntu 14.04.

cd Online_Correction/
mkdir build
cd build
cmake ..
make
cd ..
There has been no rules for "make install" yet, so if you want to use the library in other project, maybe you can copy the headers and the lib file to system path by hand.

3. Run the project
After compile and build the project, some executable files will be stored in the ./bin/ .

we have prepared one test sample yet. For the version without pixel selection:
./bin/pose_adjustment_v2

For the version which follows a sparse direct framework:
./bin/pose_adjustment_v3

After an image appears, press enter to see the whole optimization process.